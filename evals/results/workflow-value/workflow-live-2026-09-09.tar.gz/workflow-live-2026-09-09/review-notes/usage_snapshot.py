"""Postprocess completed artifacts; never launch models or assign semantic grades."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
sys.path.insert(0, str(REPO / 'evals'))
from native_diagnostics import events, session_tools
from native_report import usage_totals

rows = []
pending = []
for path in sorted((ROOT / 'trajectories').glob('*/*/*/sessions/*/manifest.json')):
    manifest = json.loads(path.read_text())
    session = path.parent
    harness, domain, arm = session.parts[-5:-2]
    identity = str(session.relative_to(ROOT))
    if not manifest.get('finished_at'):
        pending.append({'path': identity, 'model_launch_attempted': manifest.get('model_launch_attempted')})
        continue
    scan = manifest.get('credential_scan', {})
    if not scan.get('complete') or scan.get('matches'):
        raise ValueError(f'Completed artifact is not cleared for text inspection: {identity}')
    row = {key: manifest.get(key) for key in ('index', 'day', 'exit_code', 'elapsed_seconds',
        'model_launch_attempted', 'termination_reason', 'temporary_auth_home_removed')}
    row.update(path=identity, harness=harness, domain=domain, arm=arm)
    summary_path = session / 'trace-summary.json'
    if summary_path.exists():
        row.update(usage_totals(harness, json.loads(summary_path.read_text())))
    if (session / 'trace.jsonl.gz').exists():
        trace = events(session / 'trace.jsonl.gz')
        tools, provenance = session_tools(session, harness)
        names = Counter(str(tool['name']) for tool in tools)
        if harness == 'codex':
            completed = Counter(event.get('item', {}).get('type') for event in trace
                                if event.get('type') == 'item.completed')
            names['file_change'] = completed.get('file_change', 0)
            row['native_completed_item_types'] = dict(completed)
            row['unclassified_completed_types'] = sorted(set(completed) -
                {'agent_message', 'reasoning', 'command_execution', 'file_change'})
        row['tool_counts_by_name'] = dict(names)
        row['counted_tool_actions'] = sum(names.values())
        row['tool_capture_provenance'] = provenance
    rows.append(row)

groups = {}
for row in rows:
    key = '/'.join(row[k] for k in ('harness', 'domain', 'arm'))
    group = groups.setdefault(key, {'completed_sessions': 0, 'totals': {}, 'coverage': {}})
    group['completed_sessions'] += 1
    for field in ('elapsed_seconds', 'input_tokens_reported', 'cached_input_tokens_reported',
                  'cache_write_input_tokens_reported', 'output_tokens_reported',
                  'reasoning_tokens_reported', 'native_total_tokens_reported',
                  'native_cost_estimate_usd', 'counted_tool_actions'):
        value = row.get(field)
        if value is not None:
            group['totals'][field] = group['totals'].get(field, 0) + value
            group['coverage'][field] = group['coverage'].get(field, 0) + 1

snapshot = {'generated_at': datetime.now(timezone.utc).isoformat(),
    'postprocessing_source_hashes': {
        str(path.relative_to(REPO)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (Path(__file__).resolve(), REPO / 'evals/native_diagnostics.py',
                     REPO / 'evals/native_report.py', REPO / 'evals/recall.py')},
    'semantic_grading': False, 'completed_sessions': rows, 'pending_sessions': pending,
    'launch_attempts_observed': sum(bool(row.get('model_launch_attempted')) for row in rows + pending),
    'groups': groups,
    'notes': ['Compare token categories within a harness. Codex input includes cached input; Claude input excludes separate cache reads/writes.',
              'Codex tool counts include completed command executions and file-change items; one file-change item may affect multiple files.',
              'Other completed Codex item types are listed for manual accounting review, not silently counted as tools.',
              'Native dollar estimates are not subscription charges. Missing categories remain absent, with explicit coverage.',
              'Partial snapshots are not a study result. All planned trajectories remain in the final denominator.']}
assert snapshot['launch_attempts_observed'] <= 192
(ROOT / 'review-notes/usage-snapshot.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({'completed_sessions': len(rows), 'pending_sessions': len(pending),
                  'launch_attempts_observed': snapshot['launch_attempts_observed'], 'groups': groups}, indent=2))
