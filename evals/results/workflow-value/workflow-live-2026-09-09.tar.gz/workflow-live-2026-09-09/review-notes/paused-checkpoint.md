# Usage pause checkpoint

Recorded: 2026-09-09T21:42:47.010827+00:00

The owner expressed concern about consuming today's model allowance. The assistant held all further native evaluation launches. No continuation batch was launched and no automatic resume is scheduled. Reconfirm desired evaluation scope or budget when the owner chooses to resume.

README revision 96f41f00a6bf702ac8c5d638901be1e48f0b1106 was pushed and passed CI before the study began. Runtime skill remains unchanged.

Original live study: evals/runs/workflow-live-2026-09-09. The manifest closed at 2026-09-09T21:32:44.801751+00:00. There are 46 completed native sessions: Codex 19, Claude 14, Antigravity 13. The six revenue trajectories are complete. Codex weekly-product/skill has completed five sessions through simulated day 28, with its next confirmed wake saved at day 35. Original artifacts must remain intact; never repeat completed decisions.

The original matrix was gracefully stopped at session boundaries after the owner reported the Claude session limit. The owner explicitly accepts unfinished Claude coverage. Six remaining Claude trajectories have no model decisions and must be reported as unevaluated. Do not launch further Claude checks.

The proposed Codex/Antigravity continuation is not started. Uncommitted evals/workflow_continue.py and tests/test_workflow_continue.py are draft evaluation support, not runtime skill files. Four focused tests passed. Strict mypy still requires importing aggregate_hash directly from recall instead of accessing runner.aggregate_hash. The continuation driver still needs review, a duplicate-live-launch guard, and a no-model preflight before any approved future launch. No live resampling is permitted. Keep the frozen source, candidate, session cap, service state and original event clock unchanged.

Approximately 27 Codex and 32 Antigravity sessions were estimated to remain, subject to actual agent scheduling. The 2–3 hour estimate was wall time for runs plus review, not a subscription allowance estimate. Do not infer remaining quota or monetary charges from token counts.

Independent revenue reviews are retained under review-notes. Codex and Claude revenue pairs show no supported outcome advantage for the skill in these single paired trajectories. Antigravity review includes material failures and must be finalized/adjudicated from saved evidence before publication. The full diverse-use-case comparison is incomplete; do not present revenue-only findings as complete workflow value evidence.

Next owner-authorized continuation should first read this checkpoint and the saved reviews. Preserve all completed traces. Final publication, combined report, and confirmation of all three local harness installations remain outstanding. No automatic resume task has been created.
