# Evidence: change-receipt-effect-3

Original source or retained artifact and hash/version: service.py operations receipt for req-change-eval-compact-day0
Product / responsibility / subject / cohort / version: Returning mobile offer page / evaluation deployment / compact offer / returning mobile / revision 2
Event or request created at: simulated day 0
Deployed/exposed at: simulated day 0 (revision 2)
Observation window and measurement definition: deployment confirmation and revision update
Retrieved at: simulated day 0

Actual source observation: {"revision": 2, "config": {"offer": "compact", "include_wallet": true}, "effect": "deployed", "receipt": "effect-3"}
What this supports: Product revision advanced from 1 to 2; evaluation configuration {"offer": "compact", "include_wallet": true} successfully deployed.
Missing coverage and uncertainty: Initial change command returned response_lost; reconciled via operations lookup confirming receipt effect-3 was committed.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
