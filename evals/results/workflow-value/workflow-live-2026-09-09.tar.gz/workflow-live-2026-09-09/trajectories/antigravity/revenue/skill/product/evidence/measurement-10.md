# Evidence: measurement-10

Original source or retained artifact and hash/version: metrics receipt measurement-10
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / evaluation 14-day mature observation / returning mobile / revision 3 (offer: compact, include_wallet: true)
Event or request created at: simulated day 14
Deployed/exposed at: simulated day 0 (revision 2) through day 14 (revision 3)
Observation window and measurement definition: settled eligible visits from day 0 to day 14 (definition: settled-ledger-v1); exposure_age_days: 14; mature: true; window: [day 0, day 14]
Retrieved at: simulated day 14

Actual source observation: control_net_revenue_per_visit = 5, variant_net_revenue_per_visit = 5.3, difference_95ci = [0.1, 0.5], checkout_error_rate = 0.002, refunds_included = true, mature = true, revision = 3.
What this supports: Variant (compact layout) net revenue is observed at 5.3 vs control 5.0 (+0.30 per visit). The difference 95% CI is [0.1, 0.5], which is strictly positive (statistically significant positive lift). Checkout error rate is 0.002 (0.2%), exactly matching baseline control. The mature flag is true. This establishes conclusive, mature evidence that the compact offer layout improves net settled revenue while maintaining checkout health.
Missing coverage and uncertainty: None. 14-day mature observation window reached; result is statistically conclusive and guardrails preserved.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
