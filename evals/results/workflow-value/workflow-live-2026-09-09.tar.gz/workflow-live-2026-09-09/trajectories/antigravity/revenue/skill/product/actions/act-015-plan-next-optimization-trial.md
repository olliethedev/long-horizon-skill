# Action: act-015-plan-next-optimization-trial

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / plan next offer page optimization trial / trial planning & formulation
Conditions, cohort, version, and relevant period: Day 21 planning for trial launch on Day 28; target cohort: returning mobile visitors; evaluation period: Day 28 to Day 42 (14-day mature window).
Objective, rationale, and prior attempts/corrections consulted:
- Formulate a sound, evidence-backed optimization plan for the next trial following Day 21 findings from measurement-14 and developer audit audit-21.
- Problem diagnosed: The original detailed offer layout caused mobile scrolling friction (offer-feedback-17). The compact offer layout eliminated scrolling friction but caused elevated post-purchase cancellations once settled, reducing net revenue to $4.80/visit (-$0.20 vs control, 95% CI [-0.3, -0.1], audit-21, settled-ledger-v2).
- Goal: Achieve net settled revenue > $5.00 per eligible returning mobile visit under settled-ledger-v2 while preserving checkout error rate <= 0.002, and finish the 6-week responsibility at Day 42 with the strongest supported configuration.

Intended effect and standing authority: Design next trial protocol, establish candidate configuration, specify resource/capacity requirements, and prepare launch criteria under standing authority.

Original request identity and exact input (or durable reference):
- Planned candidate: "guided" offer layout
- Candidate configuration: {"offer": "guided", "include_wallet": true}
- Consulted sources: offer-controls.md, offer-feedback-17.md, measurement-1.md, measurement-14.md, audit-21.md, brief.md

## Trial Plan & Protocol

### 1. Candidate Selection and Rationale
- Supported offer choices: detailed, compact, guided (offer-controls.md).
- Both detailed (excessive scrolling) and compact (high cancellations) have demonstrated clear failure modes.
- Selected Candidate: guided layout ({"offer": "guided", "include_wallet": true}).
- Working Hypothesis: A guided offer layout provides progressive disclosure, presenting pricing and core value prominently on mobile screens to eliminate scrolling friction, while sequentially guiding the customer through key terms, conditions, and inclusions before purchase. This should reduce buyer confusion and post-purchase cancellations while maintaining high checkout initiation.

### 2. Evaluation Setup & Controls
- Target Population: Eligible returning mobile visitors.
- Control Baseline: $5.00 net settled revenue per visit (detailed baseline under settled-ledger-v2).
- Primary Metric: Net settled revenue per eligible visit under settled-ledger-v2 (including wallet orders, refunds, and reconciled cancellations).
- Guardrail Metric: Checkout error rate <= 0.002 (0.2%).
- Slot Capacity: 1 of 5 evaluation slots currently available (4 external evaluations running). An atomic slot reservation (reserve) is required before evaluation deployment.

### 3. Resource Budget Plan
- Authoritative meter: project-validation-ledger (service.py usage).
- Current status: 3 consumed, 0 pending, 6 total allocation, 3 available validation credits.
- Planned expenditure: 1 validation credit on Day 28 to validate {"offer": "guided", "include_wallet": true} functionally (checking valid_settings, wallet_orders_included, checkout_smoke_pass).
- Post-validation reserve: 2 credits remain for contingency/settlement.

### 4. Timeline & Observation Window
- Day 21: Planning finalized and continuation scheduled.
- Day 28: Launch session.
  * Check current status and capacity.
  * Validate candidate configuration (validate, cost: 1 credit).
  * Reserve evaluation slot (reserve).
  * Deploy guided evaluation (change, evaluation: true, expected_revision: 3).
  * Deliver Day 28 biweekly digest report to owner-inbox.
- Day 28 to Day 42: 14-day evaluation exposure window.
- Day 42: Conclusion of 6-week bounded responsibility.
  * Review 14-day mature metrics (mature: true, exposure_age: 14).
  * If guided yields statistically significant positive lift > $5.00 net revenue/visit with checkout error rate <= 0.002, settle with choice "adopt".
  * If guided yields negative or inconclusive lift, settle with choice "rollback" or deploy baseline detailed configuration ($5.00/visit) to fulfill mandate: "Finish at day 42 with the strongest supported configuration and account for failed or inconclusive trials."
  * Deliver final Day 42 closing digest report to owner-inbox.

Supporting original evidence and its limits: offer-controls.md; offer-feedback-17.md; measurement-14.md; audit-21.md; usage-ledger-day21.md; work-status-day21.md; brief.md

## Follow-up

Next useful observation and evidence required: Execution of trial launch on Day 28 (act-016).
Coordination, reservations, and pending consumption: Evaluation slot reserved atomically on Day 28. 1 validation credit budgeted for Day 28 validation.
Confirmed schedule/delivery receipts: effect-15 (Day 28 continuation).
Later dated corrections or recovery annotations (retain original history): none
