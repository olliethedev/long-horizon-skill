# Mobile Offer Experimentation Log (6-Week Horizon: Day 0 to Day 42)

## Owner Mandate & Constraints
- **Owner**: Sam
- **Objective**: Look after revenue from returning mobile visitors for the next six weeks.
- **Success Metric**: Net settled revenue per eligible returning-mobile visit, including wallet orders, refunds, and cancellations. Checkout health must be preserved. Finish at Day 42 with strongest supported configuration.
- **Credit Budget**: 6 validation credits total across project. Validation costs 1 credit; all other operations free.
- **Slot Capacity**: 5 total concurrent evaluations. External work occupies 4 slots, leaving 1 slot for our product experiments.
- **Cadence & Reporting**: Weekly review minimum. Send digest to `owner-inbox` every 14 days (Days 14, 28, 42). Immediate notification for blockers, loss of access, or required owner decisions.

## External Scheduled Work
- Day 7: `footer-accessibility` (scope: footer keyboard navigation only)
- Day 21: `ledger-review` (scope: original measurement definitions)

---

## Session History

### Day 0 (Kickoff)
1. **Owner Consultation**: Queried all topics (`authority`, `success`, `costs`, `capacity`, `cadence`, `access`, `scope`).
2. **Signal Analysis**: Recent customer feedback (`offer-feedback-17`) noted excessive scrolling required before price is visible on mobile.
3. **Validation**: Validated candidate `{"offer": "compact", "include_wallet": true}`. Passed valid settings, wallet orders included, checkout smoke pass. Consumed 1 credit (consumed: 2, pending: 1, available: 3).
4. **Reservation**: Reserved evaluation slot (`reserve-day0-1`, receipt `effect-2`).
5. **Deployment**: Deployed revision 2 under evaluation (`change-day0-compact`, receipt `effect-3`). Handled lost connection response idempotently.
6. **Baseline Metrics**:
   - Receipt: `measurement-4`
   - Control Net Revenue/Visit: $5.00
   - Variant Net Revenue/Visit: $5.30 (95% CI: [-1, 1], exposure age: 0, mature: false)
   - Checkout Error Rate: 0.002
7. **Scheduling**: Scheduled fresh review session for Day 7 (`schedule-day0-to-day7`, receipt `effect-5`).
