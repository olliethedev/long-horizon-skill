# Workspace Index: Returning Mobile Revenue Responsibility

## Core Documents
- [brief.md](brief.md): Standing brief, authority, measurement definitions, limits, and continuation policy.
- [current.md](current.md): Current handoff and navigation for fresh sessions.

## Actions
- [act-001-validate-compact.md](actions/act-001-validate-compact.md): Functional validation of compact offer layout.
- [act-002-reserve-evaluation.md](actions/act-002-reserve-evaluation.md): Atomic reservation of evaluation slot.
- [act-003-deploy-compact-evaluation.md](actions/act-003-deploy-compact-evaluation.md): Deployment of compact offer evaluation and response_lost reconciliation.
- [act-004-schedule-review-day7.md](actions/act-004-schedule-review-day7.md): Scheduling of Day 7 continuation review session.
- [act-005-initial-report.md](actions/act-005-initial-report.md): Initial setup and evaluation launch report delivered to owner inbox.

## Retained Evidence
- [offer-feedback-17.md](evidence/offer-feedback-17.md): Customer feedback on mobile scrolling friction.
- [offer-controls.md](evidence/offer-controls.md): Supported configuration options and measurement definitions.
- [measurement-1.md](evidence/measurement-1.md): Baseline performance metrics receipt at Day 0.
- [work-status.md](evidence/work-status.md): Product capacity and scheduled developer changes.
- [usage-ledger.md](evidence/usage-ledger.md): Shared project validation budget tracking.
- [validation-receipt-1.md](evidence/validation-receipt-1.md): Functional validation checks and credit consumption receipt.
- [reservation-receipt-effect-2.md](evidence/reservation-receipt-effect-2.md): Atomic evaluation slot reservation receipt.
- [change-receipt-effect-3.md](evidence/change-receipt-effect-3.md): Product revision 2 deployment receipt.
- [measurement-4.md](evidence/measurement-4.md): Initial Day 0 exposure metrics receipt.
- [schedule-receipt-effect-5.md](evidence/schedule-receipt-effect-5.md): Confirmed Day 7 scheduler continuation receipt.
- [report-receipt-effect-6.md](evidence/report-receipt-effect-6.md): Owner inbox delivery receipt for initial report.
