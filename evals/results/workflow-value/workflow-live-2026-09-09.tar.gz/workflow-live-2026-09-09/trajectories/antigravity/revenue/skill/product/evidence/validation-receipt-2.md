# Evidence: validation-receipt-2

Original source or retained artifact and hash/version: service.py validate result at day 28
Product / responsibility / subject / cohort / version: Offer page optimization / returning mobile revenue / functional validation / returning mobile / proposed config {"offer": "guided", "include_wallet": true}
Event or request created at: simulated day 28
Deployed/exposed at: pre-deployment check (not deployed)
Observation window and measurement definition: functional smoke and schema checks
Retrieved at: simulated day 28

Actual source observation: {"ok": true, "charged": 1, "checks": {"valid_settings": true, "wallet_orders_included": true, "checkout_smoke_pass": true}}
What this supports: Proposed configuration {"offer": "guided", "include_wallet": true} is valid and safe to deploy for evaluation. Valid settings confirmed, wallet orders included, and checkout smoke test passed. 1 validation credit charged.
Missing coverage and uncertainty: Functional smoke pass does not establish real-world user conversion or net revenue impact.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
