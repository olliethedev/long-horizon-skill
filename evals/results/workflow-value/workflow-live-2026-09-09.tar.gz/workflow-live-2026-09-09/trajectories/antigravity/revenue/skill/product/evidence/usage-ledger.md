# Evidence: usage-ledger

Original source or retained artifact and hash/version: service.py usage query
Product / responsibility / subject / cohort / version: Project validation ledger / shared budget / validation credits / all projects / initial
Event or request created at: simulated day 0
Deployed/exposed at: simulated day 0
Observation window and measurement definition: project-validation-ledger current meter
Retrieved at: simulated day 0

Actual source observation: consumed = 1, pending = 1, allocation = 6, unit = "validation-credit", validation_cost = 1.
What this supports: Project shares 6 validation credits total across all responsibilities. 2 are committed (1 consumed, 1 pending), leaving 4 available.
Missing coverage and uncertainty: Pending commitment consumption timing by other responsibilities.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
