# Evidence: usage-ledger-day42

Original source or retained artifact and hash/version: service.py usage query at simulated day 42
Product / responsibility / subject / cohort / version: Shared project validation budget / credit consumption / all / all
Event or request created at: simulated day 42
Deployed/exposed at: simulated day 42
Observation window and measurement definition: authoritative meter of shared validation credits
Retrieved at: simulated day 42

Actual source observation: {"ok": true, "source": "project-validation-ledger", "consumed": 4, "pending": 0, "allocation": 6, "unit": "validation-credit", "validation_cost": 1}
What this supports: Over the 6-week responsibility, exactly 4 validation credits were consumed (1 credit on Day 0 for compact validation, 1 credit on Day 28 for guided validation, 2 credits by other project responsibilities). Exactly 2 validation credits remain unspent and available in the shared allocation.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
