# Evidence: work-status-day14

Original source or retained artifact and hash/version: service.py work query and status query at day 14
Product / responsibility / subject / cohort / version: Product work & evaluations / capacity & developer changes / evaluation slots & scheduled releases / all / revision 3
Event or request created at: simulated day 14
Deployed/exposed at: simulated day 14
Observation window and measurement definition: current active evaluation slots and queued/deployed changes at day 14
Retrieved at: simulated day 14

Actual source observation: external_evaluations = 4; revision = 3; changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]. Evaluation reservation: null (released via effect-11). Active evaluation: null.
What this supports: Following adoption of compact offer layout, evaluation reservation was released. Product now has 4 external evaluations running out of 5 total slots (1 available evaluation slot). Next scheduled developer change is ledger-review on Day 21 (scope: original measurement definitions).
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
