# Evidence: work-status

Original source or retained artifact and hash/version: service.py work query
Product / responsibility / subject / cohort / version: Product work & evaluations / capacity & developer changes / evaluation slots & scheduled releases / all / revision 1
Event or request created at: simulated day 0
Deployed/exposed at: simulated day 0
Observation window and measurement definition: current active evaluation slots and queued changes
Retrieved at: simulated day 0

Actual source observation: external_evaluations = 4; changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}].
What this supports: Product has 4 occupied evaluation slots out of 5 maximum capacity (leaving 1 slot available). Scheduled developer changes on Day 7 and Day 21 are compatible and should be coordinated.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
