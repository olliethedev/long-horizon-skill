# Action: act-003-deploy-compact-evaluation

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / deploy compact offer evaluation / evaluation deployment
Conditions, cohort, version, and relevant period: Day 0 deployment, evaluation target cohort: returning mobile, version: config {"offer": "compact", "include_wallet": true}, expected_revision: 1
Objective, rationale, and prior attempts/corrections consulted: Deploy compact offer configuration as an evaluation against control (detailed). Consulted offer-feedback-17, validation-receipt-1, reservation-receipt-effect-2.
Intended effect and standing authority: Deploy configuration with evaluation: true and reservation req-reserve-eval-slot-day0 under standing authority.
Original request identity and exact input (or durable reference):
- Operation: change
- request_id: "req-change-eval-compact-day0"
- Input: {
    "request_id": "req-change-eval-compact-day0",
    "expected_revision": 1,
    "config": {"offer": "compact", "include_wallet": true},
    "evaluation": true,
    "reservation": "req-reserve-eval-slot-day0"
  }

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Deployed & Exposed (evaluation active)
Actual receipts and versions:
- Initial response: {"ok": false, "error": "response_lost", "detail": "The connection ended before a response was received."}
- Reconciled operation receipt from operations service: {"revision": 2, "config": {"offer": "compact", "include_wallet": true}, "effect": "deployed", "receipt": "effect-3"}
- Verified state via status: revision 2, evaluation active with req-change-eval-compact-day0.
- Initial exposure metrics receipt: measurement-4 (exposure_age_days: 0, mature: false).
Outcome or unresolved effect: Evaluation successfully deployed and verified at revision 2. Unresolved response_lost error fully reconciled against committed operation effect-3.
Supporting original evidence and its limits: change-receipt-effect-3.md; measurement-4.md; validation-receipt-1.md; reservation-receipt-effect-2.md

## Follow-up

Next useful observation and evidence required: Observation of mature metrics after evaluation exposure window (Day 7 review).
Coordination, reservations, and pending consumption: Evaluation reservation req-reserve-eval-slot-day0 active (evaluation slot 5 of 5 occupied).
Confirmed schedule/delivery receipts: Scheduled for Day 7 (see act-004).
Later dated corrections or recovery annotations (retain original history): Connection lost on initial change response; reconciled via operations query showing successful commit at revision 2.
