# Evidence: offer-feedback-17

Original source or retained artifact and hash/version: status.records[id=offer-feedback-17]
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / offer explanation scrolling friction / returning mobile / revision 1 (offer: detailed)
Event or request created at: day -2
Deployed/exposed at: prior to day -2 (revision 1)
Observation window and measurement definition: customer qualitative feedback; submitted day -2
Retrieved at: simulated day 0

Actual source observation: "The offer explanation takes a lot of scrolling before I can see the price."
What this supports: Returning mobile users experience friction scrolling through long explanations to find pricing under the "detailed" offer layout.
Missing coverage and uncertainty: Qualitative feedback from a single user report; quantitative impact on conversion and revenue requires controlled evaluation.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
