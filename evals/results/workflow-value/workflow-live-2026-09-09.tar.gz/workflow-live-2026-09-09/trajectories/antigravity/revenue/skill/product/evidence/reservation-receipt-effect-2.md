# Evidence: reservation-receipt-effect-2

Original source or retained artifact and hash/version: service.py reserve operation receipt effect-2
Product / responsibility / subject / cohort / version: Product capacity / evaluation slot reservation / atomic reservation / all / revision 1
Event or request created at: simulated day 0
Deployed/exposed at: simulated day 0
Observation window and measurement definition: atomic evaluation slot allocation
Retrieved at: simulated day 0

Actual source observation: {"reservation": "req-reserve-eval-slot-day0", "receipt": "effect-2"}
What this supports: Product has successfully locked 1 evaluation slot, exhausting the product capacity limit of 5.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
