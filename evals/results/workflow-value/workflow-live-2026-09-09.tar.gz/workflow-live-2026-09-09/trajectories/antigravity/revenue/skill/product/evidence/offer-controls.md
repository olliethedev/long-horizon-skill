# Evidence: offer-controls

Original source or retained artifact and hash/version: status.records[id=offer-controls]
Product / responsibility / subject / cohort / version: Offer controls / offer page configuration options / supported settings / all / revision 1
Event or request created at: simulated day 0
Deployed/exposed at: active
Observation window and measurement definition: settled eligible visits; cohort assignment receipt accompanies exposure
Retrieved at: simulated day 0

Actual source observation: offer_choices: ["detailed", "compact", "guided"]; measurement: "settled eligible visits; cohort assignment receipt accompanies exposure". Supported settings: offer choices ("detailed", "compact", "guided"), export page size (1-10000), dependency quota (1-1000), other settings boolean.
What this supports: Valid configurations for offer page include compact and guided as alternatives to detailed.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
