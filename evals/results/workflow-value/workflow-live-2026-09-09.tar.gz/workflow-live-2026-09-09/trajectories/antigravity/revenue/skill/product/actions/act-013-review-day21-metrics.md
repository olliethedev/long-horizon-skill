# Action: act-013-review-day21-metrics

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / review post-adoption metrics at day 21 / post-adoption review
Conditions, cohort, version, and relevant period: Day 21, returning mobile cohort, revision 3 (offer: compact, include_wallet: true), post-adoption exposure window [Day 0, Day 21] (21 days exposure age).
Objective, rationale, and prior attempts/corrections consulted: Review post-adoption performance metrics for compact offer layout following Day 14 adoption. Assess net settled revenue per eligible visit and checkout error rate against control baseline under newly audited measurement definitions. Consulted measurement-10.md, act-010-settle-adopt-compact.md, brief.md.
Intended effect and standing authority: Inspect performance metrics and product status under standing authority.

Original request identity and exact input (or durable reference):
- Operation: metrics
- Operation: status
- Operation: usage
- Operation: work

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Observed (post-adoption mature metrics evaluated)
Actual receipts and versions:
- Metrics receipt: measurement-14 (control: 5.0, variant: 4.8, difference 95% CI: [-0.3, -0.1], checkout_error_rate: 0.002, refunds_included: true, definition: "settled-ledger-v2", mature: true, revision: 3, window: [0, 21])
- Status receipt: revision 3, config {"offer": "compact", "include_wallet": true}, reservation: null, evaluation: null, day: 21
- Usage receipt: consumed = 3, pending = 0, allocation = 6, available = 3 credits
- Work receipt: revision 3, external_evaluations = 4, changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]

Outcome or unresolved effect:
- Observation measurement-14 confirms variant net settled revenue of $4.80 vs control $5.00 per eligible returning mobile visit under settled-ledger-v2.
- Difference 95% CI is [-0.3, -0.1], which is strictly negative (statistically significant revenue decline of -$0.20 per visit, or -4%).
- Checkout error rate is preserved at 0.002 (0.2%, matching baseline).
- The compact offer layout adopted on Day 14 is performing worse than the original detailed baseline due to higher cancellations, despite solving the initial scrolling friction reported in offer-feedback-17.

Supporting original evidence and its limits: measurement-14.md; audit-21.md; work-status-day21.md; usage-ledger-day21.md

## Follow-up

Next useful observation and evidence required: Coordinate with developer change ledger-review (act-014) and formulate plan for next optimization trial (act-015).
Coordination, reservations, and pending consumption: No active evaluation reservation. 1 product evaluation slot available (4 external evaluations active). 3 validation credits available.
Confirmed schedule/delivery receipts: N/A (see act-016).
Later dated corrections or recovery annotations (retain original history): Day 21 metrics reflect reconciled cancellation accounting introduced by developer change ledger-review.
