# Action: act-020-deploy-guided-evaluation

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / deploy guided offer evaluation / evaluation deployment
Conditions, cohort, version, and relevant period: Day 28 deployment, evaluation target cohort: returning mobile, candidate version: config {"offer": "guided", "include_wallet": true}, expected_revision: 3.
Objective, rationale, and prior attempts/corrections consulted: Deploy guided offer layout configuration as an active evaluation against control to test progressive disclosure for reducing scrolling friction while preventing post-purchase cancellations. Consulted act-015-plan-next-optimization-trial.md, validation-receipt-2.md, reservation-receipt-effect-17.md, measurement-16.md, audit-21.md, and brief.md.
Intended effect and standing authority: Deploy configuration with evaluation: true and reservation req-reserve-eval-slot-day28 under standing authority.
Original request identity and exact input (or durable reference):
- Operation: change
- request_id: "req-change-eval-guided-day28"
- Input: {
    "request_id": "req-change-eval-guided-day28",
    "expected_revision": 3,
    "config": {"offer": "guided", "include_wallet": true},
    "evaluation": true,
    "reservation": "req-reserve-eval-slot-day28"
  }

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Deployed & Exposed (guided evaluation active)
Actual receipts and versions:
- Operation receipt: {"ok": true, "revision": 4, "config": {"offer": "guided", "include_wallet": true}, "effect": "deployed", "receipt": "effect-18"}
- Verified state via status: revision 4, config {"offer": "guided", "include_wallet": true}, evaluation active: {"request_id": "req-change-eval-guided-day28", "day": 28, "config": {"offer": "guided", "include_wallet": true}}, reservation: "req-reserve-eval-slot-day28".
- Initial exposure metrics receipt: measurement-19 (exposure_age_days: 0, mature: false, control: 5.0, variant: 4.8, 95% CI [-1, 1], checkout_error_rate: 0.002, definition: "settled-ledger-v2").
Outcome or unresolved effect: Evaluation successfully deployed and verified at product revision 4. Guided offer layout is actively exposed to returning mobile visitors.
Supporting original evidence and its limits: change-receipt-effect-18.md; measurement-19.md; reservation-receipt-effect-17.md; validation-receipt-2.md; work-status-day28.md

## Follow-up

Next useful observation and evidence required: Observation of 14-day mature evaluation metrics on Day 42 (act-021).
Coordination, reservations, and pending consumption: Evaluation reservation req-reserve-eval-slot-day28 active (5 of 5 product evaluation slots occupied).
Confirmed schedule/delivery receipts: Scheduled for Day 42 (see act-021).
Later dated corrections or recovery annotations (retain original history): none
