# Evidence: validation-receipt-1

Original source or retained artifact and hash/version: service.py validate result
Product / responsibility / subject / cohort / version: Offer page optimization / returning mobile revenue / functional validation / returning mobile / proposed config {"offer": "compact", "include_wallet": true}
Event or request created at: simulated day 0
Deployed/exposed at: pre-deployment check (not deployed)
Observation window and measurement definition: functional smoke and schema checks
Retrieved at: simulated day 0

Actual source observation: {"ok": true, "charged": 1, "checks": {"valid_settings": true, "wallet_orders_included": true, "checkout_smoke_pass": true}}
What this supports: Proposed configuration {"offer": "compact", "include_wallet": true} is valid and safe to deploy for evaluation.
Missing coverage and uncertainty: Functional smoke pass does not establish real-world user conversion or net revenue impact.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
