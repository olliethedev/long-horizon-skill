# Evidence: reservation-receipt-effect-17

Original source or retained artifact and hash/version: service.py reserve operation receipt effect-17
Product / responsibility / subject / cohort / version: Product capacity / evaluation slot reservation / atomic reservation / all / revision 3
Event or request created at: simulated day 28
Deployed/exposed at: simulated day 28
Observation window and measurement definition: atomic evaluation slot allocation
Retrieved at: simulated day 28

Actual source observation: {"reservation": "req-reserve-eval-slot-day28", "receipt": "effect-17"}
What this supports: Product has successfully locked 1 evaluation slot atomically for the guided offer layout trial, reaching the product capacity limit of 5 (4 external evaluations + 1 active reservation).
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
