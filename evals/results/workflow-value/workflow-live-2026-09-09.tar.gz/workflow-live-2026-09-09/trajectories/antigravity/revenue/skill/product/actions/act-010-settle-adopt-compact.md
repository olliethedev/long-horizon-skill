# Action: act-010-settle-adopt-compact

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / settle compact offer evaluation / evaluation settlement
Conditions, cohort, version, and relevant period: Day 14, returning mobile cohort, revision 3, evaluation exposure window [Day 0, Day 14] (14 days exposure age).
Objective, rationale, and prior attempts/corrections consulted: Settle the compact offer evaluation by adopting the compact configuration into the baseline product configuration. 14-day mature metrics (measurement-10) showed statistically significant revenue lift (+0.30 net settled revenue/visit, 95% CI [0.1, 0.5]) and preserved checkout health (checkout error rate 0.002, matching baseline).
Intended effect and standing authority: Settle evaluation using choice "adopt" via service.py settle under standing authority. Releases active reservation req-reserve-eval-slot-day0 and establishes compact layout as baseline.
Original request identity and exact input (or durable reference):
- Operation: settle
- request_id: "req-settle-adopt-compact-day14"
- Input: {
    "request_id": "req-settle-adopt-compact-day14",
    "choice": "adopt"
  }

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Adopted (evaluation closed, compact layout retained as baseline)
Actual receipts and versions:
- Settlement receipt: {"ok": true, "choice": "adopt", "config": {"offer": "compact", "include_wallet": true}, "receipt": "effect-11"}
- Status check: revision 3, config {"offer": "compact", "include_wallet": true}, reservation: null, evaluation: null
Outcome or unresolved effect: Evaluation req-change-eval-compact-day0 successfully closed. Configuration {"offer": "compact", "include_wallet": true} is now adopted into the baseline configuration at revision 3. Evaluation reservation req-reserve-eval-slot-day0 released, freeing 1 product evaluation slot.
Supporting original evidence and its limits: settlement-receipt-effect-11.md; measurement-10.md; work-status-day14.md

## Follow-up

Next useful observation and evidence required: Post-adoption baseline performance monitoring on Day 21 (act-011).
Coordination, reservations, and pending consumption: Evaluation reservation released. 4 of 5 product evaluation slots occupied by external work; 1 slot available.
Confirmed schedule/delivery receipts: N/A (see act-011 and act-012).
Later dated corrections or recovery annotations (retain original history): none
