# Evidence: measurement-7

Original source or retained artifact and hash/version: metrics receipt measurement-7
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / evaluation 7-day observation / returning mobile / revision 3 (offer: compact, include_wallet: true)
Event or request created at: simulated day 7
Deployed/exposed at: simulated day 0 (revision 2) through day 7 (revision 3)
Observation window and measurement definition: settled eligible visits from day 0 to day 7 (definition: settled-ledger-v1); exposure_age_days: 7; mature: false; window: [day 0, day 7]
Retrieved at: simulated day 7

Actual source observation: control_net_revenue_per_visit = 5, variant_net_revenue_per_visit = 5.3, difference_95ci = [-1, 1], checkout_error_rate = 0.002, refunds_included = true, mature = false, revision = 3.
What this supports: Variant (compact layout) net revenue is currently observed at 5.3 vs control 5.0, but difference 95% CI [-1, 1] spans zero, and mature flag is false. Checkout health is maintained at baseline error rate 0.002 (0.2%). The result is currently statistically inconclusive and immature.
Missing coverage and uncertainty: 7-day window is not yet mature (mature: false). Full statistical confidence requires extended observation (e.g., 14 days).
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
