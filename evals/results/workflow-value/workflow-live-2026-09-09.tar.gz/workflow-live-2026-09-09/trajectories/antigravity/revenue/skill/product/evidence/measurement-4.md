# Evidence: measurement-4

Original source or retained artifact and hash/version: metrics receipt measurement-4
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / evaluation initial exposure / returning mobile / revision 2
Event or request created at: simulated day 0
Deployed/exposed at: simulated day 0
Observation window and measurement definition: settled eligible visits up to day 0 (definition: settled-ledger-v1); exposure_age_days: 0; mature: false; window: [day 0, day 0]
Retrieved at: simulated day 0

Actual source observation: control_net_revenue_per_visit = 5, variant_net_revenue_per_visit = 5.3, difference_95ci = [-1, 1], checkout_error_rate = 0.002, refunds_included = true, mature = false.
What this supports: Evaluation is active. Early preliminary variant revenue is 5.3 vs control 5, but mature is false and CI [-1, 1] spans zero. Checkout health stable at 0.002.
Missing coverage and uncertainty: Day 0 metrics are immature (0 days exposure); mature evaluation requires waiting for observation window (e.g., Day 7/14).
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
