# Evidence: work-status-day21

Original source or retained artifact and hash/version: service.py work query and status query at day 21
Product / responsibility / subject / cohort / version: Product work & evaluations / capacity & developer changes / evaluation slots & scheduled releases / all / revision 3
Event or request created at: simulated day 21
Deployed/exposed at: simulated day 21
Observation window and measurement definition: current active evaluation slots and queued/deployed changes at day 21
Retrieved at: simulated day 21

Actual source observation: external_evaluations = 4; revision = 3; changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]. Evaluation reservation: null. Active evaluation: null. Config: {"offer": "compact", "include_wallet": true}. Scheduler: enabled=true, day=28, status="active".

What this supports:
- Developer change ledger-review took effect on Day 21 (scope: original measurement definitions), introducing audit-21 and settled-ledger-v2.
- Prior developer change footer-accessibility remains active at revision 3 without conflict.
- External evaluations occupy 4 of 5 total product evaluation slots; 1 slot remains available for the next evaluation trial.
- No active evaluation currently running; product baseline configuration is {"offer": "compact", "include_wallet": true} at revision 3.

Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
