# Evidence: usage-ledger-day14

Original source or retained artifact and hash/version: service.py usage query at day 14
Product / responsibility / subject / cohort / version: Project validation ledger / shared budget / validation credits / all projects / day 14
Event or request created at: simulated day 14
Deployed/exposed at: simulated day 14
Observation window and measurement definition: project-validation-ledger current meter at day 14
Retrieved at: simulated day 14

Actual source observation: consumed = 3, pending = 0, allocation = 6, unit = "validation-credit", validation_cost = 1.
What this supports: Project shares 6 validation credits total across all responsibilities. 3 credits have been consumed in total, 0 pending, leaving 3 validation credits available. No credits consumed by this responsibility during Day 14 session.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
