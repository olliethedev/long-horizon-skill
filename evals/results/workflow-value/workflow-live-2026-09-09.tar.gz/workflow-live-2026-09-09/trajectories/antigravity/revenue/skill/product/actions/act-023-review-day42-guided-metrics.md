# Action: act-023-review-day42-guided-metrics

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / review mature guided layout evaluation metrics at day 42 / evaluation review
Conditions, cohort, version, and relevant period: Day 42, returning mobile cohort, revision 4/5 (offer: guided, include_wallet: true), evaluation exposure window [Day 28, Day 42] (14 days exposure age, mature: true).
Objective, rationale, and prior attempts/corrections consulted: Review 14-day mature evaluation metrics for guided offer layout under settled-ledger-v2 per scheduled assignment instruction. Determine whether guided layout met adoption criteria (statistically significant positive lift > $5.00/visit with checkout error rate <= 0.002). Consulted measurement-19.md, act-015-plan-next-optimization-trial.md, act-020-deploy-guided-evaluation.md, and brief.md.
Intended effect and standing authority: Inspect evaluation metrics, current system state, capacity, and usage under standing authority.

Original request identity and exact input (or durable reference):
- Operation: metrics
- Operation: status
- Operation: usage
- Operation: work

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Observed (14-day mature evaluation metrics evaluated)
Actual receipts and versions:
- Metrics receipt: measurement-23 (control: 5.0, variant: 4.8, difference 95% CI: [-0.3, -0.1], checkout_error_rate: 0.002, refunds_included: true, definition: "settled-ledger-v2", mature: true, revision: 4, exposure_age_days: 14, window: [28, 42])
- Status receipt: revision 4/5, config {"offer": "guided", "include_wallet": true}, day 42, reservation: "req-reserve-eval-slot-day28", evaluation: {"request_id": "req-change-eval-guided-day28", "day": 28, "config": {"offer": "guided", "include_wallet": true}}, owner_stop: true
- Usage receipt: consumed = 4, pending = 0, allocation = 6, available = 2 validation credits
- Work receipt: revision 4/5, external_evaluations = 4, changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]

Outcome or unresolved effect:
- Observation measurement-23 confirms variant net settled revenue of $4.80 vs control $5.00 per eligible returning mobile visit under settled-ledger-v2 across the full 14-day mature observation window (Days 28–42).
- Difference 95% CI is [-0.3, -0.1], indicating a statistically significant negative lift (-$0.20 per visit, or -4%).
- Checkout error rate is 0.002 (0.2%, preserving checkout health).
- Guided offer layout failed to produce positive lift over the control baseline. Like compact layout, it underperforms detailed baseline ($4.80 vs $5.00). Adoption is rejected.

Supporting original evidence and its limits: measurement-23.md; measurement-19.md; change-receipt-effect-18.md; audit-21.md; work-status-day28.md

## Follow-up

Next useful observation and evidence required: Settle evaluation and handle owner directive to stop product changes and terminate responsibility (act-024, act-025).
Coordination, reservations, and pending consumption: Active reservation req-reserve-eval-slot-day28 pending release via settlement.
Confirmed schedule/delivery receipts: N/A
Later dated corrections or recovery annotations (retain original history): none
