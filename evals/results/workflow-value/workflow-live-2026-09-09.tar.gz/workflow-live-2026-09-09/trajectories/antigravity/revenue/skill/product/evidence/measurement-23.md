# Evidence: measurement-23

Original source or retained artifact and hash/version: metrics receipt measurement-23
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / guided evaluation 14-day mature review / returning mobile / revision 4 (offer: guided, include_wallet: true)
Event or request created at: simulated day 42
Deployed/exposed at: simulated day 28 (revision 4)
Observation window and measurement definition: settled eligible visits from day 28 to day 42 (definition: settled-ledger-v2); exposure_age_days: 14; mature: true; window: [day 28, day 42]
Retrieved at: simulated day 42

Actual source observation: control_net_revenue_per_visit = 5, variant_net_revenue_per_visit = 4.8, difference_95ci = [-0.3, -0.1], checkout_error_rate = 0.002, refunds_included = true, definition = "settled-ledger-v2", mature = true, revision = 4.
What this supports: Guided offer layout evaluation reached full 14-day maturity. Under settled-ledger-v2 (reconciled cancellations and refunds included per audit-21), the guided offer layout produces $4.80 net settled revenue per eligible returning mobile visit versus $5.00 for control, representing a statistically significant negative lift of -$0.20/visit (95% CI: [-0.3, -0.1]). Checkout error rate remains stable at 0.002 (0.2%, preserving checkout health). Because the required adoption threshold was a statistically significant positive lift > $5.00/visit, adoption is rejected.
Missing coverage and uncertainty: None. 14-day mature observation window is complete.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
