# Evidence: usage-ledger-day21

Original source or retained artifact and hash/version: service.py usage query at day 21
Product / responsibility / subject / cohort / version: Project validation ledger / shared budget / validation credits / all projects / day 21
Event or request created at: simulated day 21
Deployed/exposed at: simulated day 21
Observation window and measurement definition: project-validation-ledger current meter at day 21
Retrieved at: simulated day 21

Actual source observation: consumed = 3, pending = 0, allocation = 6, unit = "validation-credit", validation_cost = 1.
What this supports: The project shares 6 validation credits total across all responsibilities. 3 credits have been consumed in total, 0 pending, leaving 3 validation credits available. Zero credits were consumed during the Day 21 review and planning session (metrics, work, status, and schedule operations are free). 3 credits remain available to validate proposed configurations for upcoming optimization trials.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
