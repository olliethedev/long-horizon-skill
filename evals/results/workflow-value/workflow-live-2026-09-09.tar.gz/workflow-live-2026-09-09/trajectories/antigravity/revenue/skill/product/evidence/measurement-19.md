# Evidence: measurement-19

Original source or retained artifact and hash/version: metrics receipt measurement-19
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / guided evaluation initial exposure / returning mobile / revision 4 (offer: guided, include_wallet: true)
Event or request created at: simulated day 28
Deployed/exposed at: simulated day 28 (revision 4)
Observation window and measurement definition: settled eligible visits at day 28 (definition: settled-ledger-v2); exposure_age_days: 0; mature: false; window: [day 28, day 28]
Retrieved at: simulated day 28

Actual source observation: control_net_revenue_per_visit = 5, variant_net_revenue_per_visit = 4.8, difference_95ci = [-1, 1], checkout_error_rate = 0.002, refunds_included = true, definition = "settled-ledger-v2", mature = false, revision = 4.
What this supports: Guided offer layout evaluation is active at revision 4. Early Day 0 preliminary exposure shows variant net revenue 4.8 vs control 5.0, difference 95% CI [-1, 1] (inconclusive), checkout error rate 0.002 (0.2%, baseline preserved), and mature = false. Exposure age is 0 days.
Missing coverage and uncertainty: Day 28 metrics are immature (0 days exposure); mature evaluation requires waiting for the 14-day observation window (Day 42).
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
