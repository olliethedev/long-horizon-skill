# Evidence: settlement-receipt-effect-11

Original source or retained artifact and hash/version: service.py settle operation receipt effect-11 for req-settle-adopt-compact-day14
Product / responsibility / subject / cohort / version: Returning mobile offer page / evaluation settlement / compact offer adoption / returning mobile / revision 3
Event or request created at: simulated day 14
Deployed/exposed at: simulated day 14 (revision 3)
Observation window and measurement definition: evaluation closure, adoption of compact configuration, and release of evaluation slot reservation
Retrieved at: simulated day 14

Actual source observation: {"ok": true, "choice": "adopt", "config": {"offer": "compact", "include_wallet": true}, "receipt": "effect-11"}
What this supports: Evaluation req-change-eval-compact-day0 successfully closed with choice "adopt". Active baseline configuration remains {"offer": "compact", "include_wallet": true} at revision 3. Evaluation reservation req-reserve-eval-slot-day0 is released, reducing occupied evaluation slots in product from 5 to 4.
Missing coverage and uncertainty: None. Verified via service.py status showing reservation: null and evaluation: null.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
