# Evidence: work-status-day28

Original source or retained artifact and hash/version: service.py work query and status query at day 28
Product / responsibility / subject / cohort / version: Product work & evaluations / capacity & developer changes / evaluation slots & scheduled releases / all / revision 4
Event or request created at: simulated day 28
Deployed/exposed at: simulated day 28
Observation window and measurement definition: current active evaluation slots and queued/deployed changes at day 28
Retrieved at: simulated day 28

Actual source observation: external_evaluations = 4; revision = 4; changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]. Evaluation reservation: "req-reserve-eval-slot-day28". Active evaluation: {"request_id": "req-change-eval-guided-day28", "day": 28, "config": {"offer": "guided", "include_wallet": true}}. Config: {"offer": "guided", "include_wallet": true}. Scheduler: enabled=true, day=42, status="active".

What this supports:
- Product revision advanced to 4 upon deployment of guided layout evaluation.
- External evaluations occupy 4 of 5 total product evaluation slots; 1 slot is occupied by this product's active evaluation reservation req-reserve-eval-slot-day28 (5 of 5 slots total occupied).
- Developer changes footer-accessibility and ledger-review remain active and compatible without interference.
- Guided offer layout evaluation is actively running with observation scheduled through Day 42.

Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
