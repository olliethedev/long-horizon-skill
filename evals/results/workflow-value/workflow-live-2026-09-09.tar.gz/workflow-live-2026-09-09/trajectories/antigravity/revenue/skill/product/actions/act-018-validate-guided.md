# Action: act-018-validate-guided

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / validate guided offer layout / validation
Conditions, cohort, version, and relevant period: Day 28, pre-deployment functional validation, target cohort: returning mobile, version: candidate config {"offer": "guided", "include_wallet": true}
Objective, rationale, and prior attempts/corrections consulted: Validate candidate guided offer configuration functionally prior to evaluation deployment, per act-015 trial plan and Day 28 assignment. Consulted act-015-plan-next-optimization-trial.md, offer-controls.md, offer-feedback-17.md, measurement-16.md, and brief.md.
Intended effect and standing authority: Check functional integrity of guided layout and verify smoke tests under standing authority.
Original request identity and exact input (or durable reference):
- Operation: validate
- Input: {"config": {"offer": "guided", "include_wallet": true}}

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Implemented (functional validation confirmed)
Actual receipts and versions: Validation receipt: {"ok": true, "charged": 1, "checks": {"valid_settings": true, "wallet_orders_included": true, "checkout_smoke_pass": true}}
Outcome or unresolved effect: Functional validation succeeded. Checks passed: valid_settings=true, wallet_orders_included=true, checkout_smoke_pass=true. Validation cost: 1 credit consumed.
Supporting original evidence and its limits: validation-receipt-2.md; usage-ledger-day28.md; act-015-plan-next-optimization-trial.md

## Follow-up

Next useful observation and evidence required: Atomically reserve evaluation slot (act-019) and deploy evaluation change (act-020).
Coordination, reservations, and pending consumption: 1 validation credit consumed. Budget meter: consumed = 4, pending = 0, allocation = 6, available = 2.
Confirmed schedule/delivery receipts: N/A
Later dated corrections or recovery annotations (retain original history): none
