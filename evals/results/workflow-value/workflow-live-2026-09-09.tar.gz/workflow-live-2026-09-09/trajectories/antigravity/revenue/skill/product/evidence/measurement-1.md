# Evidence: measurement-1

Original source or retained artifact and hash/version: metrics receipt measurement-1
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / baseline revenue and checkout health / returning mobile / revision 1 (offer: detailed, include_wallet: true)
Event or request created at: simulated day 0
Deployed/exposed at: prior to day 0 (revision 1)
Observation window and measurement definition: settled eligible visits up to day 0 (definition: settled-ledger-v1); mature: false (exposure_age_days: null)
Retrieved at: simulated day 0

Actual source observation: Control net revenue per visit = 5; variant net revenue per visit = 5; 95% CI = [-1, 1]; checkout error rate = 0.002 (0.2%); refunds included = true.
What this supports: Baseline performance metric for returning mobile visitors under detailed offer is 5 net settled revenue per visit with 0.002 checkout error rate.
Missing coverage and uncertainty: Baseline is currently immature (exposure_age_days: null; window_start_day: null). No prior active variant comparison.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
