# Evidence: measurement-16

Original source or retained artifact and hash/version: metrics receipt measurement-16
Product / responsibility / subject / cohort / version: Returning mobile offer page / returning mobile revenue / baseline 28-day mature observation / returning mobile / revision 3 (offer: compact, include_wallet: true)
Event or request created at: simulated day 28
Deployed/exposed at: simulated day 0 (revision 2) through day 28 (revision 3)
Observation window and measurement definition: settled eligible visits from day 0 to day 28 (definition: settled-ledger-v2); exposure_age_days: 28; mature: true; window: [day 0, day 28]
Retrieved at: simulated day 28

Actual source observation: control_net_revenue_per_visit = 5, variant_net_revenue_per_visit = 4.8, difference_95ci = [-0.3, -0.1], checkout_error_rate = 0.002, refunds_included = true, definition = "settled-ledger-v2", mature = true, revision = 3.
What this supports: Under settled-ledger-v2 (reconciling cancellations), the baseline compact offer layout yields $4.80 net settled revenue per visit vs $5.00 control. The difference 95% CI is [-0.3, -0.1], which is strictly negative (statistically significant net revenue reduction of -$0.20 per visit). Checkout error rate is 0.002 (0.2%), preserving checkout health. This 28-day mature observation reconfirms that the compact offer layout underperforms the detailed baseline due to elevated post-purchase cancellations, justifying the planned trial of the guided offer layout.
Missing coverage and uncertainty: None. 28-day mature observation window reached under reconciled accounting definitions.
Earlier source/claim corrected, if any: measurement-10 (Day 14) and measurement-7 (Day 7), which suggested positive or neutral lift under unreconciled settled-ledger-v1.
Scope of the correction and other conflicting evidence: Corrected by audit-21 as part of developer change ledger-review on Day 21, which reconciled cancellations for all original exposures.
