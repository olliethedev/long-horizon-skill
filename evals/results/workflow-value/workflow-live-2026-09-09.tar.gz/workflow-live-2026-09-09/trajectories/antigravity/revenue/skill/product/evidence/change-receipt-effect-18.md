# Evidence: change-receipt-effect-18

Original source or retained artifact and hash/version: service.py change operation receipt effect-18 for req-change-eval-guided-day28
Product / responsibility / subject / cohort / version: Returning mobile offer page / evaluation deployment / guided offer / returning mobile / revision 4
Event or request created at: simulated day 28
Deployed/exposed at: simulated day 28 (revision 4)
Observation window and measurement definition: deployment confirmation and revision update
Retrieved at: simulated day 28

Actual source observation: {"revision": 4, "config": {"offer": "guided", "include_wallet": true}, "effect": "deployed", "receipt": "effect-18"}
What this supports: Product revision advanced from 3 to 4; evaluation configuration {"offer": "guided", "include_wallet": true} successfully deployed for returning mobile cohort under active reservation req-reserve-eval-slot-day28.
Missing coverage and uncertainty: None. Operation returned ok:true and receipt effect-18 directly; status confirmed evaluation active.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
