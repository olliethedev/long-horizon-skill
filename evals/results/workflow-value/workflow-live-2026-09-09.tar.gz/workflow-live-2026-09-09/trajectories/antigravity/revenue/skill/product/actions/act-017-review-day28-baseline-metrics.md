# Action: act-017-review-day28-baseline-metrics

Product / responsibility / subject / aliases: Offer page optimization / returning mobile revenue / review baseline metrics at day 28 / baseline review
Conditions, cohort, version, and relevant period: Day 28, returning mobile cohort, revision 3 (offer: compact, include_wallet: true), baseline exposure window [Day 0, Day 28] (28 days exposure age).
Objective, rationale, and prior attempts/corrections consulted: Review baseline performance metrics for compact offer layout under settled-ledger-v2 per scheduled assignment instruction. Confirm stability of baseline metrics, net settled revenue per visit, and checkout error rate prior to executing planned guided offer optimization trial. Consulted measurement-14.md, audit-21.md, act-015-plan-next-optimization-trial.md, and brief.md.
Intended effect and standing authority: Inspect baseline performance metrics and current system state under standing authority.

Original request identity and exact input (or durable reference):
- Operation: metrics
- Operation: status
- Operation: usage
- Operation: work

## Actual state and evidence

Implemented / deployed / exposed / observed / adopted / rolled back: Observed (baseline mature metrics evaluated)
Actual receipts and versions:
- Metrics receipt: measurement-16 (control: 5.0, variant: 4.8, difference 95% CI: [-0.3, -0.1], checkout_error_rate: 0.002, refunds_included: true, definition: "settled-ledger-v2", mature: true, revision: 3, window: [0, 28])
- Status receipt: revision 3, config {"offer": "compact", "include_wallet": true}, day 28, reservation: null, evaluation: null
- Usage receipt: consumed = 3, pending = 0, allocation = 6, available = 3 validation credits
- Work receipt: revision 3, external_evaluations = 4, changes: [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]

Outcome or unresolved effect:
- Observation measurement-16 reconfirms variant net settled revenue of $4.80 vs control $5.00 per eligible returning mobile visit under settled-ledger-v2.
- Difference 95% CI is [-0.3, -0.1], which is strictly negative (-$0.20 per visit, or -4%).
- Checkout error rate is 0.002 (0.2%, preserving checkout health).
- Reconfirms the diagnosis from act-015: while compact offer layout addressed mobile scrolling friction (offer-feedback-17), it caused elevated post-purchase cancellations once settled. Launching the planned guided layout trial is fully warranted.

Supporting original evidence and its limits: measurement-16.md; audit-21.md; measurement-14.md; usage-ledger-day21.md; work-status-day21.md

## Follow-up

Next useful observation and evidence required: Functional validation of candidate guided offer configuration (act-018).
Coordination, reservations, and pending consumption: Evaluation capacity has 1 slot available (4 external evaluations active). 3 validation credits available.
Confirmed schedule/delivery receipts: N/A
Later dated corrections or recovery annotations (retain original history): Baseline accounting follows reconciled cancellation definitions under settled-ledger-v2.
