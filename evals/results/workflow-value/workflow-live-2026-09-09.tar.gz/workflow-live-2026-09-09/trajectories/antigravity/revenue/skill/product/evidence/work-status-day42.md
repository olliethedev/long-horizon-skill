# Evidence: work-status-day42

Original source or retained artifact and hash/version: service.py work and status queries at simulated day 42
Product / responsibility / subject / cohort / version: Product work coordination / evaluation capacity / all / revision 5
Event or request created at: simulated day 42
Deployed/exposed at: simulated day 42
Observation window and measurement definition: current product revision and active evaluation slots
Retrieved at: simulated day 42

Actual source observation:
- work: {"ok": true, "revision": 5, "external_evaluations": 4, "changes": [{"id": "footer-accessibility", "day": 7, "scope": "footer keyboard navigation only"}, {"id": "ledger-review", "day": 21, "scope": "original measurement definitions"}]}
- status: {"ok": true, "revision": 5, "config": {"offer": "guided", "include_wallet": true}, "day": 42, "access_available": true, "scheduler": {"enabled": false, "day": null, "instruction": null, "status": "terminated"}, "owner_stop": true, "owner_resume_day": null, "reservation": null, "evaluation": null}

What this supports: Evaluation reservation req-reserve-eval-slot-day28 released upon settlement; 0 active reservations for this responsibility; 4 external evaluations running; scheduler terminated (enabled: false); owner_stop: true.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
