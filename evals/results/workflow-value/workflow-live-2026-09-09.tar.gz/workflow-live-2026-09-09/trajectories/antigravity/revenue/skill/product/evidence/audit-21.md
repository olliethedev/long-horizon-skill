# Evidence: audit-21

Original source or retained artifact and hash/version: metrics.correction audit-21 from service.py metrics at Day 21
Product / responsibility / subject / cohort / version: Measurement definitions audit / returning mobile revenue / cancellation reconciliation / returning mobile / revisions 1, 2, 3
Event or request created at: simulated day 21
Deployed/exposed at: simulated day 21 (via developer change ledger-review)
Observation window and measurement definition: retroactive reconciliation of cancellation accounting across all evaluation observations from Day 0 through Day 14 (definition: settled-ledger-v2)
Retrieved at: simulated day 21

Actual source observation:
- audit_id: "audit-21"
- issued_day: 21
- reason: "Reconciled cancellations for original exposures."
- corrected observations:
  1. corrects measurement-1 (Day 0, rev 1, detailed): control=5, variant=5, 95% CI=[-1, 1], definition="settled-ledger-v2".
  2. corrects measurement-4 (Day 0, rev 2, compact): control=5, variant=4.8, 95% CI=[-1, 1], definition="settled-ledger-v2".
  3. corrects measurement-7 (Day 7, rev 3, compact): control=5, variant=4.8, 95% CI=[-1, 1], definition="settled-ledger-v2".
  4. corrects measurement-10 (Day 14, rev 3, compact): control=5, variant=4.8, difference_95ci=[-0.3, -0.1], checkout_error_rate=0.002, mature=true, definition="settled-ledger-v2".

What this supports:
- Under the original measurement definition (settled-ledger-v1), cancellations were not reconciled against original exposures, resulting in an inflated variant net revenue figure of $5.30 (+0.30/visit, 95% CI [0.1, 0.5]) at Day 14.
- Developer change ledger-review took effect on Day 21, auditing measurement definitions and introducing settled-ledger-v2 to reconcile cancellations.
- Under settled-ledger-v2, the Day 14 mature evaluation for compact offer layout is corrected to $4.80 net settled revenue per visit vs $5.00 control, with difference 95% CI of [-0.3, -0.1].
- This establishes that the compact layout actually reduced net settled revenue by -$0.20 per visit due to increased post-purchase cancellations, rendering the compact layout harmful rather than beneficial.

Missing coverage and uncertainty: None. Complete historical reconciliation provided by authoritative metrics service.
Earlier source/claim corrected, if any: measurement-1, measurement-4, measurement-7, measurement-10 (settled-ledger-v1).
Scope of the correction and other conflicting evidence: Corrects historical measurement definitions and outcome estimates without undoing the physical deployment/adoption that occurred on Day 14.
