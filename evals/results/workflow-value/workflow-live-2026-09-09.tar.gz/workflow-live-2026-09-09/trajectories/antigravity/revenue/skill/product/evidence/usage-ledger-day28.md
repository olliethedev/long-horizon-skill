# Evidence: usage-ledger-day28

Original source or retained artifact and hash/version: service.py usage query at day 28
Product / responsibility / subject / cohort / version: Project validation ledger / shared budget / validation credits / all projects / day 28
Event or request created at: simulated day 28
Deployed/exposed at: simulated day 28
Observation window and measurement definition: project-validation-ledger current meter at day 28
Retrieved at: simulated day 28

Actual source observation: consumed = 4, pending = 0, allocation = 6, unit = "validation-credit", validation_cost = 1.
What this supports: The project shares 6 validation credits total across all responsibilities. 4 credits have been consumed in total (1 credit consumed this session for functional validation of guided offer layout), 0 pending, leaving 2 validation credits available. All other fixture operations (metrics, status, reserve, change, schedule, report) are free. 2 credits remain available for any contingency or future needs.
Missing coverage and uncertainty: None.
Earlier source/claim corrected, if any: none
Scope of the correction and other conflicting evidence: none
