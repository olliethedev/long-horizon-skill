"""Use only the two unspent slots after preserving a lost process; never rerun it."""
import hashlib
import json
from pathlib import Path
import signal
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
sys.path.insert(0, str(REPO / 'evals'))
from native_harnesses import discover
from recall import dump, utc_now, request_stop, aggregate_hash, hashes
from workflow_continue import LaunchBudget, safe_remainder

metadata = json.loads((ROOT / 'manifest.json').read_text())
source = Path(metadata['source_study'])
original = json.loads((source / 'manifest.json').read_text())
assert hashlib.sha256((source / 'manifest.json').read_bytes()).hexdigest() == metadata['source_manifest_sha256']
assert hashlib.sha256((REPO / 'evals/workflow_continue.py').read_bytes()).hexdigest() == metadata['continuation_runner_sha256']
assert aggregate_hash(hashes(ROOT / 'skill')) == metadata['skill_tree']
for name, digest in metadata['source_hashes'].items():
    assert hashlib.sha256((REPO / 'evals' / name).read_bytes()).hexdigest() == digest
harness = next(h for h in discover() if h.name == 'codex')
frozen = next(h for h in original['harnesses'] if h['name'] == 'codex')
assert harness.defaults == frozen['defaults']
assert hashlib.sha256(harness.binary.read_bytes()).hexdigest() == frozen['binary_sha256']
slots = sorted((ROOT / 'launch-slots').glob('*.json'))
assert [p.name for p in slots] == ['00.json', '01.json']
assert [json.loads(p.read_text())['session_index'] for p in slots] == [5, 6]
assert all(json.loads(p.read_text())['case'] == 'codex/weekly-product/skill' for p in slots)
assert not (ROOT / 'trajectories/codex/weekly-product/no-skill').exists()
with (ROOT / 'recovery/remainder-claim.json').open('x') as stream:
    json.dump({'at':utc_now(),'previous_slots':2,'remaining_authorized_slots':2,
               'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},stream)

class RemainingBudget(LaunchBudget):
    def __init__(self):
        self.folder = ROOT / 'launch-slots'
        self.used = 2

budget = RemainingBudget()
signal.signal(signal.SIGINT, request_stop)
signal.signal(signal.SIGTERM, request_stop)
skill = json.loads((ROOT / 'trajectories/codex/weekly-product/skill/trajectory.json').read_text())
baseline = safe_remainder(harness, 'weekly-product', 'no-skill', source, ROOT, True, budget)
metadata['results'] = [{k:skill[k] for k in ('harness','domain','arm','actual_sessions','previous_sessions','stop_reason')},baseline]
metadata.update(finished_at=utc_now(),reserved_launch_slots=budget.used,
    executed_sources_unchanged=all(hashlib.sha256((REPO / 'evals' / n).read_bytes()).hexdigest()==d for n,d in metadata['source_hashes'].items()),
    continuation_runner_unchanged=hashlib.sha256((REPO / 'evals/workflow_continue.py').read_bytes()).hexdigest()==metadata['continuation_runner_sha256'],
    source_manifest_unchanged=hashlib.sha256((source / 'manifest.json').read_bytes()).hexdigest()==metadata['source_manifest_sha256'],
    recovery_source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT / 'recovery').glob('*.py')},
    interruption='The runner and owned native process disappeared during skill session 06. Its attempt and surviving evidence are retained; no decision was rerun. Two unspent slots were used for the baseline.',
    native_completed_new_sessions=sum(1 for p in ROOT.glob('trajectories/*/*/*/sessions/*/manifest.json')
        if json.loads(p.read_text()).get('exit_code')==0))
dump(ROOT / 'manifest.json',metadata)
print(json.dumps({'reserved_slots':budget.used,'completed_new_sessions':metadata['native_completed_new_sessions'],
                  'interrupted_attempts':1,'native_launches_total':46+budget.used}),flush=True)
