"""Preserve the interrupted attempt without running a model or repeating any action."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import zlib
import gzip

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
sys.path.insert(0, str(REPO / 'evals'))
from recall import dump, utc_now, summarize_trace
from workflow_publish import publication_scan, recover_gzip
from workflow_runner import preserve_workspace, copy_workspace, inventory

session = ROOT / 'trajectories/codex/weekly-product/skill/sessions/06'
manifest = json.loads((session / 'manifest.json').read_text())
assert manifest['model_launch_attempted'] and not manifest.get('finished_at')
homes = [Path(p) for p in manifest['command'] if 'native-workflow-' in p and p.endswith('/private-home')]
assert len(homes) == 1
temporary = homes[0].parent
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        command = (proc / 'cmdline').read_bytes()
    except OSError:
        continue
    if str(temporary).encode() in command:
        raise ValueError('An owned native process is still active; do not recover over it')

shutil.copyfile(session / 'manifest.json', session / 'interrupted-launch-manifest.json')
shutil.copyfile(ROOT / 'manifest.json', ROOT / 'recovery/interrupted-batch-manifest.json')
issues = {}
for source, target in ((temporary / 'workspace/product', session / 'product-after'),
                       (temporary / 'workspace/work', session / 'work')):
    found = preserve_workspace(source, target) if not target.exists() else []
    assert inventory(source) == inventory(target)
    if found:
        issues[str(target.relative_to(session))] = found
assert not issues
recovered = {}
for name in ('trace.jsonl.gz', 'stderr.txt.gz'):
    raw = (session / name).read_bytes()
    payload, complete = recover_gzip(raw)
    target = session / name.replace('.gz', '-recovered.gz')
    target.write_bytes(gzip.compress(payload))
    recovered[name] = {'original_sha256': hashlib.sha256(raw).hexdigest(),
                       'recovered_bytes': len(payload), 'gzip_complete': complete,
                       'recovered_file': target.name}
scanned = publication_scan(session)
# Read derived native text only after the available-artifact credential gate.
summary = summarize_trace(session / 'trace.jsonl-recovered.gz')
dump(session / 'trace-summary.json', summary)
state = json.loads((session / 'service-state.json').read_text())
dump(session / 'state-after.json', state)
product = session.parents[1] / 'product'
shutil.rmtree(product)
copy_workspace(session / 'product-after', product)
manifest.update(finished_at=utc_now(), recovered_after_process_loss=True,
    native_completion_verified=False, exit_code=None, infrastructure_error='RunnerProcessLost',
    termination_reason='runner_and_native_process_absent_before_capture_finalization',
    elapsed_seconds=None, artifact_errors=issues, product_after=inventory(product),
    decision_present=(session / 'work/decision.md').is_file(), recovered_streams=recovered,
    credential_scan={'complete': True, 'matches': [], 'values_persisted': False,
        'scope': 'Available interrupted artifacts and recoverable compressed bytes checked against currently observable credentials and generic patterns before text review.',
        'historical_sampler_recovered': False,
        'limits': 'The interrupted in-memory credential sampler is lost. No claim of full historical refreshed-value coverage or native completion. See recovery scan record.'})
dump(session / 'recovery-publication-scan.json', scanned)
dump(session / 'publication-exclusions.json', {'files': [name for name, detail in recovered.items()
    if not detail['gzip_complete'] and (session / name).stat().st_size],
    'reason':'Original interrupted compressed bytes are retained locally with hashes, but damaged undecodable content is withheld from publication. Scanned recovered prefixes are published separately.'})
shutil.rmtree(temporary)
manifest['temporary_auth_home_removed'] = not temporary.exists()
dump(session / 'manifest.json', manifest)
previous = json.loads((session.parent / '05/manifest.json').read_text())
result = {'harness':'codex','domain':'weekly-product','arm':'skill','previous_sessions':5,
          'actual_sessions':2,'cumulative_actual_sessions':7,'sessions':[previous,manifest],
          'state':state,'stop_reason':'infrastructure_or_process_failure',
          'semantic_review':'partial evidence only; native closing session interrupted',
          'source_trajectory':str(REPO / 'evals/runs/workflow-live-2026-09-09/trajectories/codex/weekly-product/skill')}
dump(session.parents[1] / 'trajectory.json', result)
dump(ROOT / 'recovery/recovery-record.json', {'at':utc_now(),'models_launched':0,
    'interrupted_attempt_counts_against_owner_cap':True,'original_trace_bytes_preserved':True,
    'lost_process_cause':'unknown','recovered_streams':recovered,
    'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope':'Preserved partial native output, service state and temporary product/work directories; removed only this attempt\'s temporary authentication home. No generated decision repeated.'})
print(json.dumps({'recovered_attempt_index':6,'native_completion_verified':False,
                  'decision_present':manifest['decision_present'],'remaining_authorized_attempts':2}))
