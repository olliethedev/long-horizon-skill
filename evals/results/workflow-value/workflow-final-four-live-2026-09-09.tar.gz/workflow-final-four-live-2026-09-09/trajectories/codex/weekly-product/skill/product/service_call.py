"""Persist exact service requests/results; never automatically retry effects."""
import json
import pathlib
import subprocess
import sys

root = pathlib.Path('/workspace/product')
label, operation = sys.argv[1:3]
arguments = json.loads(sys.argv[3]) if len(sys.argv) > 3 else None
if '/' in label or label in ('', '.', '..'):
    raise SystemExit('Use a simple unique record label')
intent = root / 'operations' / (label + '.request.json')
with intent.open('x') as stream:
    json.dump({'operation': operation, 'arguments': arguments}, stream, indent=2)
command = ['python3', '/workspace/tools/service.py', operation]
if arguments is not None:
    command.append(json.dumps(arguments))
result = subprocess.run(command, text=True, capture_output=True)
(root / 'operations' / (label + '.response.txt')).write_text(result.stdout)
(root / 'operations' / (label + '.transport.json')).write_text(json.dumps({
    'exit_code': result.returncode, 'stderr': result.stderr}, indent=2))
print(result.stdout, end='')
if result.stderr:
    print(result.stderr, file=sys.stderr, end='')
try:
    payload = json.loads(result.stdout)
except ValueError:
    raise SystemExit('Uncertain response: inspect operations/state before retry')
if result.returncode != 0 or payload.get('ok') is not True:
    raise SystemExit(1)
