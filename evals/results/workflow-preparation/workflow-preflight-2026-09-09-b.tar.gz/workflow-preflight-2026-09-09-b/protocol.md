# Complete-workflow value study

Status: design in progress, September 9, 2026. No new model trial has run. The owner asked to establish whether the complete workflow adds value over a capable agent without the skill. A positive finding is not presumed.

## Existing evidence and the gap

The native-tools study compared one-session recommendations from prepared archives. The earlier September 8 full-cycle prototype also compared baseline and skill across 48 Codex sessions and found no clear outcome advantage. That earlier baseline received substantial process guidance, the runner supplied six checkpoints regardless of actual scheduling, setup was largely prefilled, and hard isolation was incomplete. Preserve both studies; neither becomes a positive result through a new interpretation.

This study asks whether the current skill improves the autonomous management of a responsibility beginning with an ordinary owner request. It uses executed synthetic service effects and genuinely fresh native sessions. The agent creates its own continuing workspace, obtains consequential missing owner facts, chooses objectives, arranges continuation, handles changed evidence and interruptions, and stops or continues according to the actual brief.

## Planned comparison and bounds

Compare the frozen current skill at commit ba483280388ecf7a09aa0d514a05262f46683c5a with no skill. Both arms get the same native harness/model defaults, product facts, initial owner request, available service interfaces and owner-answer source. They start with empty agent-authored memory. Do not supply the baseline with a reconstructed skill, nor withhold normal tool documentation or owner constraints.

The proposed full first study is four domains × three installed native harnesses × two treatments: 24 complete workflow trajectories, forming 12 matched pairs. Cap each trajectory at eight fresh native sessions, for at most 192 sessions. A Codex-first scope would be eight trajectories, at most 64 sessions; the other harnesses remain explicitly unevaluated until run. The run allowance is an evaluation-resource bound, not a product spending limit or a claim about subscription charges. Actual session count depends on chosen schedules and terminal states. Use at most two native model processes concurrently.

Use one predeclared scenario per domain initially. This is exploratory evidence; the unit of comparison is a whole trajectory, not each session. Eight sessions from one chain are not eight independent successes. Do not run extra seeds or modify the skill until the fixed initial study is graded. Repeated independent scenarios are needed before claiming a reliable advantage.

## Domains

- Revenue experiments: choose and expose a page variation, wait for adequate settled-revenue evidence, handle an overlapping revision and a later ledger correction, then act under a bounded optimization brief.
- Weekly product improvement: choose from competing feedback and metrics, deliver and verify a reversible improvement, revise a mistaken benefit claim, preserve the ongoing responsibility when an individual objective finishes, and respect a later owner stop.
- Feedback follow-through: investigate a recurring customer problem, verify the exact affected conditions, recover an uncertain effect, handle an owner-restorable access problem with explicit resumption, and terminate the bounded assignment with retained evidence when supported.
- Post-PR monitoring: distinguish merge from actual exposure, inspect a competing change, verify a justified repair and observation window, and end the bounded monitoring assignment. A control path must allow evidence-backed impossibility without confusing a temporary outage with impossibility.

Events and scoring must be grounded in product facts rather than wording copied from the skill. Each scenario needs multiple reasonable objective choices; choosing the author's favorite implementation is not the success criterion.

## Continuation and owner interaction

Each trajectory has its own clock; both treatments share the same predeclared external event timeline and a 42-day horizon. At a tied timestamp, apply product changes first, then owner instructions, then scheduled work. Events are applied once. Keep every assigned trajectory in the denominator and report censoring separately. The simulated clock advances to the earliest service event, owner event or confirmed agent-scheduled run. A service event changes the world; it does not automatically wake the agent unless a documented subscription exists. Only actual scheduled work, an explicit owner instruction, or an equally available infrastructure recovery policy can launch a fresh session. A note saying return next week cannot create a run.

The initial broad request grants access to a bounded synthetic environment. Consequential facts absent from it are available through a deterministic owner-answer interface. Grade necessary facts obtained, preserved and respected; do not grade interview phrasing, question count or a preferred file layout. Unknown facts remain unknown. Owner answers are identical across arms for equivalent questions, carry no process coaching, and are audited before model trials.

Every session starts with fresh native conversation state and a minimal execution envelope identifying the workspace, simulated time, wake reason, local service and permitted evaluation boundary. Do not repeat task-specific memory instructions or repair the agent's handoff. Only the agent's saved files and independently persisted product/service state carry continuity. The skill treatment additionally gets the explicit skill invocation.

A normal gap caused by failing to schedule is a workflow outcome, not an invitation for the evaluator to rescue the agent. An authentication or harness failure before a decision is a separate infrastructure result. Preserve attempts; never repeat a generated decision for a better score. A trajectory still legitimately active when it hits the session cap is resource-censored and must not be silently scored as successfully complete or as proof of a domain failure.

## Outcomes and grading

Primary results are per-trajectory useful fulfillment, material constraint violations, unsupported consequential claims, and unassisted continuity. A justified ongoing state at the scenario horizon differs from completing a bounded task. An unsupported success claim, lost continuation, duplicate consequential effect, unauthorized mutation or exceeded shared allowance prevents a clean overall pass. A paused responsibility must preserve history and await explicit owner resumption; an inaccessible prerequisite is not automatically impossible.

Report component results separately: setup coverage, action/deployment/outcome verification, agent-authored memory use, correction handling, coordination, operation reconciliation, scheduling, pause/resume, stopping and reporting. Do not let correct formatting or high component totals erase a material failure. Mark inapplicable or unobserved components explicitly.

Product outcomes use independently recorded effects, eligible exposure and task-specific observations. Documentation volume is not benefit. Efficiency reports native token categories, elapsed process time, model sessions, tool calls, owner interventions, and synthetic service consumption separately. Subscription usage or charges remain unknown unless supplied by an actual applicable source.

Before launches, calibrate deterministic checks against known successful and failed trajectories, including plausible-looking false claims. Review the scenario/source contracts independently. Freeze scenario bytes, owner answers, scoring criteria, skill bytes, evaluator sources and native versions before the first main outcome. Conduct semantic review on complete action traces and final/persisted claims, preferably with treatment labels removed; retain source-backed disagreements. Record whether labels remained inferable from file content.

## Isolation and limits

Reuse native harness authentication/trace adapters with isolated temporary homes. The product workspace becomes writable; fixture implementation, private world state, other arms, scoring material and host projects stay outside the agent filesystem. Bind a dedicated local Unix service socket into each trajectory sandbox; the server binds it to that trajectory and accepts no client-supplied arm or state path. Verify wrong-socket and sibling-state inaccessibility before launches. Host networking remains available for native model transport: do not claim a general network allowlist or prevention of arbitrary external requests from filesystem isolation alone. External product/service use remains prohibited by the evaluation instructions; inspect traces separately. Private model authentication never enters published artifacts. Verify boundaries before any model run and preserve all failures.

This study can establish or fail to establish an advantage within its tested simulated workflows. It cannot establish actual revenue lift, arbitrary production feature quality, real service reliability over months, or general statistical superiority. The existing dense-history tests remain separate evidence about retrieval scale. A later real elapsed-time pilot needs a concrete product and its own owner brief; this request does not authorize real customer experiments or production changes.

## Final local installation

The owner additionally requested that, after evaluation and any evidence-supported improvements, the final validated skill be installed locally for Codex, Claude Code and Antigravity. Verify each installed harness's actual discovery locations and verify identical final bundle contents. Preserve unrelated skills and existing customizations. This authorizes local skill installation, not creation of a live content task in better-stack-web. The owner asked how to start such a task; its analytics, publishing authority and schedule belong to that later setup conversation.
