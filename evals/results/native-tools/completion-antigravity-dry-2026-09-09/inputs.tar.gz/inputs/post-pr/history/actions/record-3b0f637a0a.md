# record-3b0f637a0a: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-4f54812b4a.11.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-28: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-ee58e8a3de. Deployment/exposure: 2026-03-31, receipt record-a59ae40629; 5% of eligible production accounts. The original observation is history/evidence/record-bc4cc0bb11.md. Later review: history/evidence/record-dbab3ab3b7.md.
Disposition recorded after the first window: Rolled back 2026-04-08, receipt record-b1c96bdcc6, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
