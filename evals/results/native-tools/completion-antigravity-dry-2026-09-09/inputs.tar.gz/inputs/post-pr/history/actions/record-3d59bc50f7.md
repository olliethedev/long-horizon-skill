# record-3d59bc50f7: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-df7fc22939.14.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-28: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-6c2670479e. Deployment/exposure: 2026-03-03, receipt record-474ae29a20; 15% of eligible production accounts. The original observation is history/evidence/record-c9ae825020.md. Later review: history/evidence/record-a748bf6542.md.
Disposition recorded after the first window: Rolled back 2026-03-15, receipt record-6645d3d653, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
