# record-27dcb851b6: queue retry fix
Alias used in the design review: Lantern. Local variant: record-5824296480.14.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-23: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-7d2a97c408. Deployment/exposure: 2026-06-26, receipt record-8b305c0485; 15% of eligible production accounts. The original observation is history/evidence/record-e516089157.md. Later review: history/evidence/record-991b565f71.md.
Disposition recorded after the first window: Disabled 2026-07-11, receipt record-6bad66ef00, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
