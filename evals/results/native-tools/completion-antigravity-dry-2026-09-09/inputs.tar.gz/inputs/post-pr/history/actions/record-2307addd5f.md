# record-2307addd5f: timeout report
Alias used in the design review: shared worker. Local variant: record-df7fc22939.11.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-a1fe7a9797. Deployment/exposure: 2026-08-08, receipt record-fc8c012895; 5% of eligible production accounts. The original observation is history/evidence/record-2d7f452666.md. Later review: history/evidence/record-3305eb3028.md.
Disposition recorded after the first window: Rolled back 2026-08-16, receipt record-5974da56a3, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
