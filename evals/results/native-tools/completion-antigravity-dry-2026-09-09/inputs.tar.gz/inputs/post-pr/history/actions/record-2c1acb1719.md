# record-2c1acb1719: worker routing
Alias used in the design review: queue retry fix. Local variant: record-df7fc22939.9.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-05: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-0ba4a1611e. Deployment/exposure: 2026-07-08, receipt record-d43bed1940; 25% of eligible production accounts. The original observation is history/evidence/record-8122958371.md. Later review: history/evidence/record-da0b0e2027.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-17; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
