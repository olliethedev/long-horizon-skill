# record-2bee9ce08b: timeout report
Alias used in the design review: shared worker. Local variant: record-e5c0a618bf.0.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-28: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-79c3a83cbe. Deployment/exposure: 2026-05-31, receipt record-cb396b7744; 10% of eligible production accounts. The original observation is history/evidence/record-640ea202b6.md. Later review: history/evidence/record-c3f3d5ec7a.md.
Disposition recorded after the first window: Disabled 2026-06-15, receipt record-27c2a1838a, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
