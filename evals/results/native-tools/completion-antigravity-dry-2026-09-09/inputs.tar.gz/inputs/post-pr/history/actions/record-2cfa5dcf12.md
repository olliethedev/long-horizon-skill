# record-2cfa5dcf12: queue retry fix
Alias used in the design review: Lantern. Local variant: record-f39df68ace.14.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-07: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-bb12e928a8. Deployment/exposure: 2026-05-10, receipt record-29e7a7a69f; 5% of eligible production accounts. The original observation is history/evidence/record-9d8229d252.md. Later review: history/evidence/record-388d5fe782.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-23; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
