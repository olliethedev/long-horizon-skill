# record-33b23043fd: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-e5c0a618bf.12.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-21: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-eeec4226ce. Deployment/exposure: 2026-05-24, receipt record-77032736d5; 25% of eligible production accounts. The original observation is history/evidence/record-7327038368.md. Later review: history/evidence/record-e82ff88198.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
