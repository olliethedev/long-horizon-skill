# record-330f4d94a1: shared worker
Alias used in the design review: retry dashboard. Local variant: record-4f54812b4a.3.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-08: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-f39e397922. Deployment/exposure: 2026-03-11, receipt record-eb60751613; 5% of eligible production accounts. The original observation is history/evidence/record-6726476952.md. Later review: history/evidence/record-f00ba4339b.md.
Disposition recorded after the first window: Rolled back 2026-03-19, receipt record-d5fdf8f3f4, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
