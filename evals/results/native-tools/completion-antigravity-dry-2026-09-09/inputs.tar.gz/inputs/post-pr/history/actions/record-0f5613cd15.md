# record-0f5613cd15: worker routing
Alias used in the design review: queue retry fix. Local variant: record-4f54812b4a.15.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-08: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-8b65c57510. Deployment/exposure: 2026-08-11, receipt record-29111c5fc1; 20% of eligible production accounts. The original observation is history/evidence/record-813f8a936f.md. Later review: history/evidence/record-6e7f328f2e.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
