# record-09e761ea18: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-e5c0a618bf.10.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-f943075353. Deployment/exposure: 2026-07-25, receipt record-173052fc59; 10% of eligible production accounts. The original observation is history/evidence/record-c43ff0a1ff.md. Later review: history/evidence/record-51ad8283cc.md.
Disposition recorded after the first window: Disabled 2026-08-05, receipt record-ac2d685743, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
