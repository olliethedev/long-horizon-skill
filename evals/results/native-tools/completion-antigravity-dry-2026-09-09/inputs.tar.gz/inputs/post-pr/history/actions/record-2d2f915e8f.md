# record-2d2f915e8f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-c152fdc842.6.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-26: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-b0b7def092. Deployment/exposure: 2026-05-29, receipt record-47f55784ee; 25% of eligible production accounts. The original observation is history/evidence/record-cd82e3391c.md. Later review: history/evidence/record-d386e8c79c.md.
Disposition recorded after the first window: Rolled back 2026-06-10, receipt record-ddfa35e9d1, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
