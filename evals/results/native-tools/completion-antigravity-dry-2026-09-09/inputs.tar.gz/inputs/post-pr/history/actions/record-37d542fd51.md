# record-37d542fd51: worker routing
Alias used in the design review: queue retry fix. Local variant: record-e5c0a618bf.1.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-08: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-741fa667fb. Deployment/exposure: 2026-03-11, receipt record-16404262d3; 5% of eligible production accounts. The original observation is history/evidence/record-4332704ed1.md. Later review: history/evidence/record-030af0d550.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
