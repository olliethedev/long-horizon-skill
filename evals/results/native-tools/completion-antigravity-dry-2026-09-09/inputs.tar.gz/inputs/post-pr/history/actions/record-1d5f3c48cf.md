# record-1d5f3c48cf: worker routing
Alias used in the design review: queue retry fix. Local variant: record-e5c0a618bf.1.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-31: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-566089c305. Deployment/exposure: 2026-08-03, receipt record-95ecda11ec; 5% of eligible production accounts. The original observation is history/evidence/record-0c706520e5.md. Later review: history/evidence/record-94f8aea584.md.
Disposition recorded after the first window: Disabled 2026-08-14, receipt record-5f356e0307, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
