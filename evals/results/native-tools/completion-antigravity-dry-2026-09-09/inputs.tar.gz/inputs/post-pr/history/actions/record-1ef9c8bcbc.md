# record-1ef9c8bcbc: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-f39df68ace.3.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-ec8fc385f1. Deployment/exposure: 2026-03-23, receipt record-fdcaee88a8; 15% of eligible production accounts. The original observation is history/evidence/record-b161e41dfa.md. Later review: history/evidence/record-8481ad9adc.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
