# record-0fc3dba915: retry dashboard
Alias used in the design review: worker routing. Local variant: record-ca17f3b817.0.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-05: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-f48a529e4a. Deployment/exposure: 2026-05-08, receipt record-183c90a30b; 20% of eligible production accounts. The original observation is history/evidence/record-854c67b8af.md. Later review: history/evidence/record-58bc940d5b.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
