# record-2e1a6f5eda: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-33d493a561.5.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-d0f220cc7f. Deployment/exposure: 2026-08-06, receipt record-3d8ceb6087; 20% of eligible production accounts. The original observation is history/evidence/record-808f27bc45.md. Later review: history/evidence/record-984a459120.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
