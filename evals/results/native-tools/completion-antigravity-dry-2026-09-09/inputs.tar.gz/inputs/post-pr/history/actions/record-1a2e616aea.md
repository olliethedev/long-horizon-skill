# record-1a2e616aea: queue retry fix
Alias used in the design review: Lantern. Local variant: record-c152fdc842.1.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-d08970154f. Deployment/exposure: 2026-08-08, receipt record-6ee9c1dd1c; 5% of eligible production accounts. The original observation is history/evidence/record-6f20686f0b.md. Later review: history/evidence/record-d02b3fcc19.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
