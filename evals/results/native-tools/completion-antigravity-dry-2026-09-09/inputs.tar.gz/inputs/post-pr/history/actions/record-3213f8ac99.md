# record-3213f8ac99: retry dashboard
Alias used in the design review: worker routing. Local variant: record-f39df68ace.11.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-41e8ced93f. Deployment/exposure: 2026-02-19, receipt record-7d907dd98f; 5% of eligible production accounts. The original observation is history/evidence/record-f84499e4dc.md. Later review: history/evidence/record-df37820481.md.
Disposition recorded after the first window: Disabled 2026-03-06, receipt record-74203ef797, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
