# record-224db687c6: worker routing
Alias used in the design review: queue retry fix. Local variant: record-e5c0a618bf.16.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-26: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-0989dfcdd6. Deployment/exposure: 2026-07-29, receipt record-7d0a70f854; 5% of eligible production accounts. The original observation is history/evidence/record-558fcf4847.md. Later review: history/evidence/record-36a926ace0.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
