# record-1e5c1c7267: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-4f54812b4a.8.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-05: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-99fd9ca2da. Deployment/exposure: 2026-06-08, receipt record-7f0e87b355; 25% of eligible production accounts. The original observation is history/evidence/record-c94fed6682.md. Later review: history/evidence/record-9d86e879ac.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
