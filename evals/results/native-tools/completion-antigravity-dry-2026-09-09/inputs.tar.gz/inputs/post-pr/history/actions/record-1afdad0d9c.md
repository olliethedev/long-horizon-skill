# record-1afdad0d9c: worker routing
Alias used in the design review: queue retry fix. Local variant: record-4f54812b4a.10.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-06: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-8410ed1023. Deployment/exposure: 2026-06-09, receipt record-6dbb0eda78; 5% of eligible production accounts. The original observation is history/evidence/record-d3aabb8023.md. Later review: history/evidence/record-e6d032a2a6.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
