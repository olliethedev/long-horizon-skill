# record-0b9e679b8a: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-c152fdc842.8.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-15969aa309. Deployment/exposure: 2026-04-08, receipt record-4ef63e1e27; 20% of eligible production accounts. The original observation is history/evidence/record-5160df9028.md. Later review: history/evidence/record-8c4c31970f.md.
Disposition recorded after the first window: Disabled 2026-04-23, receipt record-ea4c2124e0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
