# record-1a8587a9bd: worker routing
Alias used in the design review: queue retry fix. Local variant: record-f39df68ace.8.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-a32bdf3d10. Deployment/exposure: 2026-07-27, receipt record-ad51896f8a; 20% of eligible production accounts. The original observation is history/evidence/record-01c323d519.md. Later review: history/evidence/record-5fc9adf4cb.md.
Disposition recorded after the first window: Disabled 2026-08-07, receipt record-b26b6ef87b, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
