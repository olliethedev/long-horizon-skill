# record-0695bc772d: worker routing
Alias used in the design review: queue retry fix. Local variant: record-c152fdc842.3.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-24: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-475b3dfc4e. Deployment/exposure: 2026-04-27, receipt record-aab5408361; 15% of eligible production accounts. The original observation is history/evidence/record-b987c6b0ea.md. Later review: history/evidence/record-61c49d646e.md.
Disposition recorded after the first window: Disabled 2026-05-08, receipt record-c576e87ed2, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
