# record-0e57c626fd: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-33d493a561.0.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-15: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-cd5ea7b43c. Deployment/exposure: 2026-03-18, receipt record-5014dc5344; 15% of eligible production accounts. The original observation is history/evidence/record-f8c8115e50.md. Later review: history/evidence/record-69cc3e6100.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
