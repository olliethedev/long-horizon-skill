# record-2a8511b7a2: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-5824296480.6.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-04: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-6a3b08b5f9. Deployment/exposure: 2026-05-07, receipt record-1e9a1a3223; 15% of eligible production accounts. The original observation is history/evidence/record-f36188c3cf.md. Later review: history/evidence/record-10f8f0b0f2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-20; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
