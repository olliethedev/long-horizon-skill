# record-0767f4b92b: worker routing
Alias used in the design review: queue retry fix. Local variant: record-3158237b52.8.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-12: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-ea35175f2a. Deployment/exposure: 2026-04-15, receipt record-8993aa2851; 5% of eligible production accounts. The original observation is history/evidence/record-29c1e54e12.md. Later review: history/evidence/record-823fa2990a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
