# record-3346f87f2b: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-f39df68ace.1.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-21: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-763d616142. Deployment/exposure: 2026-04-24, receipt record-cef4ccb166; 25% of eligible production accounts. The original observation is history/evidence/record-bb36e58396.md. Later review: history/evidence/record-965da720e6.md.
Disposition recorded after the first window: Rolled back 2026-05-06, receipt record-7a0ddde7a2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
