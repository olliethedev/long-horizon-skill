# record-142336abd1: retry dashboard
Alias used in the design review: worker routing. Local variant: record-5824296480.0.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-11: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-ca318d4637. Deployment/exposure: 2026-05-14, receipt record-272f7abb81; 25% of eligible production accounts. The original observation is history/evidence/record-986b9a69aa.md. Later review: history/evidence/record-77506800ef.md.
Disposition recorded after the first window: Disabled 2026-05-29, receipt record-09e78ae342, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
