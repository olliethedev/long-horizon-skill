# record-329b31d93f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.8.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-14: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-c3351f2229. Deployment/exposure: 2026-04-17, receipt record-2b32dff8b1; 15% of eligible production accounts. The original observation is history/evidence/record-fa77549f8d.md. Later review: history/evidence/record-6fa4aae544.md.
Disposition recorded after the first window: Rolled back 2026-04-29, receipt record-80f41d5dd7, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
