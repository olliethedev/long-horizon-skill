# record-31e5aae8f0: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-df7fc22939.12.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-01: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-085558b516. Deployment/exposure: 2026-04-04, receipt record-d41a8403ef; 25% of eligible production accounts. The original observation is history/evidence/record-29b838567e.md. Later review: history/evidence/record-6432c1065d.md.
Disposition recorded after the first window: Disabled 2026-04-19, receipt record-c9d1e6bf32, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
