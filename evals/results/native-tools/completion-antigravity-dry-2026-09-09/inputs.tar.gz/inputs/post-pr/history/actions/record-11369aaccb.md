# record-11369aaccb: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-e5c0a618bf.0.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-17: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-405220093a. Deployment/exposure: 2026-05-20, receipt record-73a884edf8; 5% of eligible production accounts. The original observation is history/evidence/record-bad3be46d5.md. Later review: history/evidence/record-74ed236435.md.
Disposition recorded after the first window: Disabled 2026-06-04, receipt record-581d761b3c, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
