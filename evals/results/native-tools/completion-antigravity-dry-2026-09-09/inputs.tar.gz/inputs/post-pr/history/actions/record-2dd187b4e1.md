# record-2dd187b4e1: worker routing
Alias used in the design review: queue retry fix. Local variant: record-df7fc22939.1.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-b80b5925a5. Deployment/exposure: 2026-04-08, receipt record-463d9c5823; 20% of eligible production accounts. The original observation is history/evidence/record-96f57e4314.md. Later review: history/evidence/record-df492c1490.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
