# record-26781eca6c: worker routing
Alias used in the design review: queue retry fix. Local variant: record-e5c0a618bf.5.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-29: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-a355e91dbb. Deployment/exposure: 2026-04-01, receipt record-259edb8ebb; 10% of eligible production accounts. The original observation is history/evidence/record-8b38ff2fc0.md. Later review: history/evidence/record-345f7803c4.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
