# record-1a2ae7d120: timeout report
Alias used in the design review: shared worker. Local variant: record-4f54812b4a.4.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-07: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-e25b7fa48b. Deployment/exposure: 2026-05-10, receipt record-a006be6740; 5% of eligible production accounts. The original observation is history/evidence/record-e9a68856a5.md. Later review: history/evidence/record-af716af20e.md.
Disposition recorded after the first window: Disabled 2026-05-25, receipt record-995620e550, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
