# record-1a43e808cb: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.13.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-16: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-4491117820. Deployment/exposure: 2026-06-19, receipt record-ac69c2a985; 5% of eligible production accounts. The original observation is history/evidence/record-2cb18ce3d4.md. Later review: history/evidence/record-1b21f851bc.md.
Disposition recorded after the first window: Rolled back 2026-07-01, receipt record-d18a5dafcd, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
