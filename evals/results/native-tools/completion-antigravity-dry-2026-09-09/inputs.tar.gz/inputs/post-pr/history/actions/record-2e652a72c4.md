# record-2e652a72c4: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-3158237b52.5.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-06: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-3b3728e8b5. Deployment/exposure: 2026-05-09, receipt record-0ffba3d08e; 25% of eligible production accounts. The original observation is history/evidence/record-003b760633.md. Later review: history/evidence/record-dd639e3813.md.
Disposition recorded after the first window: Disabled 2026-05-24, receipt record-4248bcbcf5, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
