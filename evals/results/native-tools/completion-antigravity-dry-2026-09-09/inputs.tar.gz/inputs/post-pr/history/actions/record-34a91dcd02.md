# record-34a91dcd02: shared worker
Alias used in the design review: retry dashboard. Local variant: record-f39df68ace.13.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-21: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-8c0199783c. Deployment/exposure: 2026-02-24, receipt record-d06e8296ac; 5% of eligible production accounts. The original observation is history/evidence/record-8f9cd469a1.md. Later review: history/evidence/record-e9e0a0eb05.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
