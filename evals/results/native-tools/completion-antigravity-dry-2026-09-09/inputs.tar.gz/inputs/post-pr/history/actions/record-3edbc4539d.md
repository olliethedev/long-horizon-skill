# record-3edbc4539d: queue retry fix
Alias used in the design review: Lantern. Local variant: record-c152fdc842.6.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-15: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-649e644472. Deployment/exposure: 2026-04-18, receipt record-77661396bc; 20% of eligible production accounts. The original observation is history/evidence/record-d7c80e9480.md. Later review: history/evidence/record-987885224e.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
