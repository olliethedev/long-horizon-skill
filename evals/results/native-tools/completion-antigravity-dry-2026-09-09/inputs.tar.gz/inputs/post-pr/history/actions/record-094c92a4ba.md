# record-094c92a4ba: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-5824296480.10.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-65fad77b8a. Deployment/exposure: 2026-06-27, receipt record-50d6550ace; 20% of eligible production accounts. The original observation is history/evidence/record-255162487b.md. Later review: history/evidence/record-72a1e5e5c7.md.
Disposition recorded after the first window: Disabled 2026-07-08, receipt record-ab034b1754, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
