# record-0a741e38ae: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-f39df68ace.16.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-22: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-fb6add8b37. Deployment/exposure: 2026-06-25, receipt record-824a3077b1; 10% of eligible production accounts. The original observation is history/evidence/record-6faa675ef5.md. Later review: history/evidence/record-b5bd447eb0.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-04; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
