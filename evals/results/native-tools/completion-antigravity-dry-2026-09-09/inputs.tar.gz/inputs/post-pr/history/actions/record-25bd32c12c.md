# record-25bd32c12c: queue retry fix
Alias used in the design review: Lantern. Local variant: record-e5c0a618bf.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-29: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-5f0bef094a. Deployment/exposure: 2026-07-02, receipt record-5af38775cb; 20% of eligible production accounts. The original observation is history/evidence/record-8bdb8914d5.md. Later review: history/evidence/record-2a381b382b.md.
Disposition recorded after the first window: Rolled back 2026-07-10, receipt record-76cc86df73, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
