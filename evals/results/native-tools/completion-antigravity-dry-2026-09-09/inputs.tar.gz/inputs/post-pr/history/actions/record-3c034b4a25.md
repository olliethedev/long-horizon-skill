# record-3c034b4a25: retry dashboard
Alias used in the design review: worker routing. Local variant: record-5824296480.10.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-23: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-d5c4f95311. Deployment/exposure: 2026-03-26, receipt record-9641c213b0; 5% of eligible production accounts. The original observation is history/evidence/record-83439446f9.md. Later review: history/evidence/record-63a7f5d174.md.
Disposition recorded after the first window: Disabled 2026-04-10, receipt record-15eeb45e5a, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
