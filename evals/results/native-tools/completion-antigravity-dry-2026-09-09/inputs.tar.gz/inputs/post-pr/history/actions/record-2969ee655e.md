# record-2969ee655e: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-df7fc22939.6.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-23: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-57aa29507d. Deployment/exposure: 2026-05-26, receipt record-75923ee6ff; 10% of eligible production accounts. The original observation is history/evidence/record-4ab7ac039d.md. Later review: history/evidence/record-a51916f508.md.
Disposition recorded after the first window: Rolled back 2026-06-03, receipt record-6e05e0e948, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
