# record-103d0e71bc: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.13.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-59058b28fa. Deployment/exposure: 2026-04-05, receipt record-4a041fca3e; 5% of eligible production accounts. The original observation is history/evidence/record-ee90aaca47.md. Later review: history/evidence/record-4bdf3e0a7a.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
