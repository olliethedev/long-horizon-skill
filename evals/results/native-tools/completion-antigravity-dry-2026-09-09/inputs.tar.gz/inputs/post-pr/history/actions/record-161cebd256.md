# record-161cebd256: shared worker
Alias used in the design review: retry dashboard. Local variant: record-33d493a561.16.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-24: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-bbb6326fb6. Deployment/exposure: 2026-05-27, receipt record-fc726dc62a; 15% of eligible production accounts. The original observation is history/evidence/record-cd7f27462a.md. Later review: history/evidence/record-4d955912e7.md.
Disposition recorded after the first window: Rolled back 2026-06-04, receipt record-de07c1b7d1, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
