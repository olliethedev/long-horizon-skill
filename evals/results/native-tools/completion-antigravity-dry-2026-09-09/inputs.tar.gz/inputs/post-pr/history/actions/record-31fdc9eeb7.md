# record-31fdc9eeb7: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-c152fdc842.3.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-15: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-af4ef608eb. Deployment/exposure: 2026-07-18, receipt record-4f11c7fdc6; 25% of eligible production accounts. The original observation is history/evidence/record-63b247e524.md. Later review: history/evidence/record-e26ea7e7cb.md.
Disposition recorded after the first window: Disabled 2026-08-02, receipt record-072d743238, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
