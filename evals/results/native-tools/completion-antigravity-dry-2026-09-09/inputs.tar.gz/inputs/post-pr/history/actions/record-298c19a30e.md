# record-298c19a30e: queue retry fix
Alias used in the design review: Lantern. Local variant: record-c152fdc842.8.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-20: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-cc6fc7ebb6. Deployment/exposure: 2026-04-23, receipt record-762bf3e347; 20% of eligible production accounts. The original observation is history/evidence/record-b9bdcbc03b.md. Later review: history/evidence/record-7e8339a58a.md.
Disposition recorded after the first window: Rolled back 2026-05-05, receipt record-453a91bd6c, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
