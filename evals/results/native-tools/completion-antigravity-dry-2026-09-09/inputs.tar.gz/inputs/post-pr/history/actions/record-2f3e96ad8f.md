# record-2f3e96ad8f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-df7fc22939.11.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-08: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-444cb68e0c. Deployment/exposure: 2026-04-11, receipt record-26bd743c30; 10% of eligible production accounts. The original observation is history/evidence/record-635e14afa4.md. Later review: history/evidence/record-d6306c9cc0.md.
Disposition recorded after the first window: Disabled 2026-04-26, receipt record-421a04c0ad, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
