# record-064eea0cb3: retry dashboard
Alias used in the design review: worker routing. Local variant: record-f39df68ace.0.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-30: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-a0479b0806. Deployment/exposure: 2026-08-02, receipt record-cb87e4405a; 25% of eligible production accounts. The original observation is history/evidence/record-0ea8853914.md. Later review: history/evidence/record-0cfb035047.md.
Disposition recorded after the first window: Rolled back 2026-08-10, receipt record-6369e6b09e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
