# record-13da2efc61: queue retry fix
Alias used in the design review: Lantern. Local variant: record-5824296480.4.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-19: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-56b8c6be09. Deployment/exposure: 2026-03-22, receipt record-738b94923c; 10% of eligible production accounts. The original observation is history/evidence/record-84ebddbb9a.md. Later review: history/evidence/record-a40160ef65.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-31; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
