# record-2afc29e005: shared worker
Alias used in the design review: retry dashboard. Local variant: record-3158237b52.9.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-14: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-7ebaa053c5. Deployment/exposure: 2026-03-17, receipt record-23573f028d; 10% of eligible production accounts. The original observation is history/evidence/record-587db6d5ef.md. Later review: history/evidence/record-1106f1a98c.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-26; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
