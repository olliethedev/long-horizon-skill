# record-1beaf7509a: queue retry fix
Alias used in the design review: Lantern. Local variant: record-4f54812b4a.16.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-25: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-88684c9cf1. Deployment/exposure: 2026-06-28, receipt record-9c8355d4f2; 25% of eligible production accounts. The original observation is history/evidence/record-dd9d283f48.md. Later review: history/evidence/record-9b010a82ec.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-11; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
