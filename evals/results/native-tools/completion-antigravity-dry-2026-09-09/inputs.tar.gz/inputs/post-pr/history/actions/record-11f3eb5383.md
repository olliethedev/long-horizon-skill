# record-11f3eb5383: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-ca17f3b817.16.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-03: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-9fc799cd4d. Deployment/exposure: 2026-07-06, receipt record-c6f3bd4db9; 15% of eligible production accounts. The original observation is history/evidence/record-dcb3065788.md. Later review: history/evidence/record-15116e7a93.md.
Disposition recorded after the first window: Rolled back 2026-07-14, receipt record-89a0c8f821, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
