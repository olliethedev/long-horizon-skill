# record-28cfa06a24: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-f39df68ace.14.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-31: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-eb782fc370. Deployment/exposure: 2026-04-03, receipt record-5507c466b5; 20% of eligible production accounts. The original observation is history/evidence/record-f2337808e0.md. Later review: history/evidence/record-7f26ab2b18.md.
Disposition recorded after the first window: Rolled back 2026-04-11, receipt record-b50b0551c7, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
