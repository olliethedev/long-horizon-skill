# record-105fd8817d: timeout report
Alias used in the design review: shared worker. Local variant: record-3158237b52.1.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-18: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-5ece896541. Deployment/exposure: 2026-02-21, receipt record-59be6e58a1; 15% of eligible production accounts. The original observation is history/evidence/record-31a25f9df1.md. Later review: history/evidence/record-d5342482d9.md.
Disposition recorded after the first window: Rolled back 2026-03-05, receipt record-2a982a69fd, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
