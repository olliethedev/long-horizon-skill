# record-0c8b29de1b: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-ca17f3b817.0.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-26: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-a5538086d8. Deployment/exposure: 2026-06-29, receipt record-f09f493a30; 5% of eligible production accounts. The original observation is history/evidence/record-85ce7531ce.md. Later review: history/evidence/record-15f6488223.md.
Disposition recorded after the first window: Rolled back 2026-07-07, receipt record-bdcda0a58c, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
