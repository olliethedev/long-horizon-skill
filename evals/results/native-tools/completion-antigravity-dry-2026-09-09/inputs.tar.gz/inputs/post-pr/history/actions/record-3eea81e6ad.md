# record-3eea81e6ad: timeout report
Alias used in the design review: shared worker. Local variant: record-c152fdc842.14.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-25: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-ca3a5a8b47. Deployment/exposure: 2026-03-28, receipt record-3c3024658b; 15% of eligible production accounts. The original observation is history/evidence/record-c71e9b4635.md. Later review: history/evidence/record-b480b573c0.md.
Disposition recorded after the first window: Rolled back 2026-04-05, receipt record-874b1b09f8, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
