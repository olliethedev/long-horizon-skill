# record-38cb4fc16f: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-5824296480.8.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-26: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-05a18d5d1b. Deployment/exposure: 2026-07-29, receipt record-7c4388aa62; 5% of eligible production accounts. The original observation is history/evidence/record-1c428db9e8.md. Later review: history/evidence/record-5dc5da5b26.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
