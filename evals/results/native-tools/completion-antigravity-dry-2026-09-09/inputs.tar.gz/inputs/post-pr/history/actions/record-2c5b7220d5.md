# record-2c5b7220d5: worker routing
Alias used in the design review: queue retry fix. Local variant: record-33d493a561.1.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-03: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-4a090d6864. Deployment/exposure: 2026-05-06, receipt record-a5be585b04; 10% of eligible production accounts. The original observation is history/evidence/record-821a775b13.md. Later review: history/evidence/record-c76201f658.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
