# record-2c08d42bdd: retry dashboard
Alias used in the design review: worker routing. Local variant: record-f39df68ace.8.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-07: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-9006e23f25. Deployment/exposure: 2026-05-10, receipt record-a49a017952; 5% of eligible production accounts. The original observation is history/evidence/record-bd87e6ed6c.md. Later review: history/evidence/record-73a0b6c010.md.
Disposition recorded after the first window: Rolled back 2026-05-22, receipt record-93bf1e79ed, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
