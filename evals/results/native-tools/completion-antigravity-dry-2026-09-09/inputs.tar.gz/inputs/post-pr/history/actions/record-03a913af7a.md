# record-03a913af7a: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-e5c0a618bf.8.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-06: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-e6f8ad8881. Deployment/exposure: 2026-06-09, receipt record-47e05bb433; 5% of eligible production accounts. The original observation is history/evidence/record-71fc2990ce.md. Later review: history/evidence/record-09ac3dfee1.md.
Disposition recorded after the first window: Disabled 2026-06-24, receipt record-7a3cbff8cf, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
