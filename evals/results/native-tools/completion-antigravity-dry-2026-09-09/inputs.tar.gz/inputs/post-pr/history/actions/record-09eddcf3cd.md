# record-09eddcf3cd: timeout report
Alias used in the design review: shared worker. Local variant: record-ca17f3b817.6.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-03: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-63603e55cc. Deployment/exposure: 2026-03-06, receipt record-8e2c7c3ac3; 5% of eligible production accounts. The original observation is history/evidence/record-5a717c007f.md. Later review: history/evidence/record-af0fac509d.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
