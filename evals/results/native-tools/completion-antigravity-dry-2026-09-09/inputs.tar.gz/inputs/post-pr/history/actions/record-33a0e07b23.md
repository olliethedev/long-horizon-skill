# record-33a0e07b23: worker routing
Alias used in the design review: queue retry fix. Local variant: record-5824296480.12.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-08: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-059a2ab05b. Deployment/exposure: 2026-05-11, receipt record-134f79762f; 10% of eligible production accounts. The original observation is history/evidence/record-1bacccfc30.md. Later review: history/evidence/record-b506de0df9.md.
Disposition recorded after the first window: Disabled 2026-05-22, receipt record-1b23616608, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
