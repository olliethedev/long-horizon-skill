# record-2ba2a14bb2: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-e5c0a618bf.3.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-26: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-0fed92f0c6. Deployment/exposure: 2026-03-01, receipt record-d918979518; 5% of eligible production accounts. The original observation is history/evidence/record-8c71dc0ad9.md. Later review: history/evidence/record-6a095944b1.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
