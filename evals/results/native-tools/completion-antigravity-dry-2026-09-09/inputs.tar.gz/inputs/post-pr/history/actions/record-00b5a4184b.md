# record-00b5a4184b: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-df7fc22939.2.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-03: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-f411e6f46d. Deployment/exposure: 2026-03-06, receipt record-24bd0dc52e; 5% of eligible production accounts. The original observation is history/evidence/record-28d1176415.md. Later review: history/evidence/record-c46128d776.md.
Disposition recorded after the first window: Rolled back 2026-03-14, receipt record-727fae67e2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
