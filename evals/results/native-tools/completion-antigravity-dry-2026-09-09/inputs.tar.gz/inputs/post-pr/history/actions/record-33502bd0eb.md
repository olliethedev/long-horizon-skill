# record-33502bd0eb: worker routing
Alias used in the design review: queue retry fix. Local variant: record-ca17f3b817.15.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-17: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-54897c563e. Deployment/exposure: 2026-07-20, receipt record-9e9a39627e; 10% of eligible production accounts. The original observation is history/evidence/record-aa67ceeefb.md. Later review: history/evidence/record-866e2554fc.md.
Disposition recorded after the first window: Disabled 2026-07-31, receipt record-0648122ebd, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
