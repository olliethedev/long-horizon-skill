# record-13a2c836d4: retry dashboard
Alias used in the design review: worker routing. Local variant: record-4f54812b4a.16.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-04: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-f806c8a000. Deployment/exposure: 2026-05-07, receipt record-90caaddd6c; 15% of eligible production accounts. The original observation is history/evidence/record-a459ddf70e.md. Later review: history/evidence/record-f962c9d33c.md.
Disposition recorded after the first window: Disabled 2026-05-18, receipt record-b4b10fa671, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
