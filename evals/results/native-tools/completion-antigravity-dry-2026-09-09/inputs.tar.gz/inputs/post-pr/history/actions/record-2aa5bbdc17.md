# record-2aa5bbdc17: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-c152fdc842.10.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-16: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-db7b593930. Deployment/exposure: 2026-07-19, receipt record-fb6220973a; 5% of eligible production accounts. The original observation is history/evidence/record-64ef662e41.md. Later review: history/evidence/record-7e65dc5b77.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
