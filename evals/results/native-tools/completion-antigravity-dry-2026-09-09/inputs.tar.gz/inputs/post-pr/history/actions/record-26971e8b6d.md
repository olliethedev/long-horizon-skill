# record-26971e8b6d: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-5824296480.15.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-21: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-7e2588d934. Deployment/exposure: 2026-05-24, receipt record-80a7777463; 25% of eligible production accounts. The original observation is history/evidence/record-107df32036.md. Later review: history/evidence/record-234cee4d4d.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
