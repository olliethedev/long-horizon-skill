# record-0b425c99b6: shared worker
Alias used in the design review: retry dashboard. Local variant: record-5824296480.7.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-18: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-2fe70462be. Deployment/exposure: 2026-07-21, receipt record-748514a7ec; 15% of eligible production accounts. The original observation is history/evidence/record-e487e0c4f2.md. Later review: history/evidence/record-f804ac8a5f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
