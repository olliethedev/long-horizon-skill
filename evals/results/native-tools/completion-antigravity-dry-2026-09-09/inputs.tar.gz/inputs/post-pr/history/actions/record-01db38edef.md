# record-01db38edef: worker routing
Alias used in the design review: queue retry fix. Local variant: record-ca17f3b817.8.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-21: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-85c21fd03f. Deployment/exposure: 2026-02-24, receipt record-5a335305f0; 5% of eligible production accounts. The original observation is history/evidence/record-956b818b06.md. Later review: history/evidence/record-0f24edef00.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
