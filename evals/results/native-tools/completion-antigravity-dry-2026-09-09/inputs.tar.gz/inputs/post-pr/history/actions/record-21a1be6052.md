# record-21a1be6052: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-c152fdc842.11.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-03: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-dd6344835b. Deployment/exposure: 2026-05-06, receipt record-cfa18120d5; 10% of eligible production accounts. The original observation is history/evidence/record-77ce7b0356.md. Later review: history/evidence/record-01d6d322d0.md.
Disposition recorded after the first window: Disabled 2026-05-17, receipt record-15812a06d0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
