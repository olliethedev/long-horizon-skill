# record-3e53d2e7b5: queue retry fix
Alias used in the design review: Lantern. Local variant: record-3158237b52.4.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-16863cdb18. Deployment/exposure: 2026-04-05, receipt record-cdef208442; 5% of eligible production accounts. The original observation is history/evidence/record-77faafe2a3.md. Later review: history/evidence/record-f28f0e2b9c.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-18; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
