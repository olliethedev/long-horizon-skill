# record-3c121f4e84: timeout report
Alias used in the design review: shared worker. Local variant: record-f39df68ace.5.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-05: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-695fb6cb52. Deployment/exposure: 2026-05-08, receipt record-74048c4d45; 20% of eligible production accounts. The original observation is history/evidence/record-e6efc9d8f0.md. Later review: history/evidence/record-21047e6f7b.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
