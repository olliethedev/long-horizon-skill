# record-3fe764a037: retry dashboard
Alias used in the design review: worker routing. Local variant: record-c152fdc842.12.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-30: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-b17f9ef20f. Deployment/exposure: 2026-05-03, receipt record-b5bad85062; 20% of eligible production accounts. The original observation is history/evidence/record-cb817cda56.md. Later review: history/evidence/record-3ea4aa71f2.md.
Disposition recorded after the first window: Rolled back 2026-05-11, receipt record-fd791e82f0, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
