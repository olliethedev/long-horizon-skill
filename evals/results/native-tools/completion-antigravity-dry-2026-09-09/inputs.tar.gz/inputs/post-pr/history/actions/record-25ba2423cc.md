# record-25ba2423cc: worker routing
Alias used in the design review: queue retry fix. Local variant: record-4f54812b4a.0.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-07: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-a0e5b01bc4. Deployment/exposure: 2026-06-10, receipt record-f8e6906ea8; 10% of eligible production accounts. The original observation is history/evidence/record-50f60f04b8.md. Later review: history/evidence/record-83b15fcd38.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-23; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
