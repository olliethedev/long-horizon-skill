# record-1a7a8c690a: queue retry fix
Alias used in the design review: Lantern. Local variant: record-4f54812b4a.11.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-142136875e. Deployment/exposure: 2026-04-26, receipt record-9975265cd1; 10% of eligible production accounts. The original observation is history/evidence/record-6ca36963e4.md. Later review: history/evidence/record-7a43c4106a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
