# record-0b4cca4084: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.8.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-23: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-a8a354a4e9. Deployment/exposure: 2026-07-26, receipt record-5de1ed50cc; 15% of eligible production accounts. The original observation is history/evidence/record-3621a54908.md. Later review: history/evidence/record-ad5f796b4a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-04; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
