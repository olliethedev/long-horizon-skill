# record-105f8e6b59: worker routing
Alias used in the design review: queue retry fix. Local variant: record-33d493a561.13.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-4a8f322a4a. Deployment/exposure: 2026-03-23, receipt record-f952b71c04; 15% of eligible production accounts. The original observation is history/evidence/record-7fcc36b37c.md. Later review: history/evidence/record-e5e6197792.md.
Disposition recorded after the first window: Disabled 2026-04-07, receipt record-a2940e7b9e, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
