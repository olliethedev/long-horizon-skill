# record-04ecf398ec: worker routing
Alias used in the design review: queue retry fix. Local variant: record-c152fdc842.11.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-1ab4136a8e. Deployment/exposure: 2026-07-27, receipt record-d953e7099b; 20% of eligible production accounts. The original observation is history/evidence/record-0e87967c39.md. Later review: history/evidence/record-0a8df0293b.md.
Disposition recorded after the first window: Disabled 2026-08-11, receipt record-26b30483f0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
