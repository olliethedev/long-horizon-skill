# record-1a54815bf5: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-5824296480.1.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-02: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-4015c539f3. Deployment/exposure: 2026-03-05, receipt record-17ed518646; 25% of eligible production accounts. The original observation is history/evidence/record-0d479195dc.md. Later review: history/evidence/record-a1130a2c30.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-18; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
