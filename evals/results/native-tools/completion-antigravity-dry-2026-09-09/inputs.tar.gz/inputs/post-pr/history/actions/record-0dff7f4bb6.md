# record-0dff7f4bb6: queue retry fix
Alias used in the design review: Lantern. Local variant: record-33d493a561.14.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-7482e2b3d8. Deployment/exposure: 2026-04-26, receipt record-befeb1bb72; 10% of eligible production accounts. The original observation is history/evidence/record-f5f2a2adc1.md. Later review: history/evidence/record-d1350cf6f7.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
