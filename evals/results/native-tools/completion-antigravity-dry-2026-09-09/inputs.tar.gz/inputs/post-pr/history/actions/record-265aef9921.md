# record-265aef9921: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-f39df68ace.2.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-25: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-383ae7074f. Deployment/exposure: 2026-02-28, receipt record-47b9626f05; 25% of eligible production accounts. The original observation is history/evidence/record-158a4e36e7.md. Later review: history/evidence/record-ee8e4ada8d.md.
Disposition recorded after the first window: Disabled 2026-03-15, receipt record-127a6d0a75, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
