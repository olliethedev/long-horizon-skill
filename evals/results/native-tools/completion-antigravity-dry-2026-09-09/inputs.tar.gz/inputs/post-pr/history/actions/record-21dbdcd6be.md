# record-21dbdcd6be: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-c152fdc842.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-04: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-82125ffae0. Deployment/exposure: 2026-07-07, receipt record-f22e1c247c; 20% of eligible production accounts. The original observation is history/evidence/record-efbc85c971.md. Later review: history/evidence/record-b9ede32fe4.md.
Disposition recorded after the first window: Rolled back 2026-07-15, receipt record-109fde0a29, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
