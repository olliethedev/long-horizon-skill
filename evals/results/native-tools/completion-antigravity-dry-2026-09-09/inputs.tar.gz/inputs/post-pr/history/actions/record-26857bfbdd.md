# record-26857bfbdd: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-ca17f3b817.9.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-01: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-10fda675e5. Deployment/exposure: 2026-03-04, receipt record-2419b8afe6; 20% of eligible production accounts. The original observation is history/evidence/record-2969c3380f.md. Later review: history/evidence/record-b50da6a288.md.
Disposition recorded after the first window: Disabled 2026-03-19, receipt record-3cc7b58c02, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
