# record-322ae7ac48: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.10.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-28: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-30a04b71d8. Deployment/exposure: 2026-07-31, receipt record-6d0a51a3a1; 15% of eligible production accounts. The original observation is history/evidence/record-f617a81288.md. Later review: history/evidence/record-e358d2923a.md.
Disposition recorded after the first window: Disabled 2026-08-11, receipt record-6c65a7be1b, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
