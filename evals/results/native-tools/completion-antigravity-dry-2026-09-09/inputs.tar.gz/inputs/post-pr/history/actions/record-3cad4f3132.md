# record-3cad4f3132: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-e5c0a618bf.0.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-17: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-cc36d01337. Deployment/exposure: 2026-04-20, receipt record-18bc1b3da9; 5% of eligible production accounts. The original observation is history/evidence/record-0ac11cbdca.md. Later review: history/evidence/record-e01d17bb62.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-03; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
