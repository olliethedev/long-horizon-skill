# record-073aa2a275: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.5.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-08: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-1953e3bae0. Deployment/exposure: 2026-04-11, receipt record-250a74e629; 10% of eligible production accounts. The original observation is history/evidence/record-781b9d533e.md. Later review: history/evidence/record-ca6eefae63.md.
Disposition recorded after the first window: Disabled 2026-04-26, receipt record-0f6044202b, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
