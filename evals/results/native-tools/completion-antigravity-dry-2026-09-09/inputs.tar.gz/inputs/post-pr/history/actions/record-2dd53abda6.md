# record-2dd53abda6: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.15.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-13: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-58f6354da4. Deployment/exposure: 2026-07-16, receipt record-54ef5a6622; 15% of eligible production accounts. The original observation is history/evidence/record-5e10c05cee.md. Later review: history/evidence/record-90041e4fa4.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
