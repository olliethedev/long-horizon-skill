# record-18dbce4a05: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.13.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-08: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-391d56d63e. Deployment/exposure: 2026-06-11, receipt record-f8f41aeff9; 15% of eligible production accounts. The original observation is history/evidence/record-9734765644.md. Later review: history/evidence/record-38a52df477.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-20; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
