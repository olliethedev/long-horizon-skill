# record-1407ae47f2: retry dashboard
Alias used in the design review: worker routing. Local variant: record-e5c0a618bf.1.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-342d4fc464. Deployment/exposure: 2026-07-23, receipt record-dd8c152711; 25% of eligible production accounts. The original observation is history/evidence/record-6bcffd2c83.md. Later review: history/evidence/record-e4671c8f56.md.
Disposition recorded after the first window: Disabled 2026-08-03, receipt record-9106bcde32, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
