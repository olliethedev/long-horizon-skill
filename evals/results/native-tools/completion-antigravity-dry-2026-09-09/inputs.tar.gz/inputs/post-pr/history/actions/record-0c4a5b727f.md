# record-0c4a5b727f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-5824296480.6.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-21: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-8f3e597f8c. Deployment/exposure: 2026-07-24, receipt record-5e447a8ece; 5% of eligible production accounts. The original observation is history/evidence/record-df0ec248e4.md. Later review: history/evidence/record-814ddc9cd5.md.
Disposition recorded after the first window: Rolled back 2026-08-05, receipt record-b331b4d343, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
