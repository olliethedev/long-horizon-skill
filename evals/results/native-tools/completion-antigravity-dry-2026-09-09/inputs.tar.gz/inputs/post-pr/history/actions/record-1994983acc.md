# record-1994983acc: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-f39df68ace.12.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-07: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-05fa6eaf58. Deployment/exposure: 2026-08-10, receipt record-8c7b196063; 15% of eligible production accounts. The original observation is history/evidence/record-570fb79795.md. Later review: history/evidence/record-e75ef40f94.md.
Disposition recorded after the first window: Rolled back 2026-08-22, receipt record-f0447c66e5, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
