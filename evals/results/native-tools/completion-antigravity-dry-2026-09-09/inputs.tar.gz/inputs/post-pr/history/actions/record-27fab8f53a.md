# record-27fab8f53a: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-33d493a561.7.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-02: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-432541a7e2. Deployment/exposure: 2026-06-05, receipt record-804f1c757d; 10% of eligible production accounts. The original observation is history/evidence/record-0b5fb28143.md. Later review: history/evidence/record-21307cd6f9.md.
Disposition recorded after the first window: Rolled back 2026-06-13, receipt record-e3d2e1d492, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
