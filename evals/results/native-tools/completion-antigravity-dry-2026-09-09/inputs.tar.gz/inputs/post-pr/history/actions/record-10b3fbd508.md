# record-10b3fbd508: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-3158237b52.14.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-77929389db. Deployment/exposure: 2026-06-14, receipt record-99526e3b2a; 5% of eligible production accounts. The original observation is history/evidence/record-e298d35904.md. Later review: history/evidence/record-2426a9de01.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
