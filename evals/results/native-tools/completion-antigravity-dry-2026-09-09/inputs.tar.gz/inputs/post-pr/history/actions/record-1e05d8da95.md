# record-1e05d8da95: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.8.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-06: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-404bd70d63. Deployment/exposure: 2026-04-09, receipt record-3168ab364e; 25% of eligible production accounts. The original observation is history/evidence/record-7e5afaf986.md. Later review: history/evidence/record-6652d5c140.md.
Disposition recorded after the first window: Rolled back 2026-04-17, receipt record-acc93d722b, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
