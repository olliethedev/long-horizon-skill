# record-3c913a32ed: timeout report
Alias used in the design review: shared worker. Local variant: record-df7fc22939.12.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-12: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-df9cad0ea9. Deployment/exposure: 2026-05-15, receipt record-8122a67337; 5% of eligible production accounts. The original observation is history/evidence/record-0148b52f41.md. Later review: history/evidence/record-1a19b0ebc3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
