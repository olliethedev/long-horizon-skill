# record-13be382cd1: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-df7fc22939.15.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-21: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-a646bf14e8. Deployment/exposure: 2026-02-24, receipt record-664a312d79; 5% of eligible production accounts. The original observation is history/evidence/record-61ef53cf02.md. Later review: history/evidence/record-4993bd8b45.md.
Disposition recorded after the first window: Rolled back 2026-03-08, receipt record-8d203818fe, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
