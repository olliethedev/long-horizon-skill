# record-3873afd069: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-ca17f3b817.6.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-27: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-624722c92a. Deployment/exposure: 2026-03-02, receipt record-bb9958bda7; 10% of eligible production accounts. The original observation is history/evidence/record-744727cf64.md. Later review: history/evidence/record-ade45bcab4.md.
Disposition recorded after the first window: Rolled back 2026-03-10, receipt record-3b772e13e3, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
