# record-2452bdf861: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.16.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-31: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-2d3251e4a6. Deployment/exposure: 2026-04-03, receipt record-452e2eafc1; 20% of eligible production accounts. The original observation is history/evidence/record-a0b658d131.md. Later review: history/evidence/record-59e5afe4c8.md.
Disposition recorded after the first window: Disabled 2026-04-14, receipt record-15baab95ff, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
