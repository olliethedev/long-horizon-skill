# record-07174de52e: queue retry fix
Alias used in the design review: Lantern. Local variant: record-4f54812b4a.15.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-02: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-b78b56750e. Deployment/exposure: 2026-06-05, receipt record-7ab643a954; 10% of eligible production accounts. The original observation is history/evidence/record-f55612182f.md. Later review: history/evidence/record-7bc608e48a.md.
Disposition recorded after the first window: Disabled 2026-06-16, receipt record-d18f94f1d4, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
