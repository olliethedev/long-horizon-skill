# record-16eb4f7851: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-5824296480.7.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-07: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-fd28061624. Deployment/exposure: 2026-06-10, receipt record-054a7a4c6c; 10% of eligible production accounts. The original observation is history/evidence/record-a6d9e1cb67.md. Later review: history/evidence/record-a3da93101f.md.
Disposition recorded after the first window: Disabled 2026-06-25, receipt record-0d2d041c50, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
