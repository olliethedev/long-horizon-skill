# record-3345bdcb65: worker routing
Alias used in the design review: queue retry fix. Local variant: record-ca17f3b817.16.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-23: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-1ebbbc5dee. Deployment/exposure: 2026-05-26, receipt record-7bb9fcbd5c; 10% of eligible production accounts. The original observation is history/evidence/record-c6e559931c.md. Later review: history/evidence/record-36947a089c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
