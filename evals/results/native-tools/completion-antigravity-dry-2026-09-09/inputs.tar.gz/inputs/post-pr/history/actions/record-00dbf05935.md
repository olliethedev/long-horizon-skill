# record-00dbf05935: worker routing
Alias used in the design review: queue retry fix. Local variant: record-f39df68ace.6.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-19: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-68c2930892. Deployment/exposure: 2026-07-22, receipt record-a429a0b9eb; 20% of eligible production accounts. The original observation is history/evidence/record-5133249d8f.md. Later review: history/evidence/record-b82bd14d64.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-31; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
