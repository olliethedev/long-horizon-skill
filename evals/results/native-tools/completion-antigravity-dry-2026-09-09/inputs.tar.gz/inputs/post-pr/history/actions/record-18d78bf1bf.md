# record-18d78bf1bf: retry dashboard
Alias used in the design review: worker routing. Local variant: record-c152fdc842.2.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-01: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-d3d046ef3e. Deployment/exposure: 2026-04-04, receipt record-f7c387aeeb; 25% of eligible production accounts. The original observation is history/evidence/record-91e0d60eaf.md. Later review: history/evidence/record-78dea76f7f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
