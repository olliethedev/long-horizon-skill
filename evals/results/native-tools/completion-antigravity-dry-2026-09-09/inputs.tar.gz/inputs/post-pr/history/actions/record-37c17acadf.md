# record-37c17acadf: retry dashboard
Alias used in the design review: worker routing. Local variant: record-ca17f3b817.1.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-28: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-835da2d705. Deployment/exposure: 2026-05-01, receipt record-42145a1b8f; 10% of eligible production accounts. The original observation is history/evidence/record-33513fe04b.md. Later review: history/evidence/record-c7b6a5f1c0.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
