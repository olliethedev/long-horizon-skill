# record-2c1738ed40: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-c152fdc842.8.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-31: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-c378263295. Deployment/exposure: 2026-06-03, receipt record-4a81d20666; 25% of eligible production accounts. The original observation is history/evidence/record-2863f41b2f.md. Later review: history/evidence/record-aeebdc15bc.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
