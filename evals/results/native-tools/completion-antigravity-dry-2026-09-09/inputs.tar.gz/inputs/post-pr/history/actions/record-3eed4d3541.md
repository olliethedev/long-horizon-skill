# record-3eed4d3541: worker routing
Alias used in the design review: queue retry fix. Local variant: record-4f54812b4a.7.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-20: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-8ad5dad224. Deployment/exposure: 2026-02-23, receipt record-f9ec73a4cd; 25% of eligible production accounts. The original observation is history/evidence/record-9c756bea67.md. Later review: history/evidence/record-aaa442e57c.md.
Disposition recorded after the first window: Disabled 2026-03-10, receipt record-160379070e, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
