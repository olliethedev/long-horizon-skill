# record-1f796d48b2: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.0.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-12: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-1e6fdbe691. Deployment/exposure: 2026-05-15, receipt record-dd6b253fb8; 5% of eligible production accounts. The original observation is history/evidence/record-fedb5968f3.md. Later review: history/evidence/record-cf1a16c278.md.
Disposition recorded after the first window: Rolled back 2026-05-23, receipt record-11d04afeba, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
