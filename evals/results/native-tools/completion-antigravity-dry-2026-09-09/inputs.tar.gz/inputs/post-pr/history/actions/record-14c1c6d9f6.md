# record-14c1c6d9f6: timeout report
Alias used in the design review: shared worker. Local variant: record-33d493a561.4.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-09: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-1a4c3fa186. Deployment/exposure: 2026-04-12, receipt record-7ab7575a37; 15% of eligible production accounts. The original observation is history/evidence/record-0448233c22.md. Later review: history/evidence/record-3208989cc8.md.
Disposition recorded after the first window: Disabled 2026-04-27, receipt record-d81870be99, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
