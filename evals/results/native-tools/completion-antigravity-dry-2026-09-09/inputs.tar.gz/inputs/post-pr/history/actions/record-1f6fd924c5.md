# record-1f6fd924c5: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-3158237b52.6.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-18: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-fe05862919. Deployment/exposure: 2026-05-21, receipt record-db012cd3c9; 10% of eligible production accounts. The original observation is history/evidence/record-5fadef0afe.md. Later review: history/evidence/record-d5cb64ffbf.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
