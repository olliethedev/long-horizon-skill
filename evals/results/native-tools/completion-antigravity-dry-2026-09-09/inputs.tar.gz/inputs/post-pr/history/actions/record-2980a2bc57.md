# record-2980a2bc57: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.9.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-07: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-eccfdd2311. Deployment/exposure: 2026-05-10, receipt record-457140502a; 5% of eligible production accounts. The original observation is history/evidence/record-456088ff5b.md. Later review: history/evidence/record-f6847722b3.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
