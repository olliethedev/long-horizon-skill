# record-34646f0fc1: worker routing
Alias used in the design review: queue retry fix. Local variant: record-ca17f3b817.0.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-27: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-5af8e0bfca. Deployment/exposure: 2026-03-02, receipt record-7514d4a929; 10% of eligible production accounts. The original observation is history/evidence/record-e7d1a57719.md. Later review: history/evidence/record-83f8c6b006.md.
Disposition recorded after the first window: Disabled 2026-03-17, receipt record-b916f0923c, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
