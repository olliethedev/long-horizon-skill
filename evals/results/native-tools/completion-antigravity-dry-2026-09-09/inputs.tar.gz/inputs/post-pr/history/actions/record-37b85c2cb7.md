# record-37b85c2cb7: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.12.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-15: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-66200e6f3d. Deployment/exposure: 2026-06-18, receipt record-3250d2b3ea; 25% of eligible production accounts. The original observation is history/evidence/record-de5ea21533.md. Later review: history/evidence/record-c97a788140.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
