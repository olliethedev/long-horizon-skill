# record-19186d4aba: timeout report
Alias used in the design review: shared worker. Local variant: record-4f54812b4a.14.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-19: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-05a2c3ec7f. Deployment/exposure: 2026-03-22, receipt record-b8ede851d7; 10% of eligible production accounts. The original observation is history/evidence/record-72ddea3600.md. Later review: history/evidence/record-0a1bd48b7c.md.
Disposition recorded after the first window: Disabled 2026-04-06, receipt record-b323a928b8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
