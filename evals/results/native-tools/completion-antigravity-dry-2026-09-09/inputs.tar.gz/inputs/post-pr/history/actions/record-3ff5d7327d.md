# record-3ff5d7327d: timeout report
Alias used in the design review: shared worker. Local variant: record-e5c0a618bf.13.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-8e862d2a53. Deployment/exposure: 2026-04-10, receipt record-d29c0f2aa2; 5% of eligible production accounts. The original observation is history/evidence/record-fa2d23bcb6.md. Later review: history/evidence/record-7ab643e8f2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
