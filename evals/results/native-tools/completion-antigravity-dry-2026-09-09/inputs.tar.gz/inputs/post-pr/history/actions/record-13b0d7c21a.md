# record-13b0d7c21a: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-f39df68ace.1.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-27: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-f389d8677e. Deployment/exposure: 2026-07-30, receipt record-135ea512f7; 10% of eligible production accounts. The original observation is history/evidence/record-d5270bb0c5.md. Later review: history/evidence/record-730f3d976a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-12; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
