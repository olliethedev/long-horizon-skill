# record-341f9ce94f: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.13.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-03: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-e196178ffd. Deployment/exposure: 2026-03-06, receipt record-26dbac2a86; 5% of eligible production accounts. The original observation is history/evidence/record-e95074975a.md. Later review: history/evidence/record-2fa666c234.md.
Disposition recorded after the first window: Disabled 2026-03-21, receipt record-fa2aa87eda, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
