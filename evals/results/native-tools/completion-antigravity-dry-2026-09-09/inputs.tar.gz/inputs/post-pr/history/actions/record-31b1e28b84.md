# record-31b1e28b84: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-e5c0a618bf.12.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-04: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-c770161198. Deployment/exposure: 2026-03-07, receipt record-050095a2b8; 10% of eligible production accounts. The original observation is history/evidence/record-39f8bef5a6.md. Later review: history/evidence/record-2566293a78.md.
Disposition recorded after the first window: Disabled 2026-03-22, receipt record-703f750376, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
