# record-1207e9a3cc: worker routing
Alias used in the design review: queue retry fix. Local variant: record-df7fc22939.16.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-01: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-ab6d437f13. Deployment/exposure: 2026-03-04, receipt record-143b3aa06a; 20% of eligible production accounts. The original observation is history/evidence/record-a561665903.md. Later review: history/evidence/record-a34016fdc2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
