# record-18af01c181: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-e5c0a618bf.10.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-11: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-8f6603223c. Deployment/exposure: 2026-07-14, receipt record-b4b6cf93c7; 5% of eligible production accounts. The original observation is history/evidence/record-5aaadf553a.md. Later review: history/evidence/record-01ad50d29f.md.
Disposition recorded after the first window: Disabled 2026-07-25, receipt record-818d67efaa, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
