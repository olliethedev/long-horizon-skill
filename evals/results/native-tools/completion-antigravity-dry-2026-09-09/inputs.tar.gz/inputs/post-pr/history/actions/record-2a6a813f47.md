# record-2a6a813f47: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-c152fdc842.7.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-08: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-d84d4507d4. Deployment/exposure: 2026-05-11, receipt record-9318fee3cd; 10% of eligible production accounts. The original observation is history/evidence/record-92c9f407a0.md. Later review: history/evidence/record-34a9d22421.md.
Disposition recorded after the first window: Rolled back 2026-05-23, receipt record-5c652f677e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
