# record-16bf6ab109: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-5824296480.8.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-20: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-7d2bc01323. Deployment/exposure: 2026-05-23, receipt record-52fe3325b1; 20% of eligible production accounts. The original observation is history/evidence/record-58c07f3b2a.md. Later review: history/evidence/record-02dd280fba.md.
Disposition recorded after the first window: Disabled 2026-06-07, receipt record-3d6bed9c71, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
