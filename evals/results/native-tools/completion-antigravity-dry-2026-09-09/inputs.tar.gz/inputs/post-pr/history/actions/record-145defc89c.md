# record-145defc89c: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.5.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-16: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-f924f7c493. Deployment/exposure: 2026-04-19, receipt record-a53022d958; 25% of eligible production accounts. The original observation is history/evidence/record-bbc008c776.md. Later review: history/evidence/record-17c4795d5d.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
