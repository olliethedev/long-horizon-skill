# record-0cf26b242e: queue retry fix
Alias used in the design review: Lantern. Local variant: record-f39df68ace.5.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-20: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-aa2a18b0b5. Deployment/exposure: 2026-04-23, receipt record-3fdf431f24; 20% of eligible production accounts. The original observation is history/evidence/record-fa7245bb7c.md. Later review: history/evidence/record-21f09a1193.md.
Disposition recorded after the first window: Rolled back 2026-05-01, receipt record-3f8e3066a9, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
