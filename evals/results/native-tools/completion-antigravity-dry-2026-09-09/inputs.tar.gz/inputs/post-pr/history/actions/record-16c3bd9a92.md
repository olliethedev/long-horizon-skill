# record-16c3bd9a92: worker routing
Alias used in the design review: queue retry fix. Local variant: record-ca17f3b817.0.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-afa4f74888. Deployment/exposure: 2026-05-19, receipt record-e2d462e39a; 25% of eligible production accounts. The original observation is history/evidence/record-9eda8843c2.md. Later review: history/evidence/record-5094021635.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
