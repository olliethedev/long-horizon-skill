# record-3d9978e4db: worker routing
Alias used in the design review: queue retry fix. Local variant: record-4f54812b4a.2.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-12: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-f4640d43b2. Deployment/exposure: 2026-06-15, receipt record-9d4723454b; 10% of eligible production accounts. The original observation is history/evidence/record-3e46b0c0e2.md. Later review: history/evidence/record-388901d630.md.
Disposition recorded after the first window: Disabled 2026-06-30, receipt record-41878fd3fa, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
