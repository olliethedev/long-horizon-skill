# record-2c7232cdbe: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-3158237b52.13.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-19: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-4d778103b9. Deployment/exposure: 2026-05-22, receipt record-7d3a416a15; 15% of eligible production accounts. The original observation is history/evidence/record-5a89a64663.md. Later review: history/evidence/record-9dfe1a35dd.md.
Disposition recorded after the first window: Rolled back 2026-06-03, receipt record-2cd964b42e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
