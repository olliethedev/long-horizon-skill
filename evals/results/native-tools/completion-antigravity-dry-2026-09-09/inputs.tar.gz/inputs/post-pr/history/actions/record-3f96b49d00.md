# record-3f96b49d00: worker routing
Alias used in the design review: queue retry fix. Local variant: record-5824296480.15.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-28: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-e928afb498. Deployment/exposure: 2026-03-03, receipt record-31a3d20915; 15% of eligible production accounts. The original observation is history/evidence/record-3acf346066.md. Later review: history/evidence/record-db2db420cd.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
