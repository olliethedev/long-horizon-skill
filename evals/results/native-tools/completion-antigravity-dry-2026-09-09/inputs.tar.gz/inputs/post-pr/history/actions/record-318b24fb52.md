# record-318b24fb52: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.16.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-14: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-4b9c953b38. Deployment/exposure: 2026-07-17, receipt record-5ca2502929; 20% of eligible production accounts. The original observation is history/evidence/record-2dfed38441.md. Later review: history/evidence/record-3bc7fd5565.md.
Disposition recorded after the first window: Rolled back 2026-07-25, receipt record-c2e1ca9dba, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
