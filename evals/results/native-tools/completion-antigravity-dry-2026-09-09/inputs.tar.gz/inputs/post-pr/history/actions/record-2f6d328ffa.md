# record-2f6d328ffa: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-df7fc22939.15.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-04: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-3cbbd7d708. Deployment/exposure: 2026-08-07, receipt record-a11c88c7b2; 25% of eligible production accounts. The original observation is history/evidence/record-10135a0982.md. Later review: history/evidence/record-03b9b8b4f2.md.
Disposition recorded after the first window: Rolled back 2026-08-19, receipt record-4b10ac13a7, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
