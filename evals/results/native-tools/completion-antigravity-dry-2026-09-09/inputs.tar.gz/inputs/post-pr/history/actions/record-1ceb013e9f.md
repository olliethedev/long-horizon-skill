# record-1ceb013e9f: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-3158237b52.5.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-05: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-031fb5a081. Deployment/exposure: 2026-06-08, receipt record-e063d73d30; 25% of eligible production accounts. The original observation is history/evidence/record-0ab33b4345.md. Later review: history/evidence/record-321863d112.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-17; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
