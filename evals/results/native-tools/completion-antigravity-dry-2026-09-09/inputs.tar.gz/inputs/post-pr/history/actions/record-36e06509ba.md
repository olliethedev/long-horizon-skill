# record-36e06509ba: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-4f54812b4a.9.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-a2895c0581. Deployment/exposure: 2026-03-15, receipt record-15dffe1aec; 25% of eligible production accounts. The original observation is history/evidence/record-4f7ea705b9.md. Later review: history/evidence/record-87a51eb089.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
