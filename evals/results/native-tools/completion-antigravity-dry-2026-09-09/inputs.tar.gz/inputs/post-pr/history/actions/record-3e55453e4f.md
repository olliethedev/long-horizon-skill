# record-3e55453e4f: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-e5c0a618bf.10.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-27: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-0f4978b68a. Deployment/exposure: 2026-03-02, receipt record-906b0a69d0; 10% of eligible production accounts. The original observation is history/evidence/record-682cbfe420.md. Later review: history/evidence/record-5792dfff4f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-15; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
