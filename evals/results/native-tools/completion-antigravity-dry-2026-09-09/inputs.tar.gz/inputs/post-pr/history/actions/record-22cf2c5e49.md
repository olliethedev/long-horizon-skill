# record-22cf2c5e49: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-33d493a561.12.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-29: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-baa8970fc1. Deployment/exposure: 2026-06-01, receipt record-c3cad38738; 15% of eligible production accounts. The original observation is history/evidence/record-7b75cc33fa.md. Later review: history/evidence/record-95ed981cb0.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
