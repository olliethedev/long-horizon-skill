# record-0ec9dd7b20: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-f39df68ace.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-09: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-879be39f8b. Deployment/exposure: 2026-08-12, receipt record-3fa4db93f5; 25% of eligible production accounts. The original observation is history/evidence/record-5118944588.md. Later review: history/evidence/record-43ec506c58.md.
Disposition recorded after the first window: Disabled 2026-08-23, receipt record-385bef46fa, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
