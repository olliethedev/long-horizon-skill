# record-3ae7e9f80c: queue retry fix
Alias used in the design review: Lantern. Local variant: record-4f54812b4a.8.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-01: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-bf26e1ea71. Deployment/exposure: 2026-06-04, receipt record-04badc6a46; 5% of eligible production accounts. The original observation is history/evidence/record-ef5bd93245.md. Later review: history/evidence/record-81338ad984.md.
Disposition recorded after the first window: Rolled back 2026-06-12, receipt record-d9298306c5, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
