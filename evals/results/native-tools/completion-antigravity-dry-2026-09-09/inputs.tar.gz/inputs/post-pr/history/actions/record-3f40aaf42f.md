# record-3f40aaf42f: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-5824296480.12.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-13: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-7c2ed47e68. Deployment/exposure: 2026-03-16, receipt record-589a558ec7; 5% of eligible production accounts. The original observation is history/evidence/record-6ae1435b27.md. Later review: history/evidence/record-d080476d9a.md.
Disposition recorded after the first window: Rolled back 2026-03-28, receipt record-cd0bfae8d2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
