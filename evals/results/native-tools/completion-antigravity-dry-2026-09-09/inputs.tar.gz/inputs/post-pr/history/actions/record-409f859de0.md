# record-409f859de0: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.11.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-21: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-d6f05e1b19. Deployment/exposure: 2026-07-24, receipt record-581e4bb90d; 5% of eligible production accounts. The original observation is history/evidence/record-e24488e2dc.md. Later review: history/evidence/record-b2fb75ad31.md.
Disposition recorded after the first window: Disabled 2026-08-04, receipt record-9038207e1a, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
