# record-32953a93ea: worker routing
Alias used in the design review: queue retry fix. Local variant: record-f39df68ace.11.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-29: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-43323fae19. Deployment/exposure: 2026-04-01, receipt record-fa5faad566; 10% of eligible production accounts. The original observation is history/evidence/record-8c28291491.md. Later review: history/evidence/record-246a22851d.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
