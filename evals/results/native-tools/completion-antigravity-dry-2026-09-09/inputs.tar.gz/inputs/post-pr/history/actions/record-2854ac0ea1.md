# record-2854ac0ea1: queue retry fix
Alias used in the design review: Lantern. Local variant: record-4f54812b4a.10.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-30: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-f21b1de169. Deployment/exposure: 2026-05-03, receipt record-ef8f0fa4de; 20% of eligible production accounts. The original observation is history/evidence/record-e57a9f6d41.md. Later review: history/evidence/record-b6e34933b8.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-16; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
