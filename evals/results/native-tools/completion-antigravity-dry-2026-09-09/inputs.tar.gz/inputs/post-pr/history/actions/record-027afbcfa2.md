# record-027afbcfa2: timeout report
Alias used in the design review: shared worker. Local variant: record-ca17f3b817.11.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-3e51decd9a. Deployment/exposure: 2026-07-25, receipt record-cdbcfc91d2; 10% of eligible production accounts. The original observation is history/evidence/record-58e2c78fd5.md. Later review: history/evidence/record-938af8ab48.md.
Disposition recorded after the first window: Rolled back 2026-08-06, receipt record-2773c1c22a, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
