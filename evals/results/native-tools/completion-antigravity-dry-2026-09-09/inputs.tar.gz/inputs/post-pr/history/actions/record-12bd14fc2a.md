# record-12bd14fc2a: retry dashboard
Alias used in the design review: worker routing. Local variant: record-5824296480.14.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-13: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-d8ebd4dab4. Deployment/exposure: 2026-05-16, receipt record-23f7c6562b; 10% of eligible production accounts. The original observation is history/evidence/record-c1e8237da5.md. Later review: history/evidence/record-f05f836ed2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
