# record-2e9a3408e0: retry dashboard
Alias used in the design review: worker routing. Local variant: record-c152fdc842.4.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-06: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-50e97f7bfe. Deployment/exposure: 2026-04-09, receipt record-cae7d0beb0; 25% of eligible production accounts. The original observation is history/evidence/record-d76be105c7.md. Later review: history/evidence/record-aad317c2d6.md.
Disposition recorded after the first window: Disabled 2026-04-20, receipt record-0858f42164, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
