# record-001a65d4be: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.2.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-28: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-a3be29e103. Deployment/exposure: 2026-05-01, receipt record-5fa54a788e; 10% of eligible production accounts. The original observation is history/evidence/record-2fec6f8ba5.md. Later review: history/evidence/record-6718bde002.md.
Disposition recorded after the first window: Disabled 2026-05-16, receipt record-ca358458f4, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
