# record-33534b3d6f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-c152fdc842.9.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-23: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-fbdf304471. Deployment/exposure: 2026-06-26, receipt record-3c2b5ba3cf; 15% of eligible production accounts. The original observation is history/evidence/record-92472b7c0c.md. Later review: history/evidence/record-cc07bef13d.md.
Disposition recorded after the first window: Rolled back 2026-07-04, receipt record-f8528c943b, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
