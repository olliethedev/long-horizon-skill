# record-113f7f260c: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-f39df68ace.13.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-18: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-ebaf37b89e. Deployment/exposure: 2026-04-21, receipt record-c8c48b4240; 10% of eligible production accounts. The original observation is history/evidence/record-8f0078d8e4.md. Later review: history/evidence/record-c9ca943798.md.
Disposition recorded after the first window: Rolled back 2026-04-29, receipt record-3243458007, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
