# record-2e92219b7f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-df7fc22939.13.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-30: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-4fe10696e9. Deployment/exposure: 2026-07-03, receipt record-44b36601c0; 25% of eligible production accounts. The original observation is history/evidence/record-9121ade8dd.md. Later review: history/evidence/record-fd1b2217fd.md.
Disposition recorded after the first window: Rolled back 2026-07-11, receipt record-757ead2e3e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
