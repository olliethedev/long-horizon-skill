# record-24225aed0a: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-4f54812b4a.14.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-20: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-76657ffc6b. Deployment/exposure: 2026-06-23, receipt record-7917154a7f; 25% of eligible production accounts. The original observation is history/evidence/record-0b1a27ced0.md. Later review: history/evidence/record-183956234d.md.
Disposition recorded after the first window: Disabled 2026-07-04, receipt record-87912c90ec, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
