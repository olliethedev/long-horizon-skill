# record-3347f1dfb0: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-33d493a561.1.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-13: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-a2942bf0f6. Deployment/exposure: 2026-07-16, receipt record-d4d91aa6f7; 15% of eligible production accounts. The original observation is history/evidence/record-8efda7595f.md. Later review: history/evidence/record-67113ff0f3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-25; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
