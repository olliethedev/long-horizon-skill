# record-0b83f9b1de: queue retry fix
Alias used in the design review: Lantern. Local variant: record-df7fc22939.15.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-19: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-cd249c3d63. Deployment/exposure: 2026-03-22, receipt record-1b5f9b81c0; 10% of eligible production accounts. The original observation is history/evidence/record-78343c3b57.md. Later review: history/evidence/record-21d76c4324.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-31; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
