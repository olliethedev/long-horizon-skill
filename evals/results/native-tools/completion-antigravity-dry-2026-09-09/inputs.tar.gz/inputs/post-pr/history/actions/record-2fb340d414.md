# record-2fb340d414: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-df7fc22939.5.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-30: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-6b059f6e89. Deployment/exposure: 2026-05-03, receipt record-a826a59382; 20% of eligible production accounts. The original observation is history/evidence/record-47d91677d3.md. Later review: history/evidence/record-553830b721.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
