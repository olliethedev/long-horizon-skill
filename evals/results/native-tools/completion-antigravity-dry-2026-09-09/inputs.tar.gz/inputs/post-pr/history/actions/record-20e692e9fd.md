# record-20e692e9fd: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-e5c0a618bf.8.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-f05b9c0f65. Deployment/exposure: 2026-03-23, receipt record-f22c954968; 15% of eligible production accounts. The original observation is history/evidence/record-a018fafbd8.md. Later review: history/evidence/record-1a62be9c08.md.
Disposition recorded after the first window: Rolled back 2026-03-31, receipt record-a45e50c190, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
