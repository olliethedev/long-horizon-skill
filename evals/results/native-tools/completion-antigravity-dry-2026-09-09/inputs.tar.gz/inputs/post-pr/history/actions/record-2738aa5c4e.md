# record-2738aa5c4e: worker routing
Alias used in the design review: queue retry fix. Local variant: record-df7fc22939.12.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-02: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-4912e9a034. Deployment/exposure: 2026-08-05, receipt record-ead7160aae; 15% of eligible production accounts. The original observation is history/evidence/record-b289ad8cc8.md. Later review: history/evidence/record-8ff6751873.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-18; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
