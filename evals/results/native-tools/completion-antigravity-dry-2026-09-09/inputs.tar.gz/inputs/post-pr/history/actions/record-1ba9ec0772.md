# record-1ba9ec0772: queue retry fix
Alias used in the design review: Lantern. Local variant: record-f39df68ace.2.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-5ea6ccee5b. Deployment/exposure: 2026-07-12, receipt record-dba07d8d3c; 20% of eligible production accounts. The original observation is history/evidence/record-cf6c0c1f1b.md. Later review: history/evidence/record-3b64bf865f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-25; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
