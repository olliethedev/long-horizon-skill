# record-3fe5c6a274: queue retry fix
Alias used in the design review: Lantern. Local variant: record-3158237b52.8.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-12: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-b20c2d9f38. Deployment/exposure: 2026-05-15, receipt record-9e5279c523; 5% of eligible production accounts. The original observation is history/evidence/record-65c504b635.md. Later review: history/evidence/record-c184aeaf40.md.
Disposition recorded after the first window: Disabled 2026-05-26, receipt record-ca73dd60a6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
