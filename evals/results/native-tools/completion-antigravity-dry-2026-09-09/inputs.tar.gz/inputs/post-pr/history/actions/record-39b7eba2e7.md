# record-39b7eba2e7: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-5824296480.2.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-14: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-6594b010a8. Deployment/exposure: 2026-03-17, receipt record-316daf87c9; 10% of eligible production accounts. The original observation is history/evidence/record-5dbcade6da.md. Later review: history/evidence/record-936f825244.md.
Disposition recorded after the first window: Disabled 2026-04-01, receipt record-96f6c8d6b6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
