# record-1a26ed8995: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-ca17f3b817.10.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-25: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-deed5be5e9. Deployment/exposure: 2026-07-28, receipt record-5a86747b9a; 25% of eligible production accounts. The original observation is history/evidence/record-cc01eb44c2.md. Later review: history/evidence/record-200d2af32d.md.
Disposition recorded after the first window: Disabled 2026-08-12, receipt record-07aa88c32c, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
