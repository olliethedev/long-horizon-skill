# record-36b18be44e: retry dashboard
Alias used in the design review: worker routing. Local variant: record-33d493a561.10.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-15: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-3532066f6a. Deployment/exposure: 2026-07-18, receipt record-bd05ec6be6; 25% of eligible production accounts. The original observation is history/evidence/record-5835462643.md. Later review: history/evidence/record-5343338a79.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
