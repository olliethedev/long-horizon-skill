# record-3a47f3c9d9: timeout report
Alias used in the design review: shared worker. Local variant: record-3158237b52.3.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-c4192a6c38. Deployment/exposure: 2026-06-14, receipt record-29b4cb4e9c; 5% of eligible production accounts. The original observation is history/evidence/record-ed20b1f20b.md. Later review: history/evidence/record-628e560d52.md.
Disposition recorded after the first window: Disabled 2026-06-29, receipt record-b73d9898a8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
