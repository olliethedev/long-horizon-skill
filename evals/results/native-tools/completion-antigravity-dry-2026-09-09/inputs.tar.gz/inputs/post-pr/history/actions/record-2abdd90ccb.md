# record-2abdd90ccb: retry dashboard
Alias used in the design review: worker routing. Local variant: record-e5c0a618bf.4.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-23: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-1eac4b042a. Deployment/exposure: 2026-02-26, receipt record-32b74da506; 15% of eligible production accounts. The original observation is history/evidence/record-8451fb26b5.md. Later review: history/evidence/record-faa1b66672.md.
Disposition recorded after the first window: Disabled 2026-03-13, receipt record-eb662178a9, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
