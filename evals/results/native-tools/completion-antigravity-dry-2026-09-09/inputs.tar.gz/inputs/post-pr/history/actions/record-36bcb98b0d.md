# record-36bcb98b0d: queue retry fix
Alias used in the design review: Lantern. Local variant: record-f39df68ace.10.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-16: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-b2b0523d43. Deployment/exposure: 2026-04-19, receipt record-f617ef4e77; 25% of eligible production accounts. The original observation is history/evidence/record-11ccf19ef5.md. Later review: history/evidence/record-11c35dddec.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-28; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
