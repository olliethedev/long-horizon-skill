# record-240fa2e660: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-33d493a561.4.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-24: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-9dc31bfaa5. Deployment/exposure: 2026-04-27, receipt record-13326f7565; 15% of eligible production accounts. The original observation is history/evidence/record-dc1c2721e0.md. Later review: history/evidence/record-69d1d4bcf1.md.
Disposition recorded after the first window: Rolled back 2026-05-09, receipt record-941317275a, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
