# record-036f6c00bb: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-4f54812b4a.15.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-01: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-3dcb9f4aea. Deployment/exposure: 2026-03-04, receipt record-7010c4acf5; 20% of eligible production accounts. The original observation is history/evidence/record-e94fde4c3d.md. Later review: history/evidence/record-29f936ab72.md.
Disposition recorded after the first window: Disabled 2026-03-19, receipt record-d3d406f488, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
