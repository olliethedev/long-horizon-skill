# record-397a55dce0: worker routing
Alias used in the design review: queue retry fix. Local variant: record-f39df68ace.7.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-31: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-3399c31c14. Deployment/exposure: 2026-08-03, receipt record-9a4630e4be; 5% of eligible production accounts. The original observation is history/evidence/record-a5352bf289.md. Later review: history/evidence/record-815a576a88.md.
Disposition recorded after the first window: Disabled 2026-08-14, receipt record-5922055722, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
