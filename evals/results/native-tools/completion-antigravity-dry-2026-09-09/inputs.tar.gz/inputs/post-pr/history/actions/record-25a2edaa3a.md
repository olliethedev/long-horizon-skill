# record-25a2edaa3a: timeout report
Alias used in the design review: shared worker. Local variant: record-3158237b52.11.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-19: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-4502a5961d. Deployment/exposure: 2026-03-22, receipt record-64e9aea10a; 10% of eligible production accounts. The original observation is history/evidence/record-0d6f650017.md. Later review: history/evidence/record-2802bf3bc4.md.
Disposition recorded after the first window: Disabled 2026-04-02, receipt record-1f53749ce2, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
