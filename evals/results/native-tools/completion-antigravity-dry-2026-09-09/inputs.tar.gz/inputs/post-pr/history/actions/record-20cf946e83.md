# record-20cf946e83: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.2.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-25: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-d45cf81ad8. Deployment/exposure: 2026-05-28, receipt record-0dac3569c4; 20% of eligible production accounts. The original observation is history/evidence/record-068178f57b.md. Later review: history/evidence/record-654884fe3f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
