# record-3bf1682d2a: worker routing
Alias used in the design review: queue retry fix. Local variant: record-df7fc22939.9.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-05: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-3c0d630b18. Deployment/exposure: 2026-06-08, receipt record-f794e7a25f; 25% of eligible production accounts. The original observation is history/evidence/record-9fd3b9a4f6.md. Later review: history/evidence/record-427c8f4e02.md.
Disposition recorded after the first window: Disabled 2026-06-23, receipt record-766f62730f, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
