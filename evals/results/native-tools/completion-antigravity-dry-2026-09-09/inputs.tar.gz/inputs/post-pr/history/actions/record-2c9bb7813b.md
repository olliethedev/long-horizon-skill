# record-2c9bb7813b: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-4f54812b4a.4.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-26: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-fa08c775e0. Deployment/exposure: 2026-04-29, receipt record-61679b7e1e; 25% of eligible production accounts. The original observation is history/evidence/record-0e78113688.md. Later review: history/evidence/record-7b81b4337e.md.
Disposition recorded after the first window: Disabled 2026-05-14, receipt record-97166b6013, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
