# record-16657bbda2: queue retry fix
Alias used in the design review: Lantern. Local variant: record-5824296480.5.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-8bf9f50d01. Deployment/exposure: 2026-03-15, receipt record-a9a9df0444; 25% of eligible production accounts. The original observation is history/evidence/record-5ae7649d37.md. Later review: history/evidence/record-9e39384b66.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
