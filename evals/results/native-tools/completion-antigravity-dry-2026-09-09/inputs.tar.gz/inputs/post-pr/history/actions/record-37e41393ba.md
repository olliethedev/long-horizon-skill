# record-37e41393ba: worker routing
Alias used in the design review: queue retry fix. Local variant: record-33d493a561.15.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-11: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-cc5d9a51cc. Deployment/exposure: 2026-07-14, receipt record-4c23bd52a3; 5% of eligible production accounts. The original observation is history/evidence/record-8b2418807a.md. Later review: history/evidence/record-8f8bac6ba3.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
