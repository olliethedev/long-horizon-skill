# record-14bde9cf21: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-f39df68ace.8.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-28: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-ad479d69e1. Deployment/exposure: 2026-07-01, receipt record-fd4c82dcd9; 15% of eligible production accounts. The original observation is history/evidence/record-05fa5c1176.md. Later review: history/evidence/record-92ec2e028f.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
