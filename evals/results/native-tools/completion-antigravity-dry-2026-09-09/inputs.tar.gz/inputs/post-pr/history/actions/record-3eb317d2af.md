# record-3eb317d2af: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-e5c0a618bf.1.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-10: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-605eb48ef3. Deployment/exposure: 2026-05-13, receipt record-a21abb2908; 20% of eligible production accounts. The original observation is history/evidence/record-292d554ccc.md. Later review: history/evidence/record-f40768cfc9.md.
Disposition recorded after the first window: Disabled 2026-05-28, receipt record-7456bbd5a6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
