# record-3bea7bc6c9: queue retry fix
Alias used in the design review: Lantern. Local variant: record-c152fdc842.11.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-2ba77d1aa3. Deployment/exposure: 2026-03-15, receipt record-7970f6d584; 25% of eligible production accounts. The original observation is history/evidence/record-0d28029c3b.md. Later review: history/evidence/record-5f8ea5080a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
