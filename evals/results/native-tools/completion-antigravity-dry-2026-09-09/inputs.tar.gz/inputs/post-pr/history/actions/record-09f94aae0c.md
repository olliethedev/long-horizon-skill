# record-09f94aae0c: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-33d493a561.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-55812e63aa. Deployment/exposure: 2026-05-19, receipt record-40856a65e5; 25% of eligible production accounts. The original observation is history/evidence/record-9c76004add.md. Later review: history/evidence/record-6385d63ed4.md.
Disposition recorded after the first window: Disabled 2026-05-30, receipt record-5f11d6090e, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
