# record-20a2970aa7: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-ca17f3b817.6.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-15: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-04ec23407b. Deployment/exposure: 2026-06-18, receipt record-ca35e4a62f; 25% of eligible production accounts. The original observation is history/evidence/record-8137858864.md. Later review: history/evidence/record-55604cd8f9.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
