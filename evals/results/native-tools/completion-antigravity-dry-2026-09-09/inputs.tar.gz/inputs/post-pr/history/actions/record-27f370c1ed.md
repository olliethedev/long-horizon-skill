# record-27f370c1ed: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-e5c0a618bf.9.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-12: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-1843e37bc6. Deployment/exposure: 2026-04-15, receipt record-f255ec8923; 5% of eligible production accounts. The original observation is history/evidence/record-57d4ffae9a.md. Later review: history/evidence/record-e312e1f2f8.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
