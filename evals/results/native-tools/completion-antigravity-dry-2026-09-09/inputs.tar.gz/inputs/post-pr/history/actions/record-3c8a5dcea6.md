# record-3c8a5dcea6: queue retry fix
Alias used in the design review: Lantern. Local variant: record-c152fdc842.5.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-23: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-3a0f302bd5. Deployment/exposure: 2026-03-26, receipt record-3336c2d202; 5% of eligible production accounts. The original observation is history/evidence/record-e674e0fc51.md. Later review: history/evidence/record-2568843fc7.md.
Disposition recorded after the first window: Rolled back 2026-04-03, receipt record-19f612623b, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
