# record-3f7d2e305c: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-ca17f3b817.11.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-57b47ad04a. Deployment/exposure: 2026-04-08, receipt record-9976390457; 20% of eligible production accounts. The original observation is history/evidence/record-7db0a0cdc9.md. Later review: history/evidence/record-1875ab6a9d.md.
Disposition recorded after the first window: Disabled 2026-04-19, receipt record-eb70fc9451, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
