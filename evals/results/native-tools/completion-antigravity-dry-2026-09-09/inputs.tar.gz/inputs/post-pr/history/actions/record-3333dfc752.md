# record-3333dfc752: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-df7fc22939.6.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-12: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-b8aa8fcee6. Deployment/exposure: 2026-04-15, receipt record-f0ccef486e; 5% of eligible production accounts. The original observation is history/evidence/record-ed62c460a8.md. Later review: history/evidence/record-6e9090b7c1.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
