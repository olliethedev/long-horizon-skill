# record-38a73eaab8: worker routing
Alias used in the design review: queue retry fix. Local variant: record-4f54812b4a.8.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-07: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-8ab5cd12af. Deployment/exposure: 2026-08-10, receipt record-cce3d05917; 15% of eligible production accounts. The original observation is history/evidence/record-c83ddc4364.md. Later review: history/evidence/record-0f27612445.md.
Disposition recorded after the first window: Disabled 2026-08-25, receipt record-693538e734, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
