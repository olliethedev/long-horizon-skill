# record-0ec6c7611f: queue retry fix
Alias used in the design review: Lantern. Local variant: record-33d493a561.2.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-26: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-a31b42384d. Deployment/exposure: 2026-05-29, receipt record-153c0ea325; 25% of eligible production accounts. The original observation is history/evidence/record-2194ab1283.md. Later review: history/evidence/record-95d273f0dd.md.
Disposition recorded after the first window: Disabled 2026-06-13, receipt record-4540dc36ce, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
