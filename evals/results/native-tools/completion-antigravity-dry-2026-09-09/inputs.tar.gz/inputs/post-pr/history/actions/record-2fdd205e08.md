# record-2fdd205e08: retry dashboard
Alias used in the design review: worker routing. Local variant: record-ca17f3b817.15.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-06: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-0139fc32fa. Deployment/exposure: 2026-07-09, receipt record-a7e2829a7a; 5% of eligible production accounts. The original observation is history/evidence/record-330a5829b5.md. Later review: history/evidence/record-38b35aa2ed.md.
Disposition recorded after the first window: Disabled 2026-07-20, receipt record-425b0b02cf, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
