# record-3a9d8d0e50: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-e5c0a618bf.14.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-15: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-2171b36973. Deployment/exposure: 2026-05-18, receipt record-3e6a3bed87; 20% of eligible production accounts. The original observation is history/evidence/record-6d318f3d1a.md. Later review: history/evidence/record-9e96d59fb0.md.
Disposition recorded after the first window: Rolled back 2026-05-26, receipt record-637b203a2d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
