# record-34920bbf6f: retry dashboard
Alias used in the design review: worker routing. Local variant: record-33d493a561.5.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-24: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-4672c9791a. Deployment/exposure: 2026-02-27, receipt record-dfac735827; 20% of eligible production accounts. The original observation is history/evidence/record-eba6effdbc.md. Later review: history/evidence/record-02f1025afe.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
