# record-3915f076de: timeout report
Alias used in the design review: shared worker. Local variant: record-5824296480.14.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-ab94526b8b. Deployment/exposure: 2026-04-05, receipt record-6b98401f3e; 5% of eligible production accounts. The original observation is history/evidence/record-7a8e0e6bc1.md. Later review: history/evidence/record-c6e21fea4e.md.
Disposition recorded after the first window: Disabled 2026-04-16, receipt record-b657d49fd3, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
