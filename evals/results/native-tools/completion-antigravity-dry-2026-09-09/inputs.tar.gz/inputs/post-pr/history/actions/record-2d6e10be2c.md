# record-2d6e10be2c: retry dashboard
Alias used in the design review: worker routing. Local variant: record-e5c0a618bf.16.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-09: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-0905a653f2. Deployment/exposure: 2026-04-12, receipt record-b3e8d5d575; 15% of eligible production accounts. The original observation is history/evidence/record-d464e256de.md. Later review: history/evidence/record-580591bbaf.md.
Disposition recorded after the first window: Rolled back 2026-04-20, receipt record-e5f0814fcb, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
