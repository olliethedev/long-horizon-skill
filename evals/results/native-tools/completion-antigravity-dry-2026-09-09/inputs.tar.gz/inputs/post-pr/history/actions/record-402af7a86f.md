# record-402af7a86f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-33d493a561.9.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-07: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-afa6b085bb. Deployment/exposure: 2026-07-10, receipt record-a40e9bb9f3; 10% of eligible production accounts. The original observation is history/evidence/record-cd5dc78c06.md. Later review: history/evidence/record-d813e94225.md.
Disposition recorded after the first window: Rolled back 2026-07-22, receipt record-0f2cafd297, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
