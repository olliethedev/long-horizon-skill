# record-240cfd883d: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-ca17f3b817.2.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-42a93e623a. Deployment/exposure: 2026-04-28, receipt record-cfb0c7d514; 20% of eligible production accounts. The original observation is history/evidence/record-715cc01304.md. Later review: history/evidence/record-4679fb02a2.md.
Disposition recorded after the first window: Disabled 2026-05-09, receipt record-78576939ff, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
