# record-380d9e65b4: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-ca17f3b817.3.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-11: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-1996786f17. Deployment/exposure: 2026-04-14, receipt record-2b8a8a4564; 25% of eligible production accounts. The original observation is history/evidence/record-047efdcbff.md. Later review: history/evidence/record-22389fe97e.md.
Disposition recorded after the first window: Rolled back 2026-04-22, receipt record-38126ec493, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
