# record-406acd5754: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-3158237b52.4.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-30: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-1c0749c06c. Deployment/exposure: 2026-08-02, receipt record-2a3c931912; 25% of eligible production accounts. The original observation is history/evidence/record-6994c3e682.md. Later review: history/evidence/record-d31346106c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
