# record-2c3ad05080: Lantern
Alias used in the design review: Candle retry patch. Local variant: record-4f54812b4a.4.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-21: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-0a606e3191. Deployment/exposure: 2026-06-24, receipt record-21a012857d; 5% of eligible production accounts. The original observation is history/evidence/record-3d99bb9764.md. Later review: history/evidence/record-526a0531d7.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
