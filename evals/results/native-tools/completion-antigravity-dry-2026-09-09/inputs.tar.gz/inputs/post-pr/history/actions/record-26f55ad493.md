# record-26f55ad493: timeout report
Alias used in the design review: shared worker. Local variant: record-e5c0a618bf.13.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-07: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-8163bce1db. Deployment/exposure: 2026-05-10, receipt record-f886336da9; 5% of eligible production accounts. The original observation is history/evidence/record-56cce97219.md. Later review: history/evidence/record-6a29519d15.md.
Disposition recorded after the first window: Disabled 2026-05-21, receipt record-bbba08d4b0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
