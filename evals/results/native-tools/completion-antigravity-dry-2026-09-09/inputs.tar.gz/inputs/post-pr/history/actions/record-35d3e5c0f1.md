# record-35d3e5c0f1: queue retry fix
Alias used in the design review: Lantern. Local variant: record-ca17f3b817.11.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-07: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-6908259211. Deployment/exposure: 2026-07-10, receipt record-58fd53d2ad; 10% of eligible production accounts. The original observation is history/evidence/record-c9c8516303.md. Later review: history/evidence/record-60193e2509.md.
Disposition recorded after the first window: Disabled 2026-07-25, receipt record-5a9f7b04a9, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
