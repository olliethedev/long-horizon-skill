# record-36d6d46dd9: dedupe collisions
Alias used in the design review: timeout report. Local variant: record-3158237b52.2.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-25: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-56ee0507d2. Deployment/exposure: 2026-07-28, receipt record-8ba60195da; 25% of eligible production accounts. The original observation is history/evidence/record-568b0a76e1.md. Later review: history/evidence/record-c5832760fc.md.
Disposition recorded after the first window: Rolled back 2026-08-09, receipt record-2493886b81, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
