# record-3384b66a2f: Candle retry patch
Alias used in the design review: dedupe collisions. Local variant: record-c152fdc842.12.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-21: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-f6805fc6de. Deployment/exposure: 2026-07-24, receipt record-1ddf4b59aa; 5% of eligible production accounts. The original observation is history/evidence/record-a0d54a4b4f.md. Later review: history/evidence/record-31c58883b3.md.
Disposition recorded after the first window: Rolled back 2026-08-05, receipt record-3f08996ee2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
