# record-1450a5ba99: large export
Alias used in the design review: CSV download. Local variant: record-dc36d78d37.16.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-27: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-26446bd044. Deployment/exposure: 2026-07-30, receipt record-6ffe955aa0; 10% of eligible production accounts. The original observation is history/evidence/record-aff6bbb9b8.md. Later review: history/evidence/record-2dc00c5e36.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
