# record-1e49cf6129: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-8a4527a255.13.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-19: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-cf3baeae21. Deployment/exposure: 2026-06-22, receipt record-f5fe5e31dc; 20% of eligible production accounts. The original observation is history/evidence/record-dfbc411c5b.md. Later review: history/evidence/record-2fd3273fc0.md.
Disposition recorded after the first window: Rolled back 2026-06-30, receipt record-27d8a98d69, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
