# record-2e9eada238: full ledger export
Alias used in the design review: workspace dump. Local variant: record-3218bfc161.3.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-7db57bd88b. Deployment/exposure: 2026-04-10, receipt record-8aa2ad2cb5; 5% of eligible production accounts. The original observation is history/evidence/record-01b1d1421d.md. Later review: history/evidence/record-44fd54afb8.md.
Disposition recorded after the first window: Disabled 2026-04-21, receipt record-f295506361, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
