# record-2ac1b99359: export progress
Alias used in the design review: full ledger export. Local variant: record-37bfea4d06.11.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-c662a4acce. Deployment/exposure: 2026-07-27, receipt record-fee24f10fa; 20% of eligible production accounts. The original observation is history/evidence/record-f8e6cae80e.md. Later review: history/evidence/record-ef4f1abb45.md.
Disposition recorded after the first window: Disabled 2026-08-11, receipt record-869e98274d, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
