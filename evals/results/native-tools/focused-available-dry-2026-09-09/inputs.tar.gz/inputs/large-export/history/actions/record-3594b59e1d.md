# record-3594b59e1d: CSV download
Alias used in the design review: NDJSON. Local variant: record-3218bfc161.14.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-13: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-ec52913351. Deployment/exposure: 2026-06-16, receipt record-81ed05c012; 15% of eligible production accounts. The original observation is history/evidence/record-956dca7614.md. Later review: history/evidence/record-b8ae45680b.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-25; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
