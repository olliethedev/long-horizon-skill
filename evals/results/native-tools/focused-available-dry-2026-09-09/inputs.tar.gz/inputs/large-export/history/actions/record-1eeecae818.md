# record-1eeecae818: NDJSON
Alias used in the design review: export progress. Local variant: record-2d97151e45.14.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-da89d0b8af. Deployment/exposure: 2026-06-21, receipt record-2d1abc6339; 15% of eligible production accounts. The original observation is history/evidence/record-506ff12dfc.md. Later review: history/evidence/record-b182097b44.md.
Disposition recorded after the first window: Rolled back 2026-06-29, receipt record-326c3c3257, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
