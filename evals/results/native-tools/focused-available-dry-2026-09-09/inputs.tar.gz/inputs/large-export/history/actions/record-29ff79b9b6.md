# record-29ff79b9b6: NDJSON
Alias used in the design review: export progress. Local variant: record-dc36d78d37.8.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-a3370f8547. Deployment/exposure: 2026-06-21, receipt record-de8a9857ab; 15% of eligible production accounts. The original observation is history/evidence/record-765d9e9741.md. Later review: history/evidence/record-b392145dab.md.
Disposition recorded after the first window: Rolled back 2026-06-29, receipt record-561b6a844e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
