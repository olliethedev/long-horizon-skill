# record-266bfb46d4: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.14.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-09: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-7ba8314172. Deployment/exposure: 2026-03-12, receipt record-8f62dd9e36; 10% of eligible production accounts. The original observation is history/evidence/record-f0cc7b6a1b.md. Later review: history/evidence/record-ea02969458.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
