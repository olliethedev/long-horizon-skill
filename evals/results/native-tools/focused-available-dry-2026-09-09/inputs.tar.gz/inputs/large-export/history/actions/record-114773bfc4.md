# record-114773bfc4: full ledger export
Alias used in the design review: workspace dump. Local variant: record-3218bfc161.6.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-f616289864. Deployment/exposure: 2026-02-19, receipt record-e8e0bf006b; 5% of eligible production accounts. The original observation is history/evidence/record-fb06c5dcf4.md. Later review: history/evidence/record-511e8d2ce6.md.
Disposition recorded after the first window: Rolled back 2026-02-27, receipt record-fbdb8c9910, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
