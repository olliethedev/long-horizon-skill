# record-3bc22c0fb5: CSV download
Alias used in the design review: NDJSON. Local variant: record-dc36d78d37.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-cffd3b5564. Deployment/exposure: 2026-04-08, receipt record-e26bd75d50; 20% of eligible production accounts. The original observation is history/evidence/record-d8497d57c2.md. Later review: history/evidence/record-d8c71cda73.md.
Disposition recorded after the first window: Rolled back 2026-04-16, receipt record-c7c12cd3ed, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
