# record-12d1abf2d7: large export
Alias used in the design review: CSV download. Local variant: record-9e15273a6e.8.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-30: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-7bc7b90d4f. Deployment/exposure: 2026-07-03, receipt record-4b8d90bf51; 25% of eligible production accounts. The original observation is history/evidence/record-97bae461f9.md. Later review: history/evidence/record-34a625bb17.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-12; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
