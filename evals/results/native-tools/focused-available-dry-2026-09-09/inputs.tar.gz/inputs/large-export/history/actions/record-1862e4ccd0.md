# record-1862e4ccd0: large export
Alias used in the design review: CSV download. Local variant: record-c480f58509.15.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-04: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-10e11cafe6. Deployment/exposure: 2026-05-07, receipt record-bda4abe5d2; 15% of eligible production accounts. The original observation is history/evidence/record-f3a6b2bb4f.md. Later review: history/evidence/record-a87e188603.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
