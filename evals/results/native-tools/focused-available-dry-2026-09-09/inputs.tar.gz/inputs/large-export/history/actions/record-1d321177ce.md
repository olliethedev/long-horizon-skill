# record-1d321177ce: NDJSON
Alias used in the design review: export progress. Local variant: record-8170dc1532.6.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-d42c1dfc55. Deployment/exposure: 2026-07-25, receipt record-8273577fb4; 10% of eligible production accounts. The original observation is history/evidence/record-d93920ee51.md. Later review: history/evidence/record-5fe4d2d84f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
