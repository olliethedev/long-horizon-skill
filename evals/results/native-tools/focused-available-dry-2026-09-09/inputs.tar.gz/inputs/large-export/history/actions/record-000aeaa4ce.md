# record-000aeaa4ce: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-2d97151e45.12.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-04: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-f112522e09. Deployment/exposure: 2026-08-07, receipt record-4e8e746b0c; 25% of eligible production accounts. The original observation is history/evidence/record-c718819e15.md. Later review: history/evidence/record-cfb0a89386.md.
Disposition recorded after the first window: Rolled back 2026-08-15, receipt record-8d50817fcb, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
