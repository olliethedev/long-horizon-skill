# record-1b0a96101b: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-37bfea4d06.16.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-31: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-26843dcdaf. Deployment/exposure: 2026-08-03, receipt record-8457ecb798; 5% of eligible production accounts. The original observation is history/evidence/record-aa4705c1ea.md. Later review: history/evidence/record-adc7fcabf3.md.
Disposition recorded after the first window: Rolled back 2026-08-11, receipt record-2377887c77, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
