# record-21bf92ab39: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.8.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-31: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-6e4cdc9461. Deployment/exposure: 2026-04-03, receipt record-99f9410fee; 20% of eligible production accounts. The original observation is history/evidence/record-1388949f3c.md. Later review: history/evidence/record-7279023b2e.md.
Disposition recorded after the first window: Rolled back 2026-04-11, receipt record-26f45196e2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
