# record-22dda80c88: Async Ledger
Alias used in the design review: large export. Local variant: record-8a4527a255.14.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-28: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-8fcdbf37a7. Deployment/exposure: 2026-03-03, receipt record-699d4f6951; 15% of eligible production accounts. The original observation is history/evidence/record-0605ff3999.md. Later review: history/evidence/record-0663677476.md.
Disposition recorded after the first window: Rolled back 2026-03-15, receipt record-c3fdaef468, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
