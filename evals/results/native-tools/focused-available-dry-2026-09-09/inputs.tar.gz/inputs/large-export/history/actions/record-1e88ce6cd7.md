# record-1e88ce6cd7: CSV download
Alias used in the design review: NDJSON. Local variant: record-9e15273a6e.8.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-24: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-8d82d0eac0. Deployment/exposure: 2026-05-27, receipt record-acd4d3c90f; 15% of eligible production accounts. The original observation is history/evidence/record-1781cc127b.md. Later review: history/evidence/record-ae76615a17.md.
Disposition recorded after the first window: Rolled back 2026-06-08, receipt record-888b3a3858, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
