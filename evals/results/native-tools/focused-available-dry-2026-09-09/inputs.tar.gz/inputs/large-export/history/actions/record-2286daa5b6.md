# record-2286daa5b6: export progress
Alias used in the design review: full ledger export. Local variant: record-37bfea4d06.16.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-03: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-312f83cfc3. Deployment/exposure: 2026-04-06, receipt record-3a90a9815e; 10% of eligible production accounts. The original observation is history/evidence/record-3e9c94d627.md. Later review: history/evidence/record-5988583c1c.md.
Disposition recorded after the first window: Disabled 2026-04-21, receipt record-eb1294c4b0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
