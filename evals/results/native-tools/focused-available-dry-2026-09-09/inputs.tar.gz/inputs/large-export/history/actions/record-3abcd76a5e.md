# record-3abcd76a5e: export progress
Alias used in the design review: full ledger export. Local variant: record-8a4527a255.12.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-03: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-a6d4f26ceb. Deployment/exposure: 2026-07-06, receipt record-b42e2a3482; 15% of eligible production accounts. The original observation is history/evidence/record-6a45c12854.md. Later review: history/evidence/record-4cf9d4b709.md.
Disposition recorded after the first window: Disabled 2026-07-17, receipt record-22e9e7f0a6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
