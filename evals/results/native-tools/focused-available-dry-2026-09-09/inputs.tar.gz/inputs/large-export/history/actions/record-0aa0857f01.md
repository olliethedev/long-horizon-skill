# record-0aa0857f01: CSV download
Alias used in the design review: NDJSON. Local variant: record-8a4527a255.0.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-25: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-4016ad97dd. Deployment/exposure: 2026-07-28, receipt record-d2f8e084d9; 25% of eligible production accounts. The original observation is history/evidence/record-7772684c56.md. Later review: history/evidence/record-542fe5a374.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-06; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
