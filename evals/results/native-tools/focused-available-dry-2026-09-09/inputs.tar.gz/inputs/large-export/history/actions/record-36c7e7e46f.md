# record-36c7e7e46f: NDJSON
Alias used in the design review: export progress. Local variant: record-c480f58509.8.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-07: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-a3d9fac677. Deployment/exposure: 2026-05-10, receipt record-a57f10c1f0; 5% of eligible production accounts. The original observation is history/evidence/record-8b9a778659.md. Later review: history/evidence/record-fbc35cf7d8.md.
Disposition recorded after the first window: Rolled back 2026-05-22, receipt record-9f28158076, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
