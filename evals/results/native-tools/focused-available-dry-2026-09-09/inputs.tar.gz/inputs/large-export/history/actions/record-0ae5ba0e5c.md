# record-0ae5ba0e5c: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-c480f58509.10.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-27: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-de18c83305. Deployment/exposure: 2026-04-30, receipt record-b95390fdfb; 5% of eligible production accounts. The original observation is history/evidence/record-b3e4ae56fd.md. Later review: history/evidence/record-5d49940ae3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
