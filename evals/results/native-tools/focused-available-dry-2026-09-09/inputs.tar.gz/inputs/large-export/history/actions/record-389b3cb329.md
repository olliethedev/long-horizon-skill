# record-389b3cb329: full ledger export
Alias used in the design review: workspace dump. Local variant: record-b3af2dc499.13.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-0e8a6286f9. Deployment/exposure: 2026-07-12, receipt record-158a9d2d87; 20% of eligible production accounts. The original observation is history/evidence/record-a8ec156c75.md. Later review: history/evidence/record-f409a00671.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-25; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
