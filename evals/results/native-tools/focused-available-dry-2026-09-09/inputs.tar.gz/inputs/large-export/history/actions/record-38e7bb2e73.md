# record-38e7bb2e73: full ledger export
Alias used in the design review: workspace dump. Local variant: record-c480f58509.9.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-24: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-25d84d0ecd. Deployment/exposure: 2026-03-27, receipt record-3d6ac87b6a; 10% of eligible production accounts. The original observation is history/evidence/record-2965d6df3f.md. Later review: history/evidence/record-8f1029bcd4.md.
Disposition recorded after the first window: Disabled 2026-04-11, receipt record-6a58b25b28, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
