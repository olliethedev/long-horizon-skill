# record-196dff76da: CSV download
Alias used in the design review: NDJSON. Local variant: record-3218bfc161.9.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-17: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-f1dea98e8c. Deployment/exposure: 2026-07-20, receipt record-37178100a6; 10% of eligible production accounts. The original observation is history/evidence/record-a9242b02d5.md. Later review: history/evidence/record-61b74d07f8.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
