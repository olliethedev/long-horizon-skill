# record-05c69ac505: full ledger export
Alias used in the design review: workspace dump. Local variant: record-2d97151e45.3.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-45b5e981f6. Deployment/exposure: 2026-06-21, receipt record-c73cb1709a; 15% of eligible production accounts. The original observation is history/evidence/record-ad22f0154f.md. Later review: history/evidence/record-27229453b6.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
