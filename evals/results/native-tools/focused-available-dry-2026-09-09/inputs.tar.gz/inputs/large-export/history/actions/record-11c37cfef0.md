# record-11c37cfef0: NDJSON
Alias used in the design review: export progress. Local variant: record-8a4527a255.1.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-135f2d04ab. Deployment/exposure: 2026-06-14, receipt record-b638b37709; 5% of eligible production accounts. The original observation is history/evidence/record-edb958c6ff.md. Later review: history/evidence/record-4b59a96ad9.md.
Disposition recorded after the first window: Rolled back 2026-06-26, receipt record-9f7ea2c331, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
