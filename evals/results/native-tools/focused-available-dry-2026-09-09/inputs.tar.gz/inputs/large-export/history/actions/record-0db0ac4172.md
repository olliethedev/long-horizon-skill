# record-0db0ac4172: full ledger export
Alias used in the design review: workspace dump. Local variant: record-3218bfc161.0.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-10: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-1fa54c7ed5. Deployment/exposure: 2026-03-13, receipt record-4ea9484770; 15% of eligible production accounts. The original observation is history/evidence/record-b92e0c2a5b.md. Later review: history/evidence/record-833d2c7e10.md.
Disposition recorded after the first window: Disabled 2026-03-28, receipt record-cea86464a6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
