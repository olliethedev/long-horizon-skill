# record-1b3be6f1f5: NDJSON
Alias used in the design review: export progress. Local variant: record-dc36d78d37.0.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-dd40624fb1. Deployment/exposure: 2026-06-27, receipt record-7b11e4c1e5; 20% of eligible production accounts. The original observation is history/evidence/record-05c3709afe.md. Later review: history/evidence/record-27c9a35f37.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
