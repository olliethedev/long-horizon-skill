# record-2a6dd08b0b: NDJSON
Alias used in the design review: export progress. Local variant: record-2d97151e45.16.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-18: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-7a35fb6277. Deployment/exposure: 2026-03-21, receipt record-01134b7bc2; 5% of eligible production accounts. The original observation is history/evidence/record-b6f7c31b15.md. Later review: history/evidence/record-cca689eec2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
