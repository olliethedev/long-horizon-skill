# record-1072f2ef6d: export progress
Alias used in the design review: full ledger export. Local variant: record-2d97151e45.5.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-12: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-6e7f0e329c. Deployment/exposure: 2026-06-15, receipt record-b5918415a7; 10% of eligible production accounts. The original observation is history/evidence/record-392b9528ea.md. Later review: history/evidence/record-860ac4a310.md.
Disposition recorded after the first window: Disabled 2026-06-26, receipt record-1dd4fb4bd8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
