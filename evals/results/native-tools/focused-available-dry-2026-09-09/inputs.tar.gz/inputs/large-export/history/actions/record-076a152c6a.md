# record-076a152c6a: NDJSON
Alias used in the design review: export progress. Local variant: record-b3af2dc499.16.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-09: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-3f5895c525. Deployment/exposure: 2026-04-12, receipt record-effe007f8d; 15% of eligible production accounts. The original observation is history/evidence/record-68d60f3625.md. Later review: history/evidence/record-8989a892cb.md.
Disposition recorded after the first window: Rolled back 2026-04-20, receipt record-77fa8b3a28, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
