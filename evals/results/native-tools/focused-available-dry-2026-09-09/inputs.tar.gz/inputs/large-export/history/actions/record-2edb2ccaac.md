# record-2edb2ccaac: CSV download
Alias used in the design review: NDJSON. Local variant: record-c480f58509.7.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-20: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-d6e584ff75. Deployment/exposure: 2026-06-23, receipt record-2970e6931e; 25% of eligible production accounts. The original observation is history/evidence/record-185afdda9a.md. Later review: history/evidence/record-2339b44548.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-02; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
