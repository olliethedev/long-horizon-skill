# record-27fe37ddfd: large export
Alias used in the design review: CSV download. Local variant: record-8a4527a255.1.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-07: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-30cb60f031. Deployment/exposure: 2026-07-10, receipt record-f8b52d22a8; 10% of eligible production accounts. The original observation is history/evidence/record-bd40c6acaa.md. Later review: history/evidence/record-8c61e8647a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
