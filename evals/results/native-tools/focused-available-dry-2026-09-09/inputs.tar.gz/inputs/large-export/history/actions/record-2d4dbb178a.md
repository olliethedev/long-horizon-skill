# record-2d4dbb178a: NDJSON
Alias used in the design review: export progress. Local variant: record-dc36d78d37.8.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-02: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-9b1e6da6ef. Deployment/exposure: 2026-03-05, receipt record-ef32e60f32; 25% of eligible production accounts. The original observation is history/evidence/record-a2b1833bb8.md. Later review: history/evidence/record-3e5af5a6e2.md.
Disposition recorded after the first window: Disabled 2026-03-20, receipt record-3ba2d9bd8c, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
