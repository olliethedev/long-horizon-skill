# record-3a89b2cd19: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-9e15273a6e.9.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-01: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-7d1a7d6686. Deployment/exposure: 2026-06-04, receipt record-f503c43170; 5% of eligible production accounts. The original observation is history/evidence/record-f4804e7523.md. Later review: history/evidence/record-91364fc069.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
