# record-1b4c525b38: full ledger export
Alias used in the design review: workspace dump. Local variant: record-3218bfc161.7.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-28: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-cc4a117d83. Deployment/exposure: 2026-05-31, receipt record-7dfed38b0f; 10% of eligible production accounts. The original observation is history/evidence/record-d42d32b010.md. Later review: history/evidence/record-a2c737ea72.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
