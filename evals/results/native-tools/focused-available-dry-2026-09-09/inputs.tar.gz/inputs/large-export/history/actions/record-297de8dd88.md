# record-297de8dd88: CSV download
Alias used in the design review: NDJSON. Local variant: record-dc36d78d37.10.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-07: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-06f52b52b8. Deployment/exposure: 2026-03-10, receipt record-bc39fdd9e1; 25% of eligible production accounts. The original observation is history/evidence/record-24ce2dbe44.md. Later review: history/evidence/record-f366cb6fa6.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
