# record-3b1d3db5c6: NDJSON
Alias used in the design review: export progress. Local variant: record-8a4527a255.4.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-1a1032b5e4. Deployment/exposure: 2026-04-25, receipt record-004a04a2bd; 5% of eligible production accounts. The original observation is history/evidence/record-db5313e7fb.md. Later review: history/evidence/record-625eda182f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-04; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
