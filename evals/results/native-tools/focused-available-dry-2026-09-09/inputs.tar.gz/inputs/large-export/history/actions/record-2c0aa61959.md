# record-2c0aa61959: large export
Alias used in the design review: CSV download. Local variant: record-8170dc1532.1.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-15: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-c418cfd973. Deployment/exposure: 2026-07-18, receipt record-0f5b29801e; 25% of eligible production accounts. The original observation is history/evidence/record-4eb775c7c5.md. Later review: history/evidence/record-5d55a30f0f.md.
Disposition recorded after the first window: Rolled back 2026-07-30, receipt record-08557fab68, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
