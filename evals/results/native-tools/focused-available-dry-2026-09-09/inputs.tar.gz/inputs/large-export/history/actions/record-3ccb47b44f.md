# record-3ccb47b44f: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-3218bfc161.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-71463c506f. Deployment/exposure: 2026-07-27, receipt record-c2135f4d02; 20% of eligible production accounts. The original observation is history/evidence/record-7275f95bba.md. Later review: history/evidence/record-ad4ea9c7c1.md.
Disposition recorded after the first window: Rolled back 2026-08-08, receipt record-49d1f74c74, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
