# record-1a80c7fe96: export progress
Alias used in the design review: full ledger export. Local variant: record-dc36d78d37.7.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-94c88368a6. Deployment/exposure: 2026-03-23, receipt record-a4b88c3157; 15% of eligible production accounts. The original observation is history/evidence/record-b867cd2fd1.md. Later review: history/evidence/record-55e268d0af.md.
Disposition recorded after the first window: Disabled 2026-04-07, receipt record-73f560dc08, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
