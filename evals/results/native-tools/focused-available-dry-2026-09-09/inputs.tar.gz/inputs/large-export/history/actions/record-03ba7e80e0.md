# record-03ba7e80e0: large export
Alias used in the design review: CSV download. Local variant: record-2d97151e45.7.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-18: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-9d7056fcc6. Deployment/exposure: 2026-02-21, receipt record-23ee3b5cc8; 15% of eligible production accounts. The original observation is history/evidence/record-386a487bbb.md. Later review: history/evidence/record-53fa43acfe.md.
Disposition recorded after the first window: Rolled back 2026-03-05, receipt record-61c140e38a, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
