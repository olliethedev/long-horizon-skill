# record-04841cca0f: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-3218bfc161.3.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-18: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-9b79a36a56. Deployment/exposure: 2026-05-21, receipt record-4ec9780f23; 10% of eligible production accounts. The original observation is history/evidence/record-c38cbf3583.md. Later review: history/evidence/record-74eb265500.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-03; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
