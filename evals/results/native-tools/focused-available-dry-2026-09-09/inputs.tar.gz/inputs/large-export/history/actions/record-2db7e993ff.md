# record-2db7e993ff: large export
Alias used in the design review: CSV download. Local variant: record-8170dc1532.16.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-24: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-207a8c623b. Deployment/exposure: 2026-03-27, receipt record-62f0064eba; 10% of eligible production accounts. The original observation is history/evidence/record-c0805b5fb0.md. Later review: history/evidence/record-47e2395698.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
