# record-36b2908fdc: full ledger export
Alias used in the design review: workspace dump. Local variant: record-dc36d78d37.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-30: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-fdfe058e37. Deployment/exposure: 2026-07-03, receipt record-b4bd2d80a2; 25% of eligible production accounts. The original observation is history/evidence/record-2878e6d29c.md. Later review: history/evidence/record-a83f6bab66.md.
Disposition recorded after the first window: Disabled 2026-07-14, receipt record-0f919027b1, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
