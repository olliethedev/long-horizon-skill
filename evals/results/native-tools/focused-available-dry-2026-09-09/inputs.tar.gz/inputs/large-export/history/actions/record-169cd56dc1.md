# record-169cd56dc1: large export
Alias used in the design review: CSV download. Local variant: record-c480f58509.3.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-30: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-63f2fc1b16. Deployment/exposure: 2026-05-03, receipt record-b07194cd62; 20% of eligible production accounts. The original observation is history/evidence/record-ea89e75913.md. Later review: history/evidence/record-5332124ea9.md.
Disposition recorded after the first window: Disabled 2026-05-14, receipt record-2a377b06bc, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
