# record-0e8931eb66: Async Ledger
Alias used in the design review: large export. Local variant: record-8a4527a255.4.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-381a295c84. Deployment/exposure: 2026-07-27, receipt record-e78d40c1f9; 20% of eligible production accounts. The original observation is history/evidence/record-88bdbf014c.md. Later review: history/evidence/record-73aae9c2c2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
