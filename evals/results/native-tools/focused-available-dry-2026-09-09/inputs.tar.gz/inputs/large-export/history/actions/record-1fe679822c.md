# record-1fe679822c: NDJSON
Alias used in the design review: export progress. Local variant: record-3218bfc161.0.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-fe00fd352b. Deployment/exposure: 2026-07-25, receipt record-15f0bcee8a; 10% of eligible production accounts. The original observation is history/evidence/record-96d02dc5df.md. Later review: history/evidence/record-46a984424f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
