# record-0fa74c6bad: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-8a4527a255.8.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-17: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-e0441eb0fd. Deployment/exposure: 2026-04-20, receipt record-c87b79a784; 5% of eligible production accounts. The original observation is history/evidence/record-f0b3333c04.md. Later review: history/evidence/record-877330d816.md.
Disposition recorded after the first window: Rolled back 2026-04-28, receipt record-9af82036c5, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
