# record-3146c2f32d: large export
Alias used in the design review: CSV download. Local variant: record-37bfea4d06.12.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-26: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-3ba790dd5c. Deployment/exposure: 2026-05-29, receipt record-0ea6722004; 25% of eligible production accounts. The original observation is history/evidence/record-aea68d5cfb.md. Later review: history/evidence/record-b309c2e462.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-11; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
