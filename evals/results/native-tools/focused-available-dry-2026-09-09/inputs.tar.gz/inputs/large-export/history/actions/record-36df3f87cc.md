# record-36df3f87cc: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-8170dc1532.15.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-d020dbc662. Deployment/exposure: 2026-04-10, receipt record-c358ac85fd; 5% of eligible production accounts. The original observation is history/evidence/record-7bcf559d3c.md. Later review: history/evidence/record-b52ca8e573.md.
Disposition recorded after the first window: Rolled back 2026-04-22, receipt record-a3c6724518, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
