# record-0e456d4ec5: NDJSON
Alias used in the design review: export progress. Local variant: record-c480f58509.4.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-03: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-cbcc039684. Deployment/exposure: 2026-06-06, receipt record-cdab57ff3b; 15% of eligible production accounts. The original observation is history/evidence/record-c9a6178eb6.md. Later review: history/evidence/record-1b0eb2d967.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
