# record-24fd8bc6e7: Async Ledger
Alias used in the design review: large export. Local variant: record-8170dc1532.14.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-5c7f08bb26. Deployment/exposure: 2026-04-28, receipt record-db20c6b8cf; 20% of eligible production accounts. The original observation is history/evidence/record-94ae3a4ef7.md. Later review: history/evidence/record-bb20adacbd.md.
Disposition recorded after the first window: Rolled back 2026-05-10, receipt record-4aab8942e7, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
