# record-1e5a9b2420: NDJSON
Alias used in the design review: export progress. Local variant: record-2d97151e45.12.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-aa26dcfff9. Deployment/exposure: 2026-07-23, receipt record-6fb637a0c6; 25% of eligible production accounts. The original observation is history/evidence/record-9f7793fb1f.md. Later review: history/evidence/record-76088cc5d5.md.
Disposition recorded after the first window: Disabled 2026-08-03, receipt record-d6545bb7f6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
