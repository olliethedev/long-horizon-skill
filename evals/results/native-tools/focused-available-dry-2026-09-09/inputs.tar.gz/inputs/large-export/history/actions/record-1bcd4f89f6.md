# record-1bcd4f89f6: NDJSON
Alias used in the design review: export progress. Local variant: record-3218bfc161.2.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-04: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-b26374dc41. Deployment/exposure: 2026-03-07, receipt record-a064b6bbbe; 10% of eligible production accounts. The original observation is history/evidence/record-74c7836d94.md. Later review: history/evidence/record-0a321cd10c.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-16; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
