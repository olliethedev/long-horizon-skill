# record-24073c8a9f: CSV download
Alias used in the design review: NDJSON. Local variant: record-b3af2dc499.3.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-25: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-b48b736ae9. Deployment/exposure: 2026-07-28, receipt record-0b20c51cbf; 25% of eligible production accounts. The original observation is history/evidence/record-1f9ce294fa.md. Later review: history/evidence/record-fd20f17d8e.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
