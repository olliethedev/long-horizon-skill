# record-14b20168cf: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-9e15273a6e.6.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-26: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-06e8cf74fe. Deployment/exposure: 2026-03-01, receipt record-50482fe577; 5% of eligible production accounts. The original observation is history/evidence/record-47f779961e.md. Later review: history/evidence/record-ad9167e41e.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
