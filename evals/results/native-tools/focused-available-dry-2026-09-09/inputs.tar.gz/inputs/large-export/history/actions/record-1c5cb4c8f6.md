# record-1c5cb4c8f6: large export
Alias used in the design review: CSV download. Local variant: record-37bfea4d06.15.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-23: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-db2a2e999c. Deployment/exposure: 2026-06-26, receipt record-0f6709a83d; 15% of eligible production accounts. The original observation is history/evidence/record-5e294f9164.md. Later review: history/evidence/record-3a211fae0a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
