# record-174ebd3aeb: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-8170dc1532.16.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-b5819e3054. Deployment/exposure: 2026-08-08, receipt record-e469d38664; 5% of eligible production accounts. The original observation is history/evidence/record-9b9f534c34.md. Later review: history/evidence/record-3c444c1485.md.
Disposition recorded after the first window: Disabled 2026-08-23, receipt record-91a3870f16, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
