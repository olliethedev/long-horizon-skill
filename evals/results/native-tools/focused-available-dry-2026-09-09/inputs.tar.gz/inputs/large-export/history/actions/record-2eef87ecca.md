# record-2eef87ecca: CSV download
Alias used in the design review: NDJSON. Local variant: record-dc36d78d37.7.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-15: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-77ced5d64c. Deployment/exposure: 2026-05-18, receipt record-fdee818b13; 20% of eligible production accounts. The original observation is history/evidence/record-d03796ea9e.md. Later review: history/evidence/record-06ee4ac9db.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
