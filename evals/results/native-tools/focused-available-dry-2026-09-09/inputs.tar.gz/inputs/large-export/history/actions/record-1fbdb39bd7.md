# record-1fbdb39bd7: Async Ledger
Alias used in the design review: large export. Local variant: record-dc36d78d37.3.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-01: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-9300574608. Deployment/exposure: 2026-05-04, receipt record-46e305fa03; 25% of eligible production accounts. The original observation is history/evidence/record-f8eeb8be1c.md. Later review: history/evidence/record-e6717a17d0.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-17; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
