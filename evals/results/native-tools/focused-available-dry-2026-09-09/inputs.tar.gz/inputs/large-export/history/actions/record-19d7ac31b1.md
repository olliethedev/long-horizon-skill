# record-19d7ac31b1: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.7.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-5316c79c6e. Deployment/exposure: 2026-06-27, receipt record-a275e2c606; 20% of eligible production accounts. The original observation is history/evidence/record-e5ba298309.md. Later review: history/evidence/record-f4a516b28e.md.
Disposition recorded after the first window: Disabled 2026-07-12, receipt record-bb14dc77e0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
