# record-0a87d5c3a9: large export
Alias used in the design review: CSV download. Local variant: record-9e15273a6e.1.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-29: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-0ef442cd66. Deployment/exposure: 2026-08-01, receipt record-ab03619021; 20% of eligible production accounts. The original observation is history/evidence/record-2585d1dd79.md. Later review: history/evidence/record-bc1e92db0c.md.
Disposition recorded after the first window: Rolled back 2026-08-09, receipt record-c40a03538f, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
