# record-274f0e6d61: full ledger export
Alias used in the design review: workspace dump. Local variant: record-9e15273a6e.7.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-16: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-f3b910e709. Deployment/exposure: 2026-04-19, receipt record-b63e406abd; 25% of eligible production accounts. The original observation is history/evidence/record-1f7bed977e.md. Later review: history/evidence/record-02a72ffb8f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-02; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
