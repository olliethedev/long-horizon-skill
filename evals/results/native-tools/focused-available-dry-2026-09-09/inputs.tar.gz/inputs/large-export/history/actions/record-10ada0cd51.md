# record-10ada0cd51: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-8170dc1532.4.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-21: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-ec87373d32. Deployment/exposure: 2026-06-24, receipt record-b4253b7cc4; 5% of eligible production accounts. The original observation is history/evidence/record-005123defc.md. Later review: history/evidence/record-e5db82dac4.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
