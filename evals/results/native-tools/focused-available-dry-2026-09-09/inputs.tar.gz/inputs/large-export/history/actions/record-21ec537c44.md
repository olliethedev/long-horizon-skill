# record-21ec537c44: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-9e15273a6e.5.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-87c56e80cc. Deployment/exposure: 2026-04-25, receipt record-e6290f5997; 5% of eligible production accounts. The original observation is history/evidence/record-c5315ad121.md. Later review: history/evidence/record-4fdeb23306.md.
Disposition recorded after the first window: Disabled 2026-05-06, receipt record-0e9f60fe64, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
