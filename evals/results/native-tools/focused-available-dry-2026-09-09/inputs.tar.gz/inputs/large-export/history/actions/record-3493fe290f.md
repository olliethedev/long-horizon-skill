# record-3493fe290f: Async Ledger
Alias used in the design review: large export. Local variant: record-dc36d78d37.4.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-24: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-866a683d3e. Deployment/exposure: 2026-05-27, receipt record-972dd7d9f8; 15% of eligible production accounts. The original observation is history/evidence/record-5d41fddb79.md. Later review: history/evidence/record-eeedc20113.md.
Disposition recorded after the first window: Disabled 2026-06-11, receipt record-d265e159af, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
