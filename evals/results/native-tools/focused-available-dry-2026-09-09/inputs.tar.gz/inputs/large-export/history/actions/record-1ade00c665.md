# record-1ade00c665: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-3218bfc161.2.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-17: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-2211a09f8b. Deployment/exposure: 2026-02-20, receipt record-50d5d988e2; 10% of eligible production accounts. The original observation is history/evidence/record-94c2935a1e.md. Later review: history/evidence/record-b979dab170.md.
Disposition recorded after the first window: Rolled back 2026-03-04, receipt record-1f732b7485, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
