# record-2d0dacb164: full ledger export
Alias used in the design review: workspace dump. Local variant: record-c480f58509.2.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-23: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-4716db4116. Deployment/exposure: 2026-03-26, receipt record-7ddd518010; 5% of eligible production accounts. The original observation is history/evidence/record-9ee7edcfd3.md. Later review: history/evidence/record-138739097a.md.
Disposition recorded after the first window: Rolled back 2026-04-07, receipt record-7d47de2dee, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
