# record-35e2a76d56: CSV download
Alias used in the design review: NDJSON. Local variant: record-dc36d78d37.0.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-13: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-b16025c952. Deployment/exposure: 2026-06-16, receipt record-34522da64f; 15% of eligible production accounts. The original observation is history/evidence/record-2922529981.md. Later review: history/evidence/record-0620cd6fef.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
