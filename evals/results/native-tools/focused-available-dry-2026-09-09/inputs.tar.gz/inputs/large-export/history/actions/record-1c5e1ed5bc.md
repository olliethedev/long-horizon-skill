# record-1c5e1ed5bc: NDJSON
Alias used in the design review: export progress. Local variant: record-8a4527a255.3.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-30: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-15775559b2. Deployment/exposure: 2026-04-02, receipt record-a7d44ffe36; 15% of eligible production accounts. The original observation is history/evidence/record-ced980811d.md. Later review: history/evidence/record-6064a2bb7b.md.
Disposition recorded after the first window: Disabled 2026-04-17, receipt record-ffa61bdb73, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
