# record-0c667eb4cc: large export
Alias used in the design review: CSV download. Local variant: record-9e15273a6e.5.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-02: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-982fd79c31. Deployment/exposure: 2026-07-05, receipt record-7e150c2a71; 10% of eligible production accounts. The original observation is history/evidence/record-d4e17a59e3.md. Later review: history/evidence/record-25e77cba0b.md.
Disposition recorded after the first window: Disabled 2026-07-20, receipt record-8070f856d0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
