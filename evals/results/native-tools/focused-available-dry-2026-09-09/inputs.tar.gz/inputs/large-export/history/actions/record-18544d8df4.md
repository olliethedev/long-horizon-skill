# record-18544d8df4: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-9e15273a6e.8.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-09: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-e2dc0a6672. Deployment/exposure: 2026-05-12, receipt record-584dd5f9b9; 15% of eligible production accounts. The original observation is history/evidence/record-b0c951cd28.md. Later review: history/evidence/record-fc479175e3.md.
Disposition recorded after the first window: Disabled 2026-05-27, receipt record-e795c62ed6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
