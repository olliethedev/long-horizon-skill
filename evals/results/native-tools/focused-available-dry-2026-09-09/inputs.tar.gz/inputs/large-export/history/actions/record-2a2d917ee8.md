# record-2a2d917ee8: full ledger export
Alias used in the design review: workspace dump. Local variant: record-2d97151e45.6.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-16: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-c5d6351bfa. Deployment/exposure: 2026-07-19, receipt record-7bb6ca7e8b; 5% of eligible production accounts. The original observation is history/evidence/record-2e76105baf.md. Later review: history/evidence/record-db5c4a0443.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
