# record-3cb61632eb: NDJSON
Alias used in the design review: export progress. Local variant: record-8a4527a255.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-7aaf54289c. Deployment/exposure: 2026-07-23, receipt record-6d9333c2f1; 25% of eligible production accounts. The original observation is history/evidence/record-20ebad56b7.md. Later review: history/evidence/record-247180cf20.md.
Disposition recorded after the first window: Disabled 2026-08-07, receipt record-36a5328209, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
