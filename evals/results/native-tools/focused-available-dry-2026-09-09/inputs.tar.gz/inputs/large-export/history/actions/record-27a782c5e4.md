# record-27a782c5e4: full ledger export
Alias used in the design review: workspace dump. Local variant: record-3218bfc161.4.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-e0e1fdceb1. Deployment/exposure: 2026-08-08, receipt record-ec88badad3; 5% of eligible production accounts. The original observation is history/evidence/record-08468bf62e.md. Later review: history/evidence/record-25bc0d8fb2.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
