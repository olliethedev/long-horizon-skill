# record-26916b8af5: CSV download
Alias used in the design review: NDJSON. Local variant: record-2d97151e45.11.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-27: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-ceb28e8deb. Deployment/exposure: 2026-06-30, receipt record-ed171a7f97; 10% of eligible production accounts. The original observation is history/evidence/record-0cd3796f6a.md. Later review: history/evidence/record-f01d6db303.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
