# record-3972eae5db: NDJSON
Alias used in the design review: export progress. Local variant: record-9e15273a6e.2.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-09: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-15c541ef21. Deployment/exposure: 2026-04-12, receipt record-d2b56d448a; 15% of eligible production accounts. The original observation is history/evidence/record-3fa9d8114a.md. Later review: history/evidence/record-b38bbae811.md.
Disposition recorded after the first window: Rolled back 2026-04-24, receipt record-c641ea1014, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
