# record-18a4cbcb85: full ledger export
Alias used in the design review: workspace dump. Local variant: record-2d97151e45.0.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-27: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-2b4a7c8e78. Deployment/exposure: 2026-07-30, receipt record-2df3ed0b92; 10% of eligible production accounts. The original observation is history/evidence/record-6741cf5fc3.md. Later review: history/evidence/record-b23f8a66e7.md.
Disposition recorded after the first window: Rolled back 2026-08-11, receipt record-7fef52d6a3, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
