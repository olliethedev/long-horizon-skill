# record-0460f1ae47: full ledger export
Alias used in the design review: workspace dump. Local variant: record-9e15273a6e.2.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-20: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-4c9d988573. Deployment/exposure: 2026-04-23, receipt record-b69fca0217; 20% of eligible production accounts. The original observation is history/evidence/record-255c53fa2f.md. Later review: history/evidence/record-92aa8d6178.md.
Disposition recorded after the first window: Rolled back 2026-05-05, receipt record-4164bcac74, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
