# record-136c5d90ca: Async Ledger
Alias used in the design review: large export. Local variant: record-dc36d78d37.7.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-21: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-7f7ed725aa. Deployment/exposure: 2026-06-24, receipt record-878902f065; 5% of eligible production accounts. The original observation is history/evidence/record-66350ed613.md. Later review: history/evidence/record-c45526f7d9.md.
Disposition recorded after the first window: Disabled 2026-07-05, receipt record-34661b1d70, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
