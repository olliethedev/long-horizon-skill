# record-1a0a0572e5: large export
Alias used in the design review: CSV download. Local variant: record-8170dc1532.11.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-27: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-39f92793fe. Deployment/exposure: 2026-04-30, receipt record-4333f89357; 5% of eligible production accounts. The original observation is history/evidence/record-7f0fe0e975.md. Later review: history/evidence/record-5fadcb552d.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
