# record-09a3f69f8e: full ledger export
Alias used in the design review: workspace dump. Local variant: record-8170dc1532.1.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-13: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-44ce26e266. Deployment/exposure: 2026-04-16, receipt record-8938a43450; 10% of eligible production accounts. The original observation is history/evidence/record-b5b6a3c82f.md. Later review: history/evidence/record-a61a78891e.md.
Disposition recorded after the first window: Rolled back 2026-04-24, receipt record-6f3175a4a5, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
