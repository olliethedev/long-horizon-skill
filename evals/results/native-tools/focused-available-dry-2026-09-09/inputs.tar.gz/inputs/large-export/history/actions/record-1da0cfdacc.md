# record-1da0cfdacc: large export
Alias used in the design review: CSV download. Local variant: record-2d97151e45.6.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-14: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-3e067ebd5b. Deployment/exposure: 2026-04-17, receipt record-2aaae1f157; 15% of eligible production accounts. The original observation is history/evidence/record-c36f60bfc0.md. Later review: history/evidence/record-47a90078e8.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-26; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
