# record-00690bb6d6: NDJSON
Alias used in the design review: export progress. Local variant: record-37bfea4d06.15.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-8f4903653b. Deployment/exposure: 2026-08-06, receipt record-a10ffa3cb5; 20% of eligible production accounts. The original observation is history/evidence/record-0736ee34a7.md. Later review: history/evidence/record-89a523b0b5.md.
Disposition recorded after the first window: Disabled 2026-08-17, receipt record-083b431a77, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
