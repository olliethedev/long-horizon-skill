# record-3b0608d8de: NDJSON
Alias used in the design review: export progress. Local variant: record-c480f58509.7.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-01: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-dea370b33c. Deployment/exposure: 2026-07-04, receipt record-b16e972421; 5% of eligible production accounts. The original observation is history/evidence/record-51a360b152.md. Later review: history/evidence/record-fb79fbec35.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
