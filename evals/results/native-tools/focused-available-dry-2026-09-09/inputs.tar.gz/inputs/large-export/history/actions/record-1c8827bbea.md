# record-1c8827bbea: large export
Alias used in the design review: CSV download. Local variant: record-dc36d78d37.7.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-15: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-9a90b12339. Deployment/exposure: 2026-04-18, receipt record-d03eec7e36; 20% of eligible production accounts. The original observation is history/evidence/record-a15166acab.md. Later review: history/evidence/record-9d891ccb3a.md.
Disposition recorded after the first window: Rolled back 2026-04-30, receipt record-dbf8863cfc, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
