# record-1b20dff6a9: full ledger export
Alias used in the design review: workspace dump. Local variant: record-dc36d78d37.4.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-d30d02f9a6. Deployment/exposure: 2026-04-05, receipt record-cfe23093e8; 5% of eligible production accounts. The original observation is history/evidence/record-643b6a07af.md. Later review: history/evidence/record-dcbfd71a02.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-18; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
