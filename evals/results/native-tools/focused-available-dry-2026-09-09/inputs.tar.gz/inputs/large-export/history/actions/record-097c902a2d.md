# record-097c902a2d: NDJSON
Alias used in the design review: export progress. Local variant: record-8170dc1532.16.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-26: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-8a01b52fff. Deployment/exposure: 2026-03-01, receipt record-91e63137a8; 5% of eligible production accounts. The original observation is history/evidence/record-1801585ecd.md. Later review: history/evidence/record-896df3b324.md.
Disposition recorded after the first window: Rolled back 2026-03-13, receipt record-835a23cfc9, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
