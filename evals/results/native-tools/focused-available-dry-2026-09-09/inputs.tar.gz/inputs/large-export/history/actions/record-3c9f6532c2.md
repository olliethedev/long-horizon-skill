# record-3c9f6532c2: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.12.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-04: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-32bad295e2. Deployment/exposure: 2026-03-07, receipt record-801ca96d4a; 10% of eligible production accounts. The original observation is history/evidence/record-208295345a.md. Later review: history/evidence/record-3dbe8ffffa.md.
Disposition recorded after the first window: Disabled 2026-03-22, receipt record-44a8278a38, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
