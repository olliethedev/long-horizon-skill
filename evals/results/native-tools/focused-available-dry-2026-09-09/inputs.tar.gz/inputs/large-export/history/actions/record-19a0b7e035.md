# record-19a0b7e035: NDJSON
Alias used in the design review: export progress. Local variant: record-8170dc1532.5.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-388cace66b. Deployment/exposure: 2026-04-26, receipt record-3750a7666a; 10% of eligible production accounts. The original observation is history/evidence/record-70d1325462.md. Later review: history/evidence/record-ac4efa7262.md.
Disposition recorded after the first window: Rolled back 2026-05-08, receipt record-74ae844d70, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
