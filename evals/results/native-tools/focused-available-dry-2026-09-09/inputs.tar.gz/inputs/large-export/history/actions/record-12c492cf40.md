# record-12c492cf40: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-dc36d78d37.3.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-21: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-89f12c30a6. Deployment/exposure: 2026-03-24, receipt record-27bdbd347e; 20% of eligible production accounts. The original observation is history/evidence/record-e632d58e25.md. Later review: history/evidence/record-0fdef40728.md.
Disposition recorded after the first window: Disabled 2026-04-04, receipt record-7df9eb98b6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
