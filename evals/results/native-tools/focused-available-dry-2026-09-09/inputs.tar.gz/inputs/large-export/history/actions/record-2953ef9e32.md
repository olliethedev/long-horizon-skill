# record-2953ef9e32: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.11.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-45d19a5134. Deployment/exposure: 2026-08-06, receipt record-f1a158aa74; 20% of eligible production accounts. The original observation is history/evidence/record-0738817160.md. Later review: history/evidence/record-9344c8cf29.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
