# record-0cb9fcb582: large export
Alias used in the design review: CSV download. Local variant: record-8170dc1532.13.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-24: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-2c91f96b7f. Deployment/exposure: 2026-02-27, receipt record-d744bb6623; 20% of eligible production accounts. The original observation is history/evidence/record-0d52e1db4f.md. Later review: history/evidence/record-eb3649aeda.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-12; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
