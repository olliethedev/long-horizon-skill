# record-081864abc1: full ledger export
Alias used in the design review: workspace dump. Local variant: record-c480f58509.4.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-14: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-6a3d2e3428. Deployment/exposure: 2026-07-17, receipt record-1336d9df94; 20% of eligible production accounts. The original observation is history/evidence/record-a965fefcff.md. Later review: history/evidence/record-e11e513230.md.
Disposition recorded after the first window: Disabled 2026-08-01, receipt record-e796992001, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
