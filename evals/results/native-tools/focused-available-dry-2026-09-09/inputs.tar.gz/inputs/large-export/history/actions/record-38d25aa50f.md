# record-38d25aa50f: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-9e15273a6e.1.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-01: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-1e6c92bfd6. Deployment/exposure: 2026-04-04, receipt record-9c839d3263; 25% of eligible production accounts. The original observation is history/evidence/record-ee18a8018a.md. Later review: history/evidence/record-3bceb03d4b.md.
Disposition recorded after the first window: Disabled 2026-04-19, receipt record-7bc02c5e12, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
