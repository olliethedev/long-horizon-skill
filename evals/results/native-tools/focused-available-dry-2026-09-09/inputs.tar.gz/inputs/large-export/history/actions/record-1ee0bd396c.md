# record-1ee0bd396c: full ledger export
Alias used in the design review: workspace dump. Local variant: record-9e15273a6e.0.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-15: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-bf02124098. Deployment/exposure: 2026-04-18, receipt record-ece8f04de1; 20% of eligible production accounts. The original observation is history/evidence/record-be2732f9fe.md. Later review: history/evidence/record-664739fcc9.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
