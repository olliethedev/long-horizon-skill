# record-144c4a4f80: NDJSON
Alias used in the design review: export progress. Local variant: record-dc36d78d37.10.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-23: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-a1b20e4f46. Deployment/exposure: 2026-07-26, receipt record-73e339afa9; 15% of eligible production accounts. The original observation is history/evidence/record-be9c267a9e.md. Later review: history/evidence/record-e79dcba2d8.md.
Disposition recorded after the first window: Rolled back 2026-08-07, receipt record-75fb9dd080, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
