# record-3cc669ac4f: full ledger export
Alias used in the design review: workspace dump. Local variant: record-9e15273a6e.5.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-d7a771f130. Deployment/exposure: 2026-03-15, receipt record-7a7c4072ef; 25% of eligible production accounts. The original observation is history/evidence/record-2db87c4ed3.md. Later review: history/evidence/record-fa61f3082b.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
