# record-30fe285c68: Async Ledger
Alias used in the design review: large export. Local variant: record-8170dc1532.2.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-27: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-d57d1d530c. Deployment/exposure: 2026-06-30, receipt record-1b299db409; 10% of eligible production accounts. The original observation is history/evidence/record-57e8c2284a.md. Later review: history/evidence/record-9af797676e.md.
Disposition recorded after the first window: Rolled back 2026-07-12, receipt record-6f0c409000, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
