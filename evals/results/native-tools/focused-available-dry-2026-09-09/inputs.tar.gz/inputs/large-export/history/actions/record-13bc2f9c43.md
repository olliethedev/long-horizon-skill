# record-13bc2f9c43: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-8a4527a255.2.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-03: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-885b7c6016. Deployment/exposure: 2026-03-06, receipt record-74676377bb; 5% of eligible production accounts. The original observation is history/evidence/record-ec607c26e3.md. Later review: history/evidence/record-0158684c00.md.
Disposition recorded after the first window: Rolled back 2026-03-14, receipt record-7de6e5d084, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
