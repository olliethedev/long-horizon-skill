# record-15486da58b: Async Ledger
Alias used in the design review: large export. Local variant: record-dc36d78d37.10.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-02: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-6d5479a45c. Deployment/exposure: 2026-05-05, receipt record-107da4fc85; 5% of eligible production accounts. The original observation is history/evidence/record-494248aec0.md. Later review: history/evidence/record-d150ff1a9f.md.
Disposition recorded after the first window: Rolled back 2026-05-13, receipt record-cb4558b271, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
