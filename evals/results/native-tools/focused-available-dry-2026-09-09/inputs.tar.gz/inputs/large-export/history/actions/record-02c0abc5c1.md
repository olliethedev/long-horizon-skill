# record-02c0abc5c1: full ledger export
Alias used in the design review: workspace dump. Local variant: record-8170dc1532.11.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-29: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-d028365593. Deployment/exposure: 2026-07-02, receipt record-6b5fdf3ef7; 20% of eligible production accounts. The original observation is history/evidence/record-396266d551.md. Later review: history/evidence/record-a6af10949a.md.
Disposition recorded after the first window: Rolled back 2026-07-14, receipt record-489d0d756e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
