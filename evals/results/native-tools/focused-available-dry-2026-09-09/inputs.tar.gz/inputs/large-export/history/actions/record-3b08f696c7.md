# record-3b08f696c7: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-c480f58509.12.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-24: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-4f86e10472. Deployment/exposure: 2026-02-27, receipt record-a931d249b7; 20% of eligible production accounts. The original observation is history/evidence/record-5d140f35e7.md. Later review: history/evidence/record-b52af5c260.md.
Disposition recorded after the first window: Rolled back 2026-03-11, receipt record-df703110a8, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
