# record-1dc8e4bad6: CSV download
Alias used in the design review: NDJSON. Local variant: record-2d97151e45.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-f5b8114a12. Deployment/exposure: 2026-04-08, receipt record-62961f55db; 20% of eligible production accounts. The original observation is history/evidence/record-92c7cda8c1.md. Later review: history/evidence/record-58f168604e.md.
Disposition recorded after the first window: Rolled back 2026-04-16, receipt record-75d81c34fe, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
