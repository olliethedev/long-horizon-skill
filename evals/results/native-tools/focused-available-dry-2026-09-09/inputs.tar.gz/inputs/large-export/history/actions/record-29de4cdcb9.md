# record-29de4cdcb9: NDJSON
Alias used in the design review: export progress. Local variant: record-8170dc1532.3.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-25: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-989ee7871d. Deployment/exposure: 2026-05-28, receipt record-f90e642943; 20% of eligible production accounts. The original observation is history/evidence/record-cee96766a3.md. Later review: history/evidence/record-986e1d56bf.md.
Disposition recorded after the first window: Disabled 2026-06-12, receipt record-ded073971d, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
