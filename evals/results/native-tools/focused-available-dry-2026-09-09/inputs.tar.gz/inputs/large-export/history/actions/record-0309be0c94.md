# record-0309be0c94: large export
Alias used in the design review: CSV download. Local variant: record-37bfea4d06.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-20: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-884270da2e. Deployment/exposure: 2026-05-23, receipt record-fe058f3bed; 20% of eligible production accounts. The original observation is history/evidence/record-c3a02ca920.md. Later review: history/evidence/record-0750a35602.md.
Disposition recorded after the first window: Rolled back 2026-05-31, receipt record-ad3948dd82, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
