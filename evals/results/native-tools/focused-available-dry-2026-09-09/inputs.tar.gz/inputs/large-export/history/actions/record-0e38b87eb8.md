# record-0e38b87eb8: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-37bfea4d06.13.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-19: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-8ad2a83d31. Deployment/exposure: 2026-02-22, receipt record-a6cf6ae9d2; 20% of eligible production accounts. The original observation is history/evidence/record-85c97db1f5.md. Later review: history/evidence/record-6171050980.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
