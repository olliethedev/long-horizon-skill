# record-38214e99de: NDJSON
Alias used in the design review: export progress. Local variant: record-c480f58509.8.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-82e2b47728. Deployment/exposure: 2026-04-10, receipt record-24cdedf986; 5% of eligible production accounts. The original observation is history/evidence/record-72f9064cb9.md. Later review: history/evidence/record-2b34cf414c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
