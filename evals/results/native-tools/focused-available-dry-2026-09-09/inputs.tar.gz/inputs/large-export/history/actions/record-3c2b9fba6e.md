# record-3c2b9fba6e: CSV download
Alias used in the design review: NDJSON. Local variant: record-c480f58509.1.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-f2b18e81cd. Deployment/exposure: 2026-04-28, receipt record-083a14c82b; 20% of eligible production accounts. The original observation is history/evidence/record-5f6f79ed6d.md. Later review: history/evidence/record-0124d6f808.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
