# record-0a4e9d6542: NDJSON
Alias used in the design review: export progress. Local variant: record-37bfea4d06.4.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-23: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-1b375bacb8. Deployment/exposure: 2026-07-26, receipt record-7b4a335f77; 15% of eligible production accounts. The original observation is history/evidence/record-2c1c803430.md. Later review: history/evidence/record-c3d3460e38.md.
Disposition recorded after the first window: Rolled back 2026-08-07, receipt record-b5921b9d2a, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
