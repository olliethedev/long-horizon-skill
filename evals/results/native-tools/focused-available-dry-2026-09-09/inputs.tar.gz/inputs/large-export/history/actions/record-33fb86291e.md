# record-33fb86291e: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-37bfea4d06.16.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-25: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-7c01b37d33. Deployment/exposure: 2026-05-28, receipt record-b88716dfee; 20% of eligible production accounts. The original observation is history/evidence/record-86b5ce3d6c.md. Later review: history/evidence/record-deeedab1a3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-06; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
