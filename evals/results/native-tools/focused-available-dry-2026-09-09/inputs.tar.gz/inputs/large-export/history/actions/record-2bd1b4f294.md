# record-2bd1b4f294: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-37bfea4d06.11.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-23: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-e9974a3ce2. Deployment/exposure: 2026-03-26, receipt record-07008c8be4; 5% of eligible production accounts. The original observation is history/evidence/record-328670bea8.md. Later review: history/evidence/record-a80a6dbe41.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-04; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
