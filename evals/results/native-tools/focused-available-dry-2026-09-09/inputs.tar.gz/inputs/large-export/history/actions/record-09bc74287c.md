# record-09bc74287c: NDJSON
Alias used in the design review: export progress. Local variant: record-dc36d78d37.3.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-05: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-ae65bc033a. Deployment/exposure: 2026-05-08, receipt record-bf21f3427b; 20% of eligible production accounts. The original observation is history/evidence/record-a30b8558e9.md. Later review: history/evidence/record-1d55c01949.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
