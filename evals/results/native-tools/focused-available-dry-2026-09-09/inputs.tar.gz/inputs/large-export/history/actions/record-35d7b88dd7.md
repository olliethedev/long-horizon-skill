# record-35d7b88dd7: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.11.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-28: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-fe2cacbfcc. Deployment/exposure: 2026-05-01, receipt record-dc69a87cca; 10% of eligible production accounts. The original observation is history/evidence/record-9d1ae259ec.md. Later review: history/evidence/record-8fd3a812d4.md.
Disposition recorded after the first window: Rolled back 2026-05-13, receipt record-5adf6f9cbc, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
