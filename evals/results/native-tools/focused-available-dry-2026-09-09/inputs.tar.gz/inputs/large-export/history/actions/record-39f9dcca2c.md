# record-39f9dcca2c: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-2d97151e45.12.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-18: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-c7b31ea99e. Deployment/exposure: 2026-04-21, receipt record-6986aa5fcb; 10% of eligible production accounts. The original observation is history/evidence/record-8155ce9ca0.md. Later review: history/evidence/record-1f5ed05ac1.md.
Disposition recorded after the first window: Disabled 2026-05-06, receipt record-a47ff3d50d, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
