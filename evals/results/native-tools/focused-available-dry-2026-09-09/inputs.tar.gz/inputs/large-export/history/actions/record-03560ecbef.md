# record-03560ecbef: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-c480f58509.2.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-25: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-dffc7cc5f1. Deployment/exposure: 2026-02-28, receipt record-42ea848449; 25% of eligible production accounts. The original observation is history/evidence/record-003865c57b.md. Later review: history/evidence/record-40dee84d3d.md.
Disposition recorded after the first window: Disabled 2026-03-15, receipt record-89c8e443ca, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
