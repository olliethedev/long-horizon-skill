# record-1c71380e3c: full ledger export
Alias used in the design review: workspace dump. Local variant: record-b3af2dc499.9.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-19: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-47d1bf6b8d. Deployment/exposure: 2026-05-22, receipt record-7d9ebca390; 15% of eligible production accounts. The original observation is history/evidence/record-04d090d03c.md. Later review: history/evidence/record-eb466413ba.md.
Disposition recorded after the first window: Disabled 2026-06-06, receipt record-a4f00e4fd9, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
