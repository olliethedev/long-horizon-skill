# record-37bbce611d: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-b3af2dc499.9.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-12: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-14145422f3. Deployment/exposure: 2026-04-15, receipt record-53d962598f; 5% of eligible production accounts. The original observation is history/evidence/record-f242bc4659.md. Later review: history/evidence/record-61a9f69fd9.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
