# record-0eddbb978a: large export
Alias used in the design review: CSV download. Local variant: record-c480f58509.6.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-28: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-f6cddfc86c. Deployment/exposure: 2026-05-31, receipt record-bd9a40e2e3; 10% of eligible production accounts. The original observation is history/evidence/record-93b064defd.md. Later review: history/evidence/record-bc35e63b5a.md.
Disposition recorded after the first window: Disabled 2026-06-15, receipt record-139171cece, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
