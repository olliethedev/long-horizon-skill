# record-2292d5ca72: CSV download
Alias used in the design review: NDJSON. Local variant: record-b3af2dc499.1.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-20: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-eebfe57588. Deployment/exposure: 2026-06-23, receipt record-da9e24faa1; 25% of eligible production accounts. The original observation is history/evidence/record-d2154aa911.md. Later review: history/evidence/record-1d6fb5fa9f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-02; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
