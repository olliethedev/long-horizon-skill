# record-0f9b9c3436: full ledger export
Alias used in the design review: workspace dump. Local variant: record-8170dc1532.7.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-08: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-ff73d4e036. Deployment/exposure: 2026-06-11, receipt record-3c7cc62ac0; 15% of eligible production accounts. The original observation is history/evidence/record-3a3732e318.md. Later review: history/evidence/record-dc8d25cae5.md.
Disposition recorded after the first window: Rolled back 2026-06-19, receipt record-6cce0b573d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
