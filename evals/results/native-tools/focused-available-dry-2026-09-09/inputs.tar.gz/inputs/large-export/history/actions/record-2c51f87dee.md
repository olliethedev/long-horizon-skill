# record-2c51f87dee: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-9e15273a6e.3.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-23: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-9b15eb7394. Deployment/exposure: 2026-06-26, receipt record-f75db46f0c; 15% of eligible production accounts. The original observation is history/evidence/record-b403e3a4df.md. Later review: history/evidence/record-b5d2f0033c.md.
Disposition recorded after the first window: Rolled back 2026-07-04, receipt record-9017530013, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
