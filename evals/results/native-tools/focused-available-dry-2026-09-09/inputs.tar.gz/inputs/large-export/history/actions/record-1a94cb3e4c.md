# record-1a94cb3e4c: full ledger export
Alias used in the design review: workspace dump. Local variant: record-9e15273a6e.13.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-25: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-6b23997506. Deployment/exposure: 2026-03-28, receipt record-82e68bd31b; 15% of eligible production accounts. The original observation is history/evidence/record-60f7c801ed.md. Later review: history/evidence/record-c86a55774c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
