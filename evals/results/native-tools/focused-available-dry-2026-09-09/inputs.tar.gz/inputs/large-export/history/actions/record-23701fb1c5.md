# record-23701fb1c5: CSV download
Alias used in the design review: NDJSON. Local variant: record-dc36d78d37.12.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-11: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-b319a39e60. Deployment/exposure: 2026-04-14, receipt record-942be9f96c; 25% of eligible production accounts. The original observation is history/evidence/record-b5421b0ef2.md. Later review: history/evidence/record-ddc1e107b6.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
