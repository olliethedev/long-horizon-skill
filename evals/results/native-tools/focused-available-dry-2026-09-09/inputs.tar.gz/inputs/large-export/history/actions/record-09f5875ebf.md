# record-09f5875ebf: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-37bfea4d06.0.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-17: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-e274518156. Deployment/exposure: 2026-06-20, receipt record-69ef2e4539; 10% of eligible production accounts. The original observation is history/evidence/record-96a2268a81.md. Later review: history/evidence/record-395b9aa2db.md.
Disposition recorded after the first window: Disabled 2026-07-01, receipt record-ecadda3f2f, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
