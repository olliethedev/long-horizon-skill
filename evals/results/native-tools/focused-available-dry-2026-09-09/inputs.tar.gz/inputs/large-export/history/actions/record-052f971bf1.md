# record-052f971bf1: large export
Alias used in the design review: CSV download. Local variant: record-c480f58509.5.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-05: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-a067d4f0dc. Deployment/exposure: 2026-05-08, receipt record-6caae15666; 20% of eligible production accounts. The original observation is history/evidence/record-a1325df48e.md. Later review: history/evidence/record-9170cfe38a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
