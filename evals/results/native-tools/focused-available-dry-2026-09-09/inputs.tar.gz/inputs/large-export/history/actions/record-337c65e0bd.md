# record-337c65e0bd: export progress
Alias used in the design review: full ledger export. Local variant: record-3218bfc161.12.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-19: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-17ccf18bb0. Deployment/exposure: 2026-07-22, receipt record-9044bc2b02; 20% of eligible production accounts. The original observation is history/evidence/record-f9ee4c6009.md. Later review: history/evidence/record-fe058e3e0b.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-31; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
