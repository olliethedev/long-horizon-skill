# record-1fbdcf1b8a: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: record-b3af2dc499.10.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-7f08c5c3c6. Deployment/exposure: 2026-07-25, receipt record-beba5fd0f6; 10% of eligible production accounts. The original observation is history/evidence/record-95277f6e7d.md. Later review: history/evidence/record-56e487c35f.md.
Disposition recorded after the first window: Disabled 2026-08-05, receipt record-f3e4d8c696, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
