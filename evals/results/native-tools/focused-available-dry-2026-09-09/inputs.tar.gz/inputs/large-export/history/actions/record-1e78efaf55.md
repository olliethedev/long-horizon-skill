# record-1e78efaf55: NDJSON
Alias used in the design review: export progress. Local variant: record-3218bfc161.16.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-ff3633cd2f. Deployment/exposure: 2026-04-26, receipt record-50e1473d9a; 10% of eligible production accounts. The original observation is history/evidence/record-7d3120885b.md. Later review: history/evidence/record-89e65cd08a.md.
Disposition recorded after the first window: Rolled back 2026-05-08, receipt record-fd4069c1c8, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
