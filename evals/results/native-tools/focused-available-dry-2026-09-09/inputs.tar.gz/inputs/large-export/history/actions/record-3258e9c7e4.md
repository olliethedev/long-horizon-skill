# record-3258e9c7e4: CSV download
Alias used in the design review: NDJSON. Local variant: record-b3af2dc499.1.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-03: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-38f4efc220. Deployment/exposure: 2026-04-06, receipt record-53a8ecb002; 10% of eligible production accounts. The original observation is history/evidence/record-0f27a35b35.md. Later review: history/evidence/record-65c4159a4a.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
