# record-1bba581e21: Async Ledger
Alias used in the design review: large export. Local variant: record-8a4527a255.16.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-21: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-46eaa708f6. Deployment/exposure: 2026-06-24, receipt record-c8287eb438; 5% of eligible production accounts. The original observation is history/evidence/record-46a5830880.md. Later review: history/evidence/record-a13011e90f.md.
Disposition recorded after the first window: Disabled 2026-07-09, receipt record-9c8e0e5fa0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
