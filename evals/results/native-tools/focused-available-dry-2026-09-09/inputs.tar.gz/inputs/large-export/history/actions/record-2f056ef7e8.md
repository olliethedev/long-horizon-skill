# record-2f056ef7e8: full ledger export
Alias used in the design review: workspace dump. Local variant: record-c480f58509.3.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-15: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-190e842641. Deployment/exposure: 2026-04-18, receipt record-5f1864b869; 20% of eligible production accounts. The original observation is history/evidence/record-f391fd7c40.md. Later review: history/evidence/record-fa9f292926.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
