# record-2f5e43c669: CSV download
Alias used in the design review: NDJSON. Local variant: record-8170dc1532.8.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-10: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-ba71fffb40. Deployment/exposure: 2026-04-13, receipt record-498543f2b7; 20% of eligible production accounts. The original observation is history/evidence/record-6cf7c31b46.md. Later review: history/evidence/record-0c9b0c99c8.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
