# record-272ce8fb44: large export
Alias used in the design review: CSV download. Local variant: record-8170dc1532.2.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-08: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-6ae032052f. Deployment/exposure: 2026-07-11, receipt record-50a54ca652; 15% of eligible production accounts. The original observation is history/evidence/record-2465c782e0.md. Later review: history/evidence/record-15213a4c88.md.
Disposition recorded after the first window: Rolled back 2026-07-23, receipt record-18446c508d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
