# record-1fed0c49ae: export progress
Alias used in the design review: full ledger export. Local variant: record-b3af2dc499.1.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-08: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-e945291a9d. Deployment/exposure: 2026-03-11, receipt record-3e553b36cc; 5% of eligible production accounts. The original observation is history/evidence/record-f802a4f7b7.md. Later review: history/evidence/record-2223559262.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
