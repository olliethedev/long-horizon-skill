# record-17fbca8473: NDJSON
Alias used in the design review: export progress. Local variant: record-c480f58509.6.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-08: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-75c115bf2e. Deployment/exposure: 2026-06-11, receipt record-333d65e0d9; 15% of eligible production accounts. The original observation is history/evidence/record-71df1eb872.md. Later review: history/evidence/record-6799e4724c.md.
Disposition recorded after the first window: Disabled 2026-06-26, receipt record-de671f7687, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
