# record-213de6838e: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: record-3218bfc161.5.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-06: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-0f2eff1178. Deployment/exposure: 2026-03-09, receipt record-29da5ca3f9; 20% of eligible production accounts. The original observation is history/evidence/record-b820796c2e.md. Later review: history/evidence/record-8faae62a6d.md.
Disposition recorded after the first window: Rolled back 2026-03-17, receipt record-7ad9aa15e0, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
