# record-0c5d21c119: full ledger export
Alias used in the design review: workspace dump. Local variant: record-8170dc1532.6.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-10: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-8afb1fd93a. Deployment/exposure: 2026-03-13, receipt record-fd4226f840; 15% of eligible production accounts. The original observation is history/evidence/record-59b5e26e2b.md. Later review: history/evidence/record-e7c8a8e7dc.md.
Disposition recorded after the first window: Disabled 2026-03-28, receipt record-3406420dd8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
