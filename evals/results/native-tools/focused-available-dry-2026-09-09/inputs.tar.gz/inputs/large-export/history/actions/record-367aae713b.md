# record-367aae713b: CSV download
Alias used in the design review: NDJSON. Local variant: record-8170dc1532.9.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-03: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-e3de5f6c4f. Deployment/exposure: 2026-05-06, receipt record-adb0fc9661; 10% of eligible production accounts. The original observation is history/evidence/record-9ee6721073.md. Later review: history/evidence/record-715a4d4e6f.md.
Disposition recorded after the first window: Rolled back 2026-05-14, receipt record-8c9dad3e2f, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
