# record-09bb28e509: CSV download
Alias used in the design review: NDJSON. Local variant: record-9e15273a6e.9.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-28: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-21b02fc559. Deployment/exposure: 2026-03-03, receipt record-d0d73ce32c; 15% of eligible production accounts. The original observation is history/evidence/record-7fe8ad2e84.md. Later review: history/evidence/record-c6c7fe0623.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-16; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
