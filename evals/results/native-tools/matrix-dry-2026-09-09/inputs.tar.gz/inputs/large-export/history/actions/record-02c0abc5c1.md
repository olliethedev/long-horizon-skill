# record-02c0abc5c1: full ledger export
Alias used in the design review: workspace dump. Local variant: la-2.11.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-29: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-4028. Deployment/exposure: 2026-07-02, receipt rollout-exp-4028; 20% of eligible production accounts. The original observation is history/evidence/record-396266d551.md. Later review: history/evidence/record-a6af10949a.md.
Disposition recorded after the first window: Rolled back 2026-07-14, receipt rollback-exp-4028, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
