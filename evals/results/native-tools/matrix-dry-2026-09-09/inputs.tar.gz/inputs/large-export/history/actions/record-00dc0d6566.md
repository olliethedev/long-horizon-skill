# record-00dc0d6566: Async Ledger
Alias used in the design review: large export. Local variant: la-1.0.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-09: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: change-exp-4612. Deployment/exposure: 2026-05-12, receipt rollout-exp-4612; 15% of eligible production accounts. The original observation is history/evidence/record-693b5e4bbc.md. Later review: history/evidence/record-6b396cc01f.md.
Disposition recorded after the first window: Rolled back 2026-05-24, receipt rollback-exp-4612, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
