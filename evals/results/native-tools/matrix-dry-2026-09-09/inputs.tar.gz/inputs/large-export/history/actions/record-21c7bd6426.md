# record-21c7bd6426: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-9.6.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-21: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5655. Deployment/exposure: 2026-02-24, receipt rollout-exp-5655; 5% of eligible production accounts. The original observation is history/evidence/record-18ccd9ded2.md. Later review: history/evidence/record-10508da35c.md.
Disposition recorded after the first window: Disabled 2026-03-11, receipt disable-exp-5655, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
