# record-3351e1fb81: large export
Alias used in the design review: CSV download. Local variant: la-8.5.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-5348. Deployment/exposure: 2026-06-27, receipt rollout-exp-5348; 20% of eligible production accounts. The original observation is history/evidence/record-e25785bcd0.md. Later review: history/evidence/record-0768520c71.md.
Disposition recorded after the first window: Rolled back 2026-07-09, receipt rollback-exp-5348, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
