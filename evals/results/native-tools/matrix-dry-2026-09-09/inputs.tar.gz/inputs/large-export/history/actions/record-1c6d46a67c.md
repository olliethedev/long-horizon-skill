# record-1c6d46a67c: Async Ledger
Alias used in the design review: large export. Local variant: la-5.14.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-19: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-5867. Deployment/exposure: 2026-04-22, receipt rollout-exp-5867; 15% of eligible production accounts. The original observation is history/evidence/record-03c9e9e636.md. Later review: history/evidence/record-5cfcf24d73.md.
Disposition recorded after the first window: Disabled 2026-05-03, receipt disable-exp-5867, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
