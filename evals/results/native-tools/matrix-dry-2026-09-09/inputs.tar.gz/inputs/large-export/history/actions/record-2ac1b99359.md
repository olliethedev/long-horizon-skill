# record-2ac1b99359: export progress
Alias used in the design review: full ledger export. Local variant: la-8.11.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: change-exp-5303. Deployment/exposure: 2026-07-27, receipt rollout-exp-5303; 20% of eligible production accounts. The original observation is history/evidence/record-f8e6cae80e.md. Later review: history/evidence/record-ef4f1abb45.md.
Disposition recorded after the first window: Disabled 2026-08-11, receipt disable-exp-5303, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
