# record-24a90dfb99: NDJSON
Alias used in the design review: export progress. Local variant: la-2.14.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-16: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5000. Deployment/exposure: 2026-07-19, receipt rollout-exp-5000; 5% of eligible production accounts. The original observation is history/evidence/record-d25e0e0ffd.md. Later review: history/evidence/record-3c2d691113.md.
Disposition recorded after the first window: Rolled back 2026-07-27, receipt rollback-exp-5000, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
