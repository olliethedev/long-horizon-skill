# record-20207fee4e: CSV download
Alias used in the design review: NDJSON. Local variant: la-2.3.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-31: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4190. Deployment/exposure: 2026-08-03, receipt rollout-exp-4190; 5% of eligible production accounts. The original observation is history/evidence/record-ee11c5fff0.md. Later review: history/evidence/record-db3bd085ba.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
