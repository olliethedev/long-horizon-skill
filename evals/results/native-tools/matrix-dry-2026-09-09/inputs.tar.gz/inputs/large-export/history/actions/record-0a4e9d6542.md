# record-0a4e9d6542: NDJSON
Alias used in the design review: export progress. Local variant: la-8.4.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-23: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-4412. Deployment/exposure: 2026-07-26, receipt rollout-exp-4412; 15% of eligible production accounts. The original observation is history/evidence/record-2c1c803430.md. Later review: history/evidence/record-c3d3460e38.md.
Disposition recorded after the first window: Rolled back 2026-08-07, receipt rollback-exp-4412, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
