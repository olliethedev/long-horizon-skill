# record-3a562fad34: NDJSON
Alias used in the design review: export progress. Local variant: la-3.6.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-5145. Deployment/exposure: 2026-08-08, receipt rollout-exp-5145; 5% of eligible production accounts. The original observation is history/evidence/record-74e87807db.md. Later review: history/evidence/record-aa87fe28fc.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-17; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
