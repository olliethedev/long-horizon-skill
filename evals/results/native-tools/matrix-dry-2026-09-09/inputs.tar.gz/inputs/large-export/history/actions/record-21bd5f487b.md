# record-21bd5f487b: export progress
Alias used in the design review: full ledger export. Local variant: la-2.6.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-02: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-4397. Deployment/exposure: 2026-08-05, receipt rollout-exp-4397; 15% of eligible production accounts. The original observation is history/evidence/record-545a3c3fb8.md. Later review: history/evidence/record-0d27a3a09f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-18; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
