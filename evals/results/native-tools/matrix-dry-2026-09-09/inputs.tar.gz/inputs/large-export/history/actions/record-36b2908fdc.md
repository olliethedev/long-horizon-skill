# record-36b2908fdc: full ledger export
Alias used in the design review: workspace dump. Local variant: la-4.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-30: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-4219. Deployment/exposure: 2026-07-03, receipt rollout-exp-4219; 25% of eligible production accounts. The original observation is history/evidence/record-2878e6d29c.md. Later review: history/evidence/record-a83f6bab66.md.
Disposition recorded after the first window: Disabled 2026-07-14, receipt disable-exp-4219, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
