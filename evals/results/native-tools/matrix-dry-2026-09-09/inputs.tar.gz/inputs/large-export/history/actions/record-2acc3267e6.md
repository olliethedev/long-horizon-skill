# record-2acc3267e6: NDJSON
Alias used in the design review: export progress. Local variant: la-8.16.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-04: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-4781. Deployment/exposure: 2026-03-07, receipt rollout-exp-4781; 10% of eligible production accounts. The original observation is history/evidence/record-19384d6e55.md. Later review: history/evidence/record-23c9a77457.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-20; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
