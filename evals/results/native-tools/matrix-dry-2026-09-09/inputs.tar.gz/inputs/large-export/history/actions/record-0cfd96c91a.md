# record-0cfd96c91a: full ledger export
Alias used in the design review: workspace dump. Local variant: la-4.14.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-07: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-5731. Deployment/exposure: 2026-07-10, receipt rollout-exp-5731; 10% of eligible production accounts. The original observation is history/evidence/record-8d2d249ad4.md. Later review: history/evidence/record-a851273b97.md.
Disposition recorded after the first window: Disabled 2026-07-21, receipt disable-exp-5731, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
