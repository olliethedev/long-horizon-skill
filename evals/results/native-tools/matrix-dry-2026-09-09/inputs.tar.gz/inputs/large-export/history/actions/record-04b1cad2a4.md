# record-04b1cad2a4: full ledger export
Alias used in the design review: workspace dump. Local variant: la-3.13.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-4965. Deployment/exposure: 2026-06-14, receipt rollout-exp-4965; 5% of eligible production accounts. The original observation is history/evidence/record-3dc500a89e.md. Later review: history/evidence/record-8d7efaf02a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
