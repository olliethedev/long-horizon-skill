# record-3a1550e2a0: full ledger export
Alias used in the design review: workspace dump. Local variant: la-5.12.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-16: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-5525. Deployment/exposure: 2026-07-19, receipt rollout-exp-5525; 5% of eligible production accounts. The original observation is history/evidence/record-660c670ddd.md. Later review: history/evidence/record-6e1eb77da4.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
