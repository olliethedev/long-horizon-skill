# record-2f1905a3ee: full ledger export
Alias used in the design review: workspace dump. Local variant: la-4.8.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-29: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-4858. Deployment/exposure: 2026-08-01, receipt rollout-exp-4858; 20% of eligible production accounts. The original observation is history/evidence/record-cadd64f7da.md. Later review: history/evidence/record-e84638e12c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
