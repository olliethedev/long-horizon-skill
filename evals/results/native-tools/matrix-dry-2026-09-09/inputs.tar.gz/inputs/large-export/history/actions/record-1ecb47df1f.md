# record-1ecb47df1f: full ledger export
Alias used in the design review: workspace dump. Local variant: la-2.6.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-27: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-4550. Deployment/exposure: 2026-05-30, receipt rollout-exp-4550; 5% of eligible production accounts. The original observation is history/evidence/record-9f42641eb1.md. Later review: history/evidence/record-8c62f6194f.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
