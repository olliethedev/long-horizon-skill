# record-0c3e675f87: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-7.6.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-29: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: change-exp-5383. Deployment/exposure: 2026-08-01, receipt rollout-exp-5383; 20% of eligible production accounts. The original observation is history/evidence/record-35c10518ce.md. Later review: history/evidence/record-a842c6ed5f.md.
Disposition recorded after the first window: Disabled 2026-08-16, receipt disable-exp-5383, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
