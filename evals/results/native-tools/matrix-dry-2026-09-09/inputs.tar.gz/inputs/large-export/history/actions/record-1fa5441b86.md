# record-1fa5441b86: large export
Alias used in the design review: CSV download. Local variant: la-9.15.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-06: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: change-exp-5511. Deployment/exposure: 2026-08-09, receipt rollout-exp-5511; 10% of eligible production accounts. The original observation is history/evidence/record-e443d9946b.md. Later review: history/evidence/record-5f51ee1dde.md.
Disposition recorded after the first window: Disabled 2026-08-24, receipt disable-exp-5511, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
