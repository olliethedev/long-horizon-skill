# record-0db58c2406: export progress
Alias used in the design review: full ledger export. Local variant: la-3.13.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-01: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-4659. Deployment/exposure: 2026-05-04, receipt rollout-exp-4659; 25% of eligible production accounts. The original observation is history/evidence/record-7b13711805.md. Later review: history/evidence/record-095b26b1a5.md.
Disposition recorded after the first window: Disabled 2026-05-15, receipt disable-exp-4659, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
