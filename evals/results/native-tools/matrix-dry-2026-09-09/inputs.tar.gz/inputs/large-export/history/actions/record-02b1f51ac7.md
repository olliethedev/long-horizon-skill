# record-02b1f51ac7: large export
Alias used in the design review: CSV download. Local variant: la-5.11.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-08: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-6272. Deployment/exposure: 2026-07-11, receipt rollout-exp-6272; 15% of eligible production accounts. The original observation is history/evidence/record-4e4f705dd5.md. Later review: history/evidence/record-006ff78da2.md.
Disposition recorded after the first window: Rolled back 2026-07-19, receipt rollback-exp-6272, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
