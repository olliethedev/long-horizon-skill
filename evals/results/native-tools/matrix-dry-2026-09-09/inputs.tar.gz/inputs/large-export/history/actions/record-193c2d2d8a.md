# record-193c2d2d8a: full ledger export
Alias used in the design review: workspace dump. Local variant: la-1.10.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-17: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4639. Deployment/exposure: 2026-03-20, receipt rollout-exp-4639; 25% of eligible production accounts. The original observation is history/evidence/record-b77c089e0d.md. Later review: history/evidence/record-76a6203674.md.
Disposition recorded after the first window: Disabled 2026-04-04, receipt disable-exp-4639, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
