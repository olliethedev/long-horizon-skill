# record-29018ec5a9: Async Ledger
Alias used in the design review: large export. Local variant: la-1.3.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-06: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-4360. Deployment/exposure: 2026-06-09, receipt rollout-exp-4360; 5% of eligible production accounts. The original observation is history/evidence/record-9f0f29efe5.md. Later review: history/evidence/record-3c1b6bb13b.md.
Disposition recorded after the first window: Rolled back 2026-06-17, receipt rollback-exp-4360, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
