# record-04f0a125fc: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-5.1.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-29: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: change-exp-5327. Deployment/exposure: 2026-05-02, receipt rollout-exp-5327; 15% of eligible production accounts. The original observation is history/evidence/record-8f94406607.md. Later review: history/evidence/record-d6507559da.md.
Disposition recorded after the first window: Disabled 2026-05-17, receipt disable-exp-5327, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
