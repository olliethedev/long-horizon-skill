# record-2fc5de8e90: large export
Alias used in the design review: CSV download. Local variant: la-2.12.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-20: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4658. Deployment/exposure: 2026-04-23, receipt rollout-exp-4658; 20% of eligible production accounts. The original observation is history/evidence/record-28c2160b69.md. Later review: history/evidence/record-d4c0fc2ae3.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
