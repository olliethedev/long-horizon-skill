# record-09a3f69f8e: full ledger export
Alias used in the design review: workspace dump. Local variant: la-2.1.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-13: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-6296. Deployment/exposure: 2026-04-16, receipt rollout-exp-6296; 10% of eligible production accounts. The original observation is history/evidence/record-b5b6a3c82f.md. Later review: history/evidence/record-a61a78891e.md.
Disposition recorded after the first window: Rolled back 2026-04-24, receipt rollback-exp-6296, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
