# record-162ac37eab: Async Ledger
Alias used in the design review: large export. Local variant: la-9.1.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-4953. Deployment/exposure: 2026-07-27, receipt rollout-exp-4953; 20% of eligible production accounts. The original observation is history/evidence/record-0b71a77929.md. Later review: history/evidence/record-4d77ecb614.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
