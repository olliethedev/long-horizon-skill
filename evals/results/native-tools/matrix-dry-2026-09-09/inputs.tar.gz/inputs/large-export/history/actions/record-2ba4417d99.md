# record-2ba4417d99: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-1.11.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-03: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-6340. Deployment/exposure: 2026-03-06, receipt rollout-exp-6340; 5% of eligible production accounts. The original observation is history/evidence/record-d917d1a1c9.md. Later review: history/evidence/record-9ca19c2e7f.md.
Disposition recorded after the first window: Rolled back 2026-03-18, receipt rollback-exp-6340, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
