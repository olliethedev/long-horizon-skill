# record-363badb348: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-1.14.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-01: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-4558. Deployment/exposure: 2026-03-04, receipt rollout-exp-4558; 20% of eligible production accounts. The original observation is history/evidence/record-750d1687f5.md. Later review: history/evidence/record-a5801e74f1.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
