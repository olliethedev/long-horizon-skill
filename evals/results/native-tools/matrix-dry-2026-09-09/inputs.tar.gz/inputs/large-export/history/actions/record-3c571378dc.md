# record-3c571378dc: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-6.3.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-17: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: change-exp-6111. Deployment/exposure: 2026-06-20, receipt rollout-exp-6111; 10% of eligible production accounts. The original observation is history/evidence/record-974998b004.md. Later review: history/evidence/record-49a47458f6.md.
Disposition recorded after the first window: Disabled 2026-07-05, receipt disable-exp-6111, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
