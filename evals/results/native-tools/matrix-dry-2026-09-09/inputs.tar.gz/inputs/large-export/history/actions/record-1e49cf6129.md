# record-1e49cf6129: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-7.13.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-19: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-5968. Deployment/exposure: 2026-06-22, receipt rollout-exp-5968; 20% of eligible production accounts. The original observation is history/evidence/record-dfbc411c5b.md. Later review: history/evidence/record-2fd3273fc0.md.
Disposition recorded after the first window: Rolled back 2026-06-30, receipt rollback-exp-5968, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
