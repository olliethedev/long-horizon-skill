# record-388f7f01e8: NDJSON
Alias used in the design review: export progress. Local variant: la-5.5.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-4175. Deployment/exposure: 2026-02-19, receipt rollout-exp-4175; 5% of eligible production accounts. The original observation is history/evidence/record-7b3eea58de.md. Later review: history/evidence/record-a0103beff3.md.
Disposition recorded after the first window: Disabled 2026-03-06, receipt disable-exp-4175, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
