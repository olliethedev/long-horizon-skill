# record-2ac5af7244: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-4.0.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-23: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-5785. Deployment/exposure: 2026-03-26, receipt rollout-exp-5785; 5% of eligible production accounts. The original observation is history/evidence/record-e377124e46.md. Later review: history/evidence/record-80854b475e.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-04; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
