# record-367aae713b: CSV download
Alias used in the design review: NDJSON. Local variant: la-2.9.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-03: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-5216. Deployment/exposure: 2026-05-06, receipt rollout-exp-5216; 10% of eligible production accounts. The original observation is history/evidence/record-9ee6721073.md. Later review: history/evidence/record-715a4d4e6f.md.
Disposition recorded after the first window: Rolled back 2026-05-14, receipt rollback-exp-5216, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
