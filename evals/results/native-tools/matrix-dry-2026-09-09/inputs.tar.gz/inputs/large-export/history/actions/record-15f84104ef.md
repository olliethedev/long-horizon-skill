# record-15f84104ef: Async Ledger
Alias used in the design review: large export. Local variant: la-4.14.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: change-exp-6343. Deployment/exposure: 2026-04-08, receipt rollout-exp-6343; 20% of eligible production accounts. The original observation is history/evidence/record-0ce0da105f.md. Later review: history/evidence/record-cba7a050bc.md.
Disposition recorded after the first window: Disabled 2026-04-23, receipt disable-exp-6343, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
