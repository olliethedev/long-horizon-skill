# record-33b1dfbc4e: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-3.0.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-26: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4884. Deployment/exposure: 2026-05-29, receipt rollout-exp-4884; 25% of eligible production accounts. The original observation is history/evidence/record-8605cd2342.md. Later review: history/evidence/record-f9846b65d5.md.
Disposition recorded after the first window: Rolled back 2026-06-10, receipt rollback-exp-4884, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
