# record-1fe57635b3: NDJSON
Alias used in the design review: export progress. Local variant: la-4.10.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-06: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-5659. Deployment/exposure: 2026-04-09, receipt rollout-exp-5659; 25% of eligible production accounts. The original observation is history/evidence/record-a7b3308724.md. Later review: history/evidence/record-e99e2e14fe.md.
Disposition recorded after the first window: Disabled 2026-04-20, receipt disable-exp-5659, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
