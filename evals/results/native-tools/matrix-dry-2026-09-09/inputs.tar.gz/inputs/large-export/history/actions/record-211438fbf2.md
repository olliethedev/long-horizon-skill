# record-211438fbf2: large export
Alias used in the design review: CSV download. Local variant: la-6.13.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-21: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-4149. Deployment/exposure: 2026-04-24, receipt rollout-exp-4149; 25% of eligible production accounts. The original observation is history/evidence/record-71188bf3c8.md. Later review: history/evidence/record-d5f2e304a8.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
