# record-26832ac1bd: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-9.11.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-12: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-5286. Deployment/exposure: 2026-07-15, receipt rollout-exp-5286; 10% of eligible production accounts. The original observation is history/evidence/record-7b274f8609.md. Later review: history/evidence/record-7ca659840c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
