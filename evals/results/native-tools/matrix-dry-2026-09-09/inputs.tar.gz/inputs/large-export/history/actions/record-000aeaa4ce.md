# record-000aeaa4ce: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-9.12.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-04: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-5304. Deployment/exposure: 2026-08-07, receipt rollout-exp-5304; 25% of eligible production accounts. The original observation is history/evidence/record-c718819e15.md. Later review: history/evidence/record-cfb0a89386.md.
Disposition recorded after the first window: Rolled back 2026-08-15, receipt rollback-exp-5304, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
