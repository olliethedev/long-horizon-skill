# record-22e0699fff: large export
Alias used in the design review: CSV download. Local variant: la-1.2.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-6025. Deployment/exposure: 2026-04-10, receipt rollout-exp-6025; 5% of eligible production accounts. The original observation is history/evidence/record-9c2f7abc96.md. Later review: history/evidence/record-d154dc0bbd.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
