# record-39c6c5d5ed: NDJSON
Alias used in the design review: export progress. Local variant: la-1.2.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-18: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-6331. Deployment/exposure: 2026-05-21, receipt rollout-exp-6331; 10% of eligible production accounts. The original observation is history/evidence/record-d7c43fde63.md. Later review: history/evidence/record-e013bab8d3.md.
Disposition recorded after the first window: Disabled 2026-06-01, receipt disable-exp-6331, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
