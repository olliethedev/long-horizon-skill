# record-0a4a3e4bc0: export progress
Alias used in the design review: full ledger export. Local variant: la-3.1.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-03: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: change-exp-5667. Deployment/exposure: 2026-07-06, receipt rollout-exp-5667; 15% of eligible production accounts. The original observation is history/evidence/record-32eb447a8e.md. Later review: history/evidence/record-aa4fe2ae1f.md.
Disposition recorded after the first window: Disabled 2026-07-17, receipt disable-exp-5667, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
