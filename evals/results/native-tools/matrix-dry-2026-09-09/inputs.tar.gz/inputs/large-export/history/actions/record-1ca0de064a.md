# record-1ca0de064a: large export
Alias used in the design review: CSV download. Local variant: la-9.10.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-18: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-5880. Deployment/exposure: 2026-03-21, receipt rollout-exp-5880; 5% of eligible production accounts. The original observation is history/evidence/record-61fa91792e.md. Later review: history/evidence/record-0f8fb9a15c.md.
Disposition recorded after the first window: Rolled back 2026-03-29, receipt rollback-exp-5880, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
