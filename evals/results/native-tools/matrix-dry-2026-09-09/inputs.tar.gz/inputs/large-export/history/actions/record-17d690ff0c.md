# record-17d690ff0c: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-7.1.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-27: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-4375. Deployment/exposure: 2026-05-30, receipt rollout-exp-4375; 5% of eligible production accounts. The original observation is history/evidence/record-09be4e2476.md. Later review: history/evidence/record-33c4c92a68.md.
Disposition recorded after the first window: Disabled 2026-06-14, receipt disable-exp-4375, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
