# record-1b2ee458b3: large export
Alias used in the design review: CSV download. Local variant: la-7.16.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-16: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: change-exp-4798. Deployment/exposure: 2026-03-19, receipt rollout-exp-4798; 20% of eligible production accounts. The original observation is history/evidence/record-8b563363a8.md. Later review: history/evidence/record-20b1e70f9a.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
