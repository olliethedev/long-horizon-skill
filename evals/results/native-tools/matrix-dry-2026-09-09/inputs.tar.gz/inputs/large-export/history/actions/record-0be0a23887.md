# record-0be0a23887: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-7.10.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-16: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-6373. Deployment/exposure: 2026-03-19, receipt rollout-exp-6373; 20% of eligible production accounts. The original observation is history/evidence/record-56d1d4bc20.md. Later review: history/evidence/record-6469e6a937.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
