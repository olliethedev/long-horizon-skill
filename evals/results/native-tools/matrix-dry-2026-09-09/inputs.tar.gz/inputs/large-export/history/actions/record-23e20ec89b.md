# record-23e20ec89b: Async Ledger
Alias used in the design review: large export. Local variant: la-6.9.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-06: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-5760. Deployment/exposure: 2026-06-09, receipt rollout-exp-5760; 5% of eligible production accounts. The original observation is history/evidence/record-fbb99799d5.md. Later review: history/evidence/record-e983631617.md.
Disposition recorded after the first window: Rolled back 2026-06-17, receipt rollback-exp-5760, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
