# record-1072f2ef6d: export progress
Alias used in the design review: full ledger export. Local variant: la-9.5.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-12: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: change-exp-5331. Deployment/exposure: 2026-06-15, receipt rollout-exp-5331; 10% of eligible production accounts. The original observation is history/evidence/record-392b9528ea.md. Later review: history/evidence/record-860ac4a310.md.
Disposition recorded after the first window: Disabled 2026-06-26, receipt disable-exp-5331, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
