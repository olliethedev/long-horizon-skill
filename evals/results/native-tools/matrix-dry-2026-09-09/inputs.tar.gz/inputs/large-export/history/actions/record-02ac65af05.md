# record-02ac65af05: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-9.14.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-03: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5187. Deployment/exposure: 2026-06-06, receipt rollout-exp-5187; 15% of eligible production accounts. The original observation is history/evidence/record-4379796d59.md. Later review: history/evidence/record-125d971a10.md.
Disposition recorded after the first window: Disabled 2026-06-17, receipt disable-exp-5187, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
