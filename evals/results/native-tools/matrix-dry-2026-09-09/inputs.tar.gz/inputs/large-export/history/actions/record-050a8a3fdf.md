# record-050a8a3fdf: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-8.8.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-25: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-6167. Deployment/exposure: 2026-03-28, receipt rollout-exp-6167; 15% of eligible production accounts. The original observation is history/evidence/record-dd3a0ee37d.md. Later review: history/evidence/record-fadcc7c3df.md.
Disposition recorded after the first window: Disabled 2026-04-12, receipt disable-exp-6167, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
