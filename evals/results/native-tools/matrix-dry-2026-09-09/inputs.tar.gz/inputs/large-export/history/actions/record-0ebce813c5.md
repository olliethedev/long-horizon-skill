# record-0ebce813c5: large export
Alias used in the design review: CSV download. Local variant: la-7.4.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-04: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-4429. Deployment/exposure: 2026-08-07, receipt rollout-exp-4429; 25% of eligible production accounts. The original observation is history/evidence/record-bb9fa71e09.md. Later review: history/evidence/record-99a6cd70b1.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-20; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
