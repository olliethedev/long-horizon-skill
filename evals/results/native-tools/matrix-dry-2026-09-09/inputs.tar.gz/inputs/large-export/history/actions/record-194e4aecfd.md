# record-194e4aecfd: large export
Alias used in the design review: CSV download. Local variant: la-3.0.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-30: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5343. Deployment/exposure: 2026-05-03, receipt rollout-exp-5343; 20% of eligible production accounts. The original observation is history/evidence/record-5d03ea58fc.md. Later review: history/evidence/record-ecbdab19f9.md.
Disposition recorded after the first window: Disabled 2026-05-18, receipt disable-exp-5343, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
