# record-13dbe4eecd: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-5.0.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-12: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5156. Deployment/exposure: 2026-06-15, receipt rollout-exp-5156; 10% of eligible production accounts. The original observation is history/evidence/record-6e1178b841.md. Later review: history/evidence/record-eaa45afdc8.md.
Disposition recorded after the first window: Rolled back 2026-06-27, receipt rollback-exp-5156, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
