# record-265c23a7e8: large export
Alias used in the design review: CSV download. Local variant: la-7.16.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-02: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4951. Deployment/exposure: 2026-07-05, receipt rollout-exp-4951; 10% of eligible production accounts. The original observation is history/evidence/record-77d2a4dfaf.md. Later review: history/evidence/record-e289525d12.md.
Disposition recorded after the first window: Disabled 2026-07-20, receipt disable-exp-4951, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
