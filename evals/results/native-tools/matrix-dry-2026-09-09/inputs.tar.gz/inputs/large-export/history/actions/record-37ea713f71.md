# record-37ea713f71: Async Ledger
Alias used in the design review: large export. Local variant: la-5.14.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4337. Deployment/exposure: 2026-03-23, receipt rollout-exp-4337; 15% of eligible production accounts. The original observation is history/evidence/record-5f92714701.md. Later review: history/evidence/record-f3f4f2136f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
