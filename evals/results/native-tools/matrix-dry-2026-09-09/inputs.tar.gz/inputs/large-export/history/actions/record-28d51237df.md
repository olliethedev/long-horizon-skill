# record-28d51237df: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-3.13.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: change-exp-5271. Deployment/exposure: 2026-07-25, receipt rollout-exp-5271; 10% of eligible production accounts. The original observation is history/evidence/record-ffae473f68.md. Later review: history/evidence/record-59810d6790.md.
Disposition recorded after the first window: Disabled 2026-08-09, receipt disable-exp-5271, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
