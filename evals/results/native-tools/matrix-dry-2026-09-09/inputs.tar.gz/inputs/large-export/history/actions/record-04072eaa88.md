# record-04072eaa88: full ledger export
Alias used in the design review: workspace dump. Local variant: la-1.2.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: change-exp-5413. Deployment/exposure: 2026-07-12, receipt rollout-exp-5413; 20% of eligible production accounts. The original observation is history/evidence/record-0d3e635622.md. Later review: history/evidence/record-d59f563e1a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-25; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
