# record-1c0645c7af: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-9.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4899. Deployment/exposure: 2026-05-19, receipt rollout-exp-4899; 25% of eligible production accounts. The original observation is history/evidence/record-753067a070.md. Later review: history/evidence/record-65235af4fb.md.
Disposition recorded after the first window: Disabled 2026-05-30, receipt disable-exp-4899, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
