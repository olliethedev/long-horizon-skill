# record-2f57dcfc56: NDJSON
Alias used in the design review: export progress. Local variant: la-8.9.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-5420. Deployment/exposure: 2026-04-05, receipt rollout-exp-5420; 5% of eligible production accounts. The original observation is history/evidence/record-16f6d7a39c.md. Later review: history/evidence/record-7cbdc031bc.md.
Disposition recorded after the first window: Rolled back 2026-04-17, receipt rollback-exp-5420, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
