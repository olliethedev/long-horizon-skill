# record-06dced49c8: large export
Alias used in the design review: CSV download. Local variant: la-2.15.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-17: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5936. Deployment/exposure: 2026-06-20, receipt rollout-exp-5936; 10% of eligible production accounts. The original observation is history/evidence/record-37b4f6fb13.md. Later review: history/evidence/record-9de3f3ceb9.md.
Disposition recorded after the first window: Rolled back 2026-06-28, receipt rollback-exp-5936, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
