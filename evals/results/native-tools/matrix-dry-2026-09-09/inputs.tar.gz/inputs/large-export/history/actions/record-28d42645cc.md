# record-28d42645cc: CSV download
Alias used in the design review: NDJSON. Local variant: la-6.8.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-05: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-4824. Deployment/exposure: 2026-07-08, receipt rollout-exp-4824; 25% of eligible production accounts. The original observation is history/evidence/record-1ed36d462b.md. Later review: history/evidence/record-9a4a7b5255.md.
Disposition recorded after the first window: Rolled back 2026-07-16, receipt rollback-exp-4824, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
