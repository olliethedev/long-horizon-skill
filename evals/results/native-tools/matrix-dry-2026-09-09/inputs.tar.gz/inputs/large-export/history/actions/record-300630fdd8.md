# record-300630fdd8: full ledger export
Alias used in the design review: workspace dump. Local variant: la-2.4.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-05: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-6197. Deployment/exposure: 2026-03-08, receipt rollout-exp-6197; 15% of eligible production accounts. The original observation is history/evidence/record-2e4d60226a.md. Later review: history/evidence/record-d2c201fc93.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
