# record-2d4dc7d729: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-3.16.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-03: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4866. Deployment/exposure: 2026-05-06, receipt rollout-exp-4866; 10% of eligible production accounts. The original observation is history/evidence/record-128402b134.md. Later review: history/evidence/record-839e3ac56b.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
