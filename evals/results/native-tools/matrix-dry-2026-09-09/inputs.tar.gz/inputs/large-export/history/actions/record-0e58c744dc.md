# record-0e58c744dc: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-1.8.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-5215. Deployment/exposure: 2026-04-25, receipt rollout-exp-5215; 5% of eligible production accounts. The original observation is history/evidence/record-d0888163c5.md. Later review: history/evidence/record-da30804d7a.md.
Disposition recorded after the first window: Disabled 2026-05-10, receipt disable-exp-5215, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
