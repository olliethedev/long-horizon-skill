# record-0fa74c6bad: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-7.8.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-17: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-4960. Deployment/exposure: 2026-04-20, receipt rollout-exp-4960; 5% of eligible production accounts. The original observation is history/evidence/record-f0b3333c04.md. Later review: history/evidence/record-877330d816.md.
Disposition recorded after the first window: Rolled back 2026-04-28, receipt rollback-exp-4960, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
