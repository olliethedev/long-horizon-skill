# record-1a39c0909e: CSV download
Alias used in the design review: NDJSON. Local variant: la-7.6.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-28: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4465. Deployment/exposure: 2026-03-31, receipt rollout-exp-4465; 5% of eligible production accounts. The original observation is history/evidence/record-d45c6d7e79.md. Later review: history/evidence/record-03620444b2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
