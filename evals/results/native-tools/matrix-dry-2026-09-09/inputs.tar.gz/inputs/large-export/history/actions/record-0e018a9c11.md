# record-0e018a9c11: large export
Alias used in the design review: CSV download. Local variant: la-9.14.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-08: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-4116. Deployment/exposure: 2026-04-11, receipt rollout-exp-4116; 10% of eligible production accounts. The original observation is history/evidence/record-9b7b0e2396.md. Later review: history/evidence/record-545f493b52.md.
Disposition recorded after the first window: Rolled back 2026-04-23, receipt rollback-exp-4116, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
