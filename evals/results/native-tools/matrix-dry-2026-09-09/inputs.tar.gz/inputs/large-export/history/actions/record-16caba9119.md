# record-16caba9119: large export
Alias used in the design review: CSV download. Local variant: la-3.3.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-4938. Deployment/exposure: 2026-08-06, receipt rollout-exp-4938; 20% of eligible production accounts. The original observation is history/evidence/record-5890359161.md. Later review: history/evidence/record-b9e262fd62.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
