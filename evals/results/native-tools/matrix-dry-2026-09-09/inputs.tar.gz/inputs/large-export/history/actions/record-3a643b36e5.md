# record-3a643b36e5: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-3.11.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-31: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-5388. Deployment/exposure: 2026-04-03, receipt rollout-exp-5388; 20% of eligible production accounts. The original observation is history/evidence/record-c755e6d7cb.md. Later review: history/evidence/record-41e51d2237.md.
Disposition recorded after the first window: Rolled back 2026-04-15, receipt rollback-exp-5388, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
