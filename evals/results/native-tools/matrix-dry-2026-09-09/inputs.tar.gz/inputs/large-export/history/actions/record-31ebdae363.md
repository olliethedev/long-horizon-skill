# record-31ebdae363: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-4.0.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-21: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-4255. Deployment/exposure: 2026-02-24, receipt rollout-exp-4255; 5% of eligible production accounts. The original observation is history/evidence/record-5b39e12178.md. Later review: history/evidence/record-02338c46a7.md.
Disposition recorded after the first window: Disabled 2026-03-11, receipt disable-exp-4255, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
