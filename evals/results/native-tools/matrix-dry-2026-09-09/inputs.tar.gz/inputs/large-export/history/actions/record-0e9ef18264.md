# record-0e9ef18264: NDJSON
Alias used in the design review: export progress. Local variant: la-4.14.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-27: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5425. Deployment/exposure: 2026-05-30, receipt rollout-exp-5425; 5% of eligible production accounts. The original observation is history/evidence/record-3d75d2acb8.md. Later review: history/evidence/record-52eb8840d9.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-08; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
