# record-1b8d2337ce: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-6.7.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-22: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-4194. Deployment/exposure: 2026-03-25, receipt rollout-exp-4194; 25% of eligible production accounts. The original observation is history/evidence/record-58415e95c3.md. Later review: history/evidence/record-96f9398ceb.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
