# record-3c2b9fba6e: CSV download
Alias used in the design review: NDJSON. Local variant: la-1.1.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-6313. Deployment/exposure: 2026-04-28, receipt rollout-exp-6313; 20% of eligible production accounts. The original observation is history/evidence/record-5f6f79ed6d.md. Later review: history/evidence/record-0124d6f808.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
