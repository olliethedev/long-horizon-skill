# record-152dcb41d0: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-2.0.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-12: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-5360. Deployment/exposure: 2026-05-15, receipt rollout-exp-5360; 5% of eligible production accounts. The original observation is history/evidence/record-bdfdd085ea.md. Later review: history/evidence/record-3956e1cf52.md.
Disposition recorded after the first window: Rolled back 2026-05-23, receipt rollback-exp-5360, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
