# record-21bf92ab39: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-5.8.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-31: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-4688. Deployment/exposure: 2026-04-03, receipt rollout-exp-4688; 20% of eligible production accounts. The original observation is history/evidence/record-1388949f3c.md. Later review: history/evidence/record-7279023b2e.md.
Disposition recorded after the first window: Rolled back 2026-04-11, receipt rollback-exp-4688, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
