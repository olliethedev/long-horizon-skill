# record-1e08f7d824: Async Ledger
Alias used in the design review: large export. Local variant: la-1.6.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-17: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-5485. Deployment/exposure: 2026-04-20, receipt rollout-exp-5485; 5% of eligible production accounts. The original observation is history/evidence/record-8d080b97c6.md. Later review: history/evidence/record-285bbf0053.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-03; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
