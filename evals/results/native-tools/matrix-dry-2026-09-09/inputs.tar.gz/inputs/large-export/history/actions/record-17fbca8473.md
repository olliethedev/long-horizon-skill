# record-17fbca8473: NDJSON
Alias used in the design review: export progress. Local variant: la-1.6.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-08: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-4567. Deployment/exposure: 2026-06-11, receipt rollout-exp-4567; 15% of eligible production accounts. The original observation is history/evidence/record-71df1eb872.md. Later review: history/evidence/record-6799e4724c.md.
Disposition recorded after the first window: Disabled 2026-06-26, receipt disable-exp-4567, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
