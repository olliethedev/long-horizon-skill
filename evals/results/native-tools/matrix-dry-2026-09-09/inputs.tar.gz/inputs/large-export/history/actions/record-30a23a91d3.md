# record-30a23a91d3: large export
Alias used in the design review: CSV download. Local variant: la-4.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-20: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: change-exp-5488. Deployment/exposure: 2026-05-23, receipt rollout-exp-5488; 20% of eligible production accounts. The original observation is history/evidence/record-cd08ac35bb.md. Later review: history/evidence/record-ef1fafcfc9.md.
Disposition recorded after the first window: Rolled back 2026-05-31, receipt rollback-exp-5488, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
