# record-3abcd76a5e: export progress
Alias used in the design review: full ledger export. Local variant: la-7.12.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-03: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-4267. Deployment/exposure: 2026-07-06, receipt rollout-exp-4267; 15% of eligible production accounts. The original observation is history/evidence/record-6a45c12854.md. Later review: history/evidence/record-4cf9d4b709.md.
Disposition recorded after the first window: Disabled 2026-07-17, receipt disable-exp-4267, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
