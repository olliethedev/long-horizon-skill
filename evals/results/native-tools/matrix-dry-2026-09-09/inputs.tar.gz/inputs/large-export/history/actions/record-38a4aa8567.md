# record-38a4aa8567: CSV download
Alias used in the design review: NDJSON. Local variant: la-1.3.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-22: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-6196. Deployment/exposure: 2026-02-25, receipt rollout-exp-6196; 10% of eligible production accounts. The original observation is history/evidence/record-98b8f6aec7.md. Later review: history/evidence/record-7e0817fd27.md.
Disposition recorded after the first window: Rolled back 2026-03-09, receipt rollback-exp-6196, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
