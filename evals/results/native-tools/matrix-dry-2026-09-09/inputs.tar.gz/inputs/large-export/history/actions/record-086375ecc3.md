# record-086375ecc3: large export
Alias used in the design review: CSV download. Local variant: la-9.3.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-17: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-4989. Deployment/exposure: 2026-03-20, receipt rollout-exp-4989; 25% of eligible production accounts. The original observation is history/evidence/record-bb99503709.md. Later review: history/evidence/record-60bd1cebd0.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-02; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
