# record-2d7603efab: NDJSON
Alias used in the design review: export progress. Local variant: la-8.14.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-6275. Deployment/exposure: 2026-02-19, receipt rollout-exp-6275; 5% of eligible production accounts. The original observation is history/evidence/record-be8014c5b6.md. Later review: history/evidence/record-814e43d12b.md.
Disposition recorded after the first window: Disabled 2026-03-02, receipt disable-exp-6275, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
