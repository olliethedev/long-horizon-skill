# record-11c37cfef0: NDJSON
Alias used in the design review: export progress. Local variant: la-7.1.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-5140. Deployment/exposure: 2026-06-14, receipt rollout-exp-5140; 5% of eligible production accounts. The original observation is history/evidence/record-edb958c6ff.md. Later review: history/evidence/record-4b59a96ad9.md.
Disposition recorded after the first window: Rolled back 2026-06-26, receipt rollback-exp-5140, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
