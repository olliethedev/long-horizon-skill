# record-19a7ad530e: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-2.12.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4199. Deployment/exposure: 2026-05-19, receipt rollout-exp-4199; 25% of eligible production accounts. The original observation is history/evidence/record-8b66a17692.md. Later review: history/evidence/record-15d33b1853.md.
Disposition recorded after the first window: Disabled 2026-06-03, receipt disable-exp-4199, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
