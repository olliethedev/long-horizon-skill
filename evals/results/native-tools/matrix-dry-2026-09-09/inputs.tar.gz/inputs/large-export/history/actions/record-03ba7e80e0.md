# record-03ba7e80e0: large export
Alias used in the design review: CSV download. Local variant: la-9.7.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-18: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-6132. Deployment/exposure: 2026-02-21, receipt rollout-exp-6132; 15% of eligible production accounts. The original observation is history/evidence/record-386a487bbb.md. Later review: history/evidence/record-53fa43acfe.md.
Disposition recorded after the first window: Rolled back 2026-03-05, receipt rollback-exp-6132, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
