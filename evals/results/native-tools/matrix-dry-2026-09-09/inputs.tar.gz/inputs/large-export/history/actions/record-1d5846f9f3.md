# record-1d5846f9f3: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-7.15.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-29: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: change-exp-4627. Deployment/exposure: 2026-05-02, receipt rollout-exp-4627; 15% of eligible production accounts. The original observation is history/evidence/record-34beda91ea.md. Later review: history/evidence/record-b057e9a1b2.md.
Disposition recorded after the first window: Disabled 2026-05-13, receipt disable-exp-4627, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
