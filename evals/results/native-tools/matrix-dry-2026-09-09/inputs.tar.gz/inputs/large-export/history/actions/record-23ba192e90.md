# record-23ba192e90: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-1.3.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-26: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-5584. Deployment/exposure: 2026-05-29, receipt rollout-exp-5584; 25% of eligible production accounts. The original observation is history/evidence/record-24ca7b711e.md. Later review: history/evidence/record-2526a8b882.md.
Disposition recorded after the first window: Rolled back 2026-06-06, receipt rollback-exp-5584, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
