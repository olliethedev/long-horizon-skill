# record-0c0b051d03: NDJSON
Alias used in the design review: export progress. Local variant: la-2.0.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-27: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-6125. Deployment/exposure: 2026-05-30, receipt rollout-exp-6125; 5% of eligible production accounts. The original observation is history/evidence/record-ce0afb3492.md. Later review: history/evidence/record-cf748e2a03.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-12; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
