# record-2fb08c6e1a: Async Ledger
Alias used in the design review: large export. Local variant: la-3.0.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-5037. Deployment/exposure: 2026-03-23, receipt rollout-exp-5037; 15% of eligible production accounts. The original observation is history/evidence/record-cd7ee9a602.md. Later review: history/evidence/record-3db57b36ff.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
