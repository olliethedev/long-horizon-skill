# record-2002fa60b1: Async Ledger
Alias used in the design review: large export. Local variant: la-9.15.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-26: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: change-exp-5205. Deployment/exposure: 2026-06-29, receipt rollout-exp-5205; 5% of eligible production accounts. The original observation is history/evidence/record-f698f3bf70.md. Later review: history/evidence/record-9cf4bc8fb4.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-12; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
