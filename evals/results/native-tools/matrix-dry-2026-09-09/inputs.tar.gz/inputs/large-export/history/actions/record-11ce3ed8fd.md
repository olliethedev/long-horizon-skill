# record-11ce3ed8fd: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-3.1.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: change-exp-4902. Deployment/exposure: 2026-06-21, receipt rollout-exp-4902; 15% of eligible production accounts. The original observation is history/evidence/record-84598082c4.md. Later review: history/evidence/record-bae8e369ed.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
