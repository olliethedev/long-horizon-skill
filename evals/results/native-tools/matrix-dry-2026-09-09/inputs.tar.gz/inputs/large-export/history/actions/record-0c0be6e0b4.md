# record-0c0be6e0b4: NDJSON
Alias used in the design review: export progress. Local variant: la-7.7.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-20: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4483. Deployment/exposure: 2026-04-23, receipt rollout-exp-4483; 20% of eligible production accounts. The original observation is history/evidence/record-065ca7889a.md. Later review: history/evidence/record-edec1121cc.md.
Disposition recorded after the first window: Disabled 2026-05-04, receipt disable-exp-4483, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
