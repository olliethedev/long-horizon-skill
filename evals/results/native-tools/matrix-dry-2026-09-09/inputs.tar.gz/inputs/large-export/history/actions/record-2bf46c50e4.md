# record-2bf46c50e4: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-6.13.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-16: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-5220. Deployment/exposure: 2026-06-19, receipt rollout-exp-5220; 5% of eligible production accounts. The original observation is history/evidence/record-a85d7e8c21.md. Later review: history/evidence/record-baffebeeb4.md.
Disposition recorded after the first window: Rolled back 2026-07-01, receipt rollback-exp-5220, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
