# record-31efe46e1f: full ledger export
Alias used in the design review: workspace dump. Local variant: la-8.11.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-5609. Deployment/exposure: 2026-03-15, receipt rollout-exp-5609; 25% of eligible production accounts. The original observation is history/evidence/record-2cade69d9f.md. Later review: history/evidence/record-834adcee47.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
