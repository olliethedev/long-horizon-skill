# record-3bb357052d: Async Ledger
Alias used in the design review: large export. Local variant: la-2.13.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-02: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-5900. Deployment/exposure: 2026-05-05, receipt rollout-exp-5900; 5% of eligible production accounts. The original observation is history/evidence/record-940a9e117e.md. Later review: history/evidence/record-b808cfec91.md.
Disposition recorded after the first window: Rolled back 2026-05-17, receipt rollback-exp-5900, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
