# record-0358fcd78a: export progress
Alias used in the design review: full ledger export. Local variant: la-1.7.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-4738. Deployment/exposure: 2026-04-28, receipt rollout-exp-4738; 20% of eligible production accounts. The original observation is history/evidence/record-ed39721dd7.md. Later review: history/evidence/record-99f61e5d07.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
