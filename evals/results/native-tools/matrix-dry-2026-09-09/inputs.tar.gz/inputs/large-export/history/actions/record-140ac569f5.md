# record-140ac569f5: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-7.5.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-20: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-5212. Deployment/exposure: 2026-03-23, receipt rollout-exp-5212; 15% of eligible production accounts. The original observation is history/evidence/record-b5349b553e.md. Later review: history/evidence/record-7b8a36feee.md.
Disposition recorded after the first window: Rolled back 2026-04-04, receipt rollback-exp-5212, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
