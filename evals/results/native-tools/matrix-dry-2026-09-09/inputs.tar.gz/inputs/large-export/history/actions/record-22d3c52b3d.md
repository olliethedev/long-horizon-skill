# record-22d3c52b3d: full ledger export
Alias used in the design review: workspace dump. Local variant: la-9.5.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-23: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5637. Deployment/exposure: 2026-07-26, receipt rollout-exp-5637; 15% of eligible production accounts. The original observation is history/evidence/record-4b60860d78.md. Later review: history/evidence/record-12d282621a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-08; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
