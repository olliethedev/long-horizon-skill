# record-2a25e9f40e: full ledger export
Alias used in the design review: workspace dump. Local variant: la-5.7.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-14: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4517. Deployment/exposure: 2026-05-17, receipt rollout-exp-4517; 15% of eligible production accounts. The original observation is history/evidence/record-1b640d2f1e.md. Later review: history/evidence/record-aa2ffb866f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
