# record-26ed5c3c63: full ledger export
Alias used in the design review: workspace dump. Local variant: la-6.12.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-13: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-4896. Deployment/exposure: 2026-04-16, receipt rollout-exp-4896; 10% of eligible production accounts. The original observation is history/evidence/record-d8722527fb.md. Later review: history/evidence/record-c355ac5ac7.md.
Disposition recorded after the first window: Rolled back 2026-04-24, receipt rollback-exp-4896, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
