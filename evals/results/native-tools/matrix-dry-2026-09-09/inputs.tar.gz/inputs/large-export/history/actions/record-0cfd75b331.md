# record-0cfd75b331: full ledger export
Alias used in the design review: workspace dump. Local variant: la-2.11.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4181. Deployment/exposure: 2026-04-26, receipt rollout-exp-4181; 10% of eligible production accounts. The original observation is history/evidence/record-4f749e425e.md. Later review: history/evidence/record-8d7c04b926.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
