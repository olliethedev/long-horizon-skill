# record-0da3fbf9bd: full ledger export
Alias used in the design review: workspace dump. Local variant: la-5.1.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-6398. Deployment/exposure: 2026-06-27, receipt rollout-exp-6398; 20% of eligible production accounts. The original observation is history/evidence/record-06f30bfaeb.md. Later review: history/evidence/record-d85422c616.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
