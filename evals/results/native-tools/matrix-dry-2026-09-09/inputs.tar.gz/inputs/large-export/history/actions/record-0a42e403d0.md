# record-0a42e403d0: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-3.15.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-27: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-5001. Deployment/exposure: 2026-07-30, receipt rollout-exp-5001; 10% of eligible production accounts. The original observation is history/evidence/record-8b85f2cfff.md. Later review: history/evidence/record-445ff0c0f3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-08; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
