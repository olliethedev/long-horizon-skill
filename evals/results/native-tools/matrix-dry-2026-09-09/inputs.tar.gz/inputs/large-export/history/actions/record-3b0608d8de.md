# record-3b0608d8de: NDJSON
Alias used in the design review: export progress. Local variant: la-1.7.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-01: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-4585. Deployment/exposure: 2026-07-04, receipt rollout-exp-4585; 5% of eligible production accounts. The original observation is history/evidence/record-51a360b152.md. Later review: history/evidence/record-fb79fbec35.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
