# record-295a9f6d5e: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-1.4.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-02: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-5449. Deployment/exposure: 2026-03-05, receipt rollout-exp-5449; 25% of eligible production accounts. The original observation is history/evidence/record-e90a85cae6.md. Later review: history/evidence/record-beeee2e3a3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-14; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
