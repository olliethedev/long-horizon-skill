# record-23a2e3703d: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-2.0.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-18: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-5207. Deployment/exposure: 2026-07-21, receipt rollout-exp-5207; 15% of eligible production accounts. The original observation is history/evidence/record-5ff088d70f.md. Later review: history/evidence/record-82ef556373.md.
Disposition recorded after the first window: Disabled 2026-08-05, receipt disable-exp-5207, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
