# record-2b619bfa4d: NDJSON
Alias used in the design review: export progress. Local variant: la-5.4.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: change-exp-5840. Deployment/exposure: 2026-06-14, receipt rollout-exp-5840; 5% of eligible production accounts. The original observation is history/evidence/record-c4b7678ba3.md. Later review: history/evidence/record-a6975eca3f.md.
Disposition recorded after the first window: Rolled back 2026-06-22, receipt rollback-exp-5840, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
