# record-1ed8442ef1: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-4.15.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-4525. Deployment/exposure: 2026-02-19, receipt rollout-exp-4525; 5% of eligible production accounts. The original observation is history/evidence/record-4022aed451.md. Later review: history/evidence/record-788a97daa8.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-04; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
