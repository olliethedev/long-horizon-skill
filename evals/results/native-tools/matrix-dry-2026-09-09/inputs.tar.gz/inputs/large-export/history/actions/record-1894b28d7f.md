# record-1894b28d7f: large export
Alias used in the design review: CSV download. Local variant: la-8.9.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-6338. Deployment/exposure: 2026-08-06, receipt rollout-exp-6338; 20% of eligible production accounts. The original observation is history/evidence/record-cb9371e2f6.md. Later review: history/evidence/record-eb1ccfdff1.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
