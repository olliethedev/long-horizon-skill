# record-0f82d09d4e: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-8.13.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-27: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-5645. Deployment/exposure: 2026-04-30, receipt rollout-exp-5645; 5% of eligible production accounts. The original observation is history/evidence/record-c2edfdac67.md. Later review: history/evidence/record-2c1666aa0d.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
