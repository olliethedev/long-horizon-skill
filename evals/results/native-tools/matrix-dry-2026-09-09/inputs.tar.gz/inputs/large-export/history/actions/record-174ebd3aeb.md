# record-174ebd3aeb: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-2.16.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5495. Deployment/exposure: 2026-08-08, receipt rollout-exp-5495; 5% of eligible production accounts. The original observation is history/evidence/record-9b9f534c34.md. Later review: history/evidence/record-3c444c1485.md.
Disposition recorded after the first window: Disabled 2026-08-23, receipt disable-exp-5495, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
