# record-1dc8e4bad6: CSV download
Alias used in the design review: NDJSON. Local variant: la-9.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-6168. Deployment/exposure: 2026-04-08, receipt rollout-exp-6168; 20% of eligible production accounts. The original observation is history/evidence/record-92c7cda8c1.md. Later review: history/evidence/record-58f168604e.md.
Disposition recorded after the first window: Rolled back 2026-04-16, receipt rollback-exp-6168, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
