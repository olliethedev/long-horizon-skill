# record-0bd01ff41d: CSV download
Alias used in the design review: NDJSON. Local variant: la-9.16.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-07: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5529. Deployment/exposure: 2026-03-10, receipt rollout-exp-5529; 25% of eligible production accounts. The original observation is history/evidence/record-ce48a0b3be.md. Later review: history/evidence/record-4735b87204.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
