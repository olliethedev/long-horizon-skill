# record-380ff7ccfd: CSV download
Alias used in the design review: NDJSON. Local variant: la-3.7.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-01: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-6234. Deployment/exposure: 2026-05-04, receipt rollout-exp-6234; 25% of eligible production accounts. The original observation is history/evidence/record-c903e6641d.md. Later review: history/evidence/record-ab876cabfa.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
