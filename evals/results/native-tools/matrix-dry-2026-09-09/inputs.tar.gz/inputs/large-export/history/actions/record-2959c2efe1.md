# record-2959c2efe1: Async Ledger
Alias used in the design review: large export. Local variant: la-1.7.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-10: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-5503. Deployment/exposure: 2026-05-13, receipt rollout-exp-5503; 20% of eligible production accounts. The original observation is history/evidence/record-9f954ae697.md. Later review: history/evidence/record-fd53fa4927.md.
Disposition recorded after the first window: Disabled 2026-05-28, receipt disable-exp-5503, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
