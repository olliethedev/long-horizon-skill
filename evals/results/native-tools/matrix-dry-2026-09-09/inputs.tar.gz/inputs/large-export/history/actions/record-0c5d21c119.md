# record-0c5d21c119: full ledger export
Alias used in the design review: workspace dump. Local variant: la-2.6.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-10: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: change-exp-5927. Deployment/exposure: 2026-03-13, receipt rollout-exp-5927; 15% of eligible production accounts. The original observation is history/evidence/record-59b5e26e2b.md. Later review: history/evidence/record-e7c8a8e7dc.md.
Disposition recorded after the first window: Disabled 2026-03-28, receipt disable-exp-5927, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
