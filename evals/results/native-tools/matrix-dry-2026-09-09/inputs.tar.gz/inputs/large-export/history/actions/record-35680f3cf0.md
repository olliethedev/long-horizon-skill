# record-35680f3cf0: large export
Alias used in the design review: CSV download. Local variant: la-1.12.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-23: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-5287. Deployment/exposure: 2026-07-26, receipt rollout-exp-5287; 15% of eligible production accounts. The original observation is history/evidence/record-357a7a0802.md. Later review: history/evidence/record-fba5112114.md.
Disposition recorded after the first window: Disabled 2026-08-10, receipt disable-exp-5287, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
