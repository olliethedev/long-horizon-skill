# record-3a8b5bf756: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-9.5.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-17: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: change-exp-5790. Deployment/exposure: 2026-05-20, receipt rollout-exp-5790; 5% of eligible production accounts. The original observation is history/evidence/record-b308a91de1.md. Later review: history/evidence/record-1057583df3.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
