# record-142c04afd1: NDJSON
Alias used in the design review: export progress. Local variant: la-9.1.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-5565. Deployment/exposure: 2026-04-25, receipt rollout-exp-5565; 5% of eligible production accounts. The original observation is history/evidence/record-71d0ca1849.md. Later review: history/evidence/record-5fe4f07f47.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-08; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
