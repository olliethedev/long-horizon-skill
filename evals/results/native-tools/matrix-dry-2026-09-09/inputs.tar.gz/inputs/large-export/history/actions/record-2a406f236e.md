# record-2a406f236e: CSV download
Alias used in the design review: NDJSON. Local variant: la-5.5.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-24: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-5552. Deployment/exposure: 2026-05-27, receipt rollout-exp-5552; 15% of eligible production accounts. The original observation is history/evidence/record-cb06d251bd.md. Later review: history/evidence/record-e28dd7a1fe.md.
Disposition recorded after the first window: Rolled back 2026-06-04, receipt rollback-exp-5552, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
