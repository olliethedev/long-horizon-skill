# record-07dca622cc: export progress
Alias used in the design review: full ledger export. Local variant: la-9.6.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-05: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-5349. Deployment/exposure: 2026-07-08, receipt rollout-exp-5349; 25% of eligible production accounts. The original observation is history/evidence/record-8b6e2ac184.md. Later review: history/evidence/record-55d675db28.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-21; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
