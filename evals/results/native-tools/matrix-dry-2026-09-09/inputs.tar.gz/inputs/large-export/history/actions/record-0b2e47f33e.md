# record-0b2e47f33e: Async Ledger
Alias used in the design review: large export. Local variant: la-3.8.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-19: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5793. Deployment/exposure: 2026-06-22, receipt rollout-exp-5793; 20% of eligible production accounts. The original observation is history/evidence/record-08607323b1.md. Later review: history/evidence/record-c2517a4a24.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
