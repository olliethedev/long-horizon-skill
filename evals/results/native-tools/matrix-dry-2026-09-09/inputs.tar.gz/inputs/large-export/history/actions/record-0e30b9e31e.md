# record-0e30b9e31e: large export
Alias used in the design review: CSV download. Local variant: la-2.9.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: change-exp-5063. Deployment/exposure: 2026-07-12, receipt rollout-exp-5063; 20% of eligible production accounts. The original observation is history/evidence/record-3206024d33.md. Later review: history/evidence/record-d9b9d9e11f.md.
Disposition recorded after the first window: Disabled 2026-07-27, receipt disable-exp-5063, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
