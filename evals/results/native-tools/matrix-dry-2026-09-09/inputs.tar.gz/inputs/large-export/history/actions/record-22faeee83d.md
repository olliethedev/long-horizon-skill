# record-22faeee83d: NDJSON
Alias used in the design review: export progress. Local variant: la-1.12.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-11: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-5593. Deployment/exposure: 2026-03-14, receipt rollout-exp-5593; 20% of eligible production accounts. The original observation is history/evidence/record-c61f3a35d0.md. Later review: history/evidence/record-10709173b4.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-23; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
