# record-1fa2a6e8eb: CSV download
Alias used in the design review: NDJSON. Local variant: la-9.16.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-24: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-4152. Deployment/exposure: 2026-05-27, receipt rollout-exp-4152; 15% of eligible production accounts. The original observation is history/evidence/record-27391703d4.md. Later review: history/evidence/record-fdd01b3388.md.
Disposition recorded after the first window: Rolled back 2026-06-04, receipt rollback-exp-4152, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
