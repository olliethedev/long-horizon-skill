# record-1c71380e3c: full ledger export
Alias used in the design review: workspace dump. Local variant: la-5.9.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-19: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: change-exp-4247. Deployment/exposure: 2026-05-22, receipt rollout-exp-4247; 15% of eligible production accounts. The original observation is history/evidence/record-04d090d03c.md. Later review: history/evidence/record-eb466413ba.md.
Disposition recorded after the first window: Disabled 2026-06-06, receipt disable-exp-4247, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
