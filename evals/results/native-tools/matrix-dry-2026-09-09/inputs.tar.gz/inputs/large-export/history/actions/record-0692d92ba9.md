# record-0692d92ba9: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-4.2.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-14: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4138. Deployment/exposure: 2026-06-17, receipt rollout-exp-4138; 20% of eligible production accounts. The original observation is history/evidence/record-a1b960b7cb.md. Later review: history/evidence/record-c6dfdca3e9.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
