# record-07e52b1c5b: large export
Alias used in the design review: CSV download. Local variant: la-7.2.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-30: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: change-exp-4699. Deployment/exposure: 2026-08-02, receipt rollout-exp-4699; 25% of eligible production accounts. The original observation is history/evidence/record-9dfd774e66.md. Later review: history/evidence/record-24e67effaa.md.
Disposition recorded after the first window: Disabled 2026-08-13, receipt disable-exp-4699, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
