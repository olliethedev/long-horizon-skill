# record-0f97e01fe8: large export
Alias used in the design review: CSV download. Local variant: la-6.8.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-25: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-4518. Deployment/exposure: 2026-05-28, receipt rollout-exp-4518; 20% of eligible production accounts. The original observation is history/evidence/record-064143630c.md. Later review: history/evidence/record-64810bf5f6.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
