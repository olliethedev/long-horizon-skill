# record-2bde1a792b: NDJSON
Alias used in the design review: export progress. Local variant: la-7.8.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-13: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: change-exp-4501. Deployment/exposure: 2026-05-16, receipt rollout-exp-4501; 10% of eligible production accounts. The original observation is history/evidence/record-a8f7f68e7a.md. Later review: history/evidence/record-2a31eb0740.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
