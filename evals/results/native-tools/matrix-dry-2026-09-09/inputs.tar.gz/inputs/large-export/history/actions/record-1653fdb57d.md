# record-1653fdb57d: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-3.7.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-02: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-5622. Deployment/exposure: 2026-08-05, receipt rollout-exp-5622; 15% of eligible production accounts. The original observation is history/evidence/record-f5c465c756.md. Later review: history/evidence/record-3cf708b23f.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
