# record-13ec5f3616: large export
Alias used in the design review: CSV download. Local variant: la-9.6.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-6114. Deployment/exposure: 2026-07-23, receipt rollout-exp-6114; 25% of eligible production accounts. The original observation is history/evidence/record-59be57cd69.md. Later review: history/evidence/record-0b7556089e.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
