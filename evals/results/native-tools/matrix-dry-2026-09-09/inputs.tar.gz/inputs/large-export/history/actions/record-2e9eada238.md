# record-2e9eada238: full ledger export
Alias used in the design review: workspace dump. Local variant: la-6.3.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: change-exp-4275. Deployment/exposure: 2026-04-10, receipt rollout-exp-4275; 5% of eligible production accounts. The original observation is history/evidence/record-01b1d1421d.md. Later review: history/evidence/record-44fd54afb8.md.
Disposition recorded after the first window: Disabled 2026-04-21, receipt disable-exp-4275, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
