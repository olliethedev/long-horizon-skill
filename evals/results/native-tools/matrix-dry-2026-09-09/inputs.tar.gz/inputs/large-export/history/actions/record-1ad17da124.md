# record-1ad17da124: full ledger export
Alias used in the design review: workspace dump. Local variant: la-5.10.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-23: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-4112. Deployment/exposure: 2026-02-26, receipt rollout-exp-4112; 15% of eligible production accounts. The original observation is history/evidence/record-51abb722c0.md. Later review: history/evidence/record-bdbb20aef6.md.
Disposition recorded after the first window: Rolled back 2026-03-06, receipt rollback-exp-4112, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
