# record-372a2af110: large export
Alias used in the design review: CSV download. Local variant: la-6.6.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-20: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: change-exp-4788. Deployment/exposure: 2026-05-23, receipt rollout-exp-4788; 20% of eligible production accounts. The original observation is history/evidence/record-623fb145ab.md. Later review: history/evidence/record-ff23c2281c.md.
Disposition recorded after the first window: Rolled back 2026-06-04, receipt rollback-exp-4788, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
