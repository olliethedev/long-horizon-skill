# record-1f1471e02d: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-4.13.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-19: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: change-exp-6172. Deployment/exposure: 2026-05-22, receipt rollout-exp-6172; 15% of eligible production accounts. The original observation is history/evidence/record-05fea4e6e3.md. Later review: history/evidence/record-0613bf9038.md.
Disposition recorded after the first window: Rolled back 2026-06-03, receipt rollback-exp-6172, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
