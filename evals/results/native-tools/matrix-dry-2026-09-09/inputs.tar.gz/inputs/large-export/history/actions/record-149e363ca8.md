# record-149e363ca8: Async Ledger
Alias used in the design review: large export. Local variant: la-9.11.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-28: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: change-exp-5592. Deployment/exposure: 2026-03-03, receipt rollout-exp-5592; 15% of eligible production accounts. The original observation is history/evidence/record-f10480f1ae.md. Later review: history/evidence/record-99e22d2397.md.
Disposition recorded after the first window: Rolled back 2026-03-11, receipt rollback-exp-5592, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
