# record-0f586ee1db: export progress
Alias used in the design review: full ledger export. Local variant: la-1.16.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-01: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: change-exp-5359. Deployment/exposure: 2026-05-04, receipt rollout-exp-5359; 25% of eligible production accounts. The original observation is history/evidence/record-ee23e8bfb1.md. Later review: history/evidence/record-8b71417787.md.
Disposition recorded after the first window: Disabled 2026-05-19, receipt disable-exp-5359, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
