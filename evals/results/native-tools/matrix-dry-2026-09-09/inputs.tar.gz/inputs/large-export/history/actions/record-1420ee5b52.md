# record-1420ee5b52: NDJSON
Alias used in the design review: export progress. Local variant: la-1.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-30: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4468. Deployment/exposure: 2026-05-03, receipt rollout-exp-4468; 20% of eligible production accounts. The original observation is history/evidence/record-f46d208f7a.md. Later review: history/evidence/record-d853f8e58a.md.
Disposition recorded after the first window: Rolled back 2026-05-15, receipt rollback-exp-4468, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
