# record-16de6c414e: full ledger export
Alias used in the design review: workspace dump. Local variant: la-1.13.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-14: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-5917. Deployment/exposure: 2026-05-17, receipt rollout-exp-5917; 15% of eligible production accounts. The original observation is history/evidence/record-7614d4434d.md. Later review: history/evidence/record-0b15dd5926.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
