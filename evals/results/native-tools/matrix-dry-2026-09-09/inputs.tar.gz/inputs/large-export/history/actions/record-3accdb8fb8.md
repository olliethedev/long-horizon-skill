# record-3accdb8fb8: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-2.9.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: change-exp-6134. Deployment/exposure: 2026-03-15, receipt rollout-exp-6134; 25% of eligible production accounts. The original observation is history/evidence/record-a74685a577.md. Later review: history/evidence/record-fe08999a0c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
