# record-3cb61632eb: NDJSON
Alias used in the design review: export progress. Local variant: la-7.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5239. Deployment/exposure: 2026-07-23, receipt rollout-exp-5239; 25% of eligible production accounts. The original observation is history/evidence/record-20ebad56b7.md. Later review: history/evidence/record-247180cf20.md.
Disposition recorded after the first window: Disabled 2026-08-07, receipt disable-exp-5239, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
