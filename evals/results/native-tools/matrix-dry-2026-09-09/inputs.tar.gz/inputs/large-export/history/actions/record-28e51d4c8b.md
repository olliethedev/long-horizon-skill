# record-28e51d4c8b: full ledger export
Alias used in the design review: workspace dump. Local variant: la-6.11.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-07: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-5031. Deployment/exposure: 2026-07-10, receipt rollout-exp-5031; 10% of eligible production accounts. The original observation is history/evidence/record-adfa886a58.md. Later review: history/evidence/record-5d5f440d45.md.
Disposition recorded after the first window: Disabled 2026-07-25, receipt disable-exp-5031, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
