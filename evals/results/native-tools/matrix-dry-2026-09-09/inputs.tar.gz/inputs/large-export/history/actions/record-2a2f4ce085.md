# record-2a2f4ce085: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-6.0.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-20: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-4833. Deployment/exposure: 2026-04-23, receipt rollout-exp-4833; 20% of eligible production accounts. The original observation is history/evidence/record-7634b97a95.md. Later review: history/evidence/record-bc499129e4.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-02; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
