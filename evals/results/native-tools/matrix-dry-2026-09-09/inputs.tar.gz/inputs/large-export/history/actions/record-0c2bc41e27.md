# record-0c2bc41e27: large export
Alias used in the design review: CSV download. Local variant: la-2.10.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-15: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: change-exp-4928. Deployment/exposure: 2026-04-18, receipt rollout-exp-4928; 20% of eligible production accounts. The original observation is history/evidence/record-c91683f20a.md. Later review: history/evidence/record-30c513ca25.md.
Disposition recorded after the first window: Rolled back 2026-04-26, receipt rollback-exp-4928, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
