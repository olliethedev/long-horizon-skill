# record-1e5a9b2420: NDJSON
Alias used in the design review: export progress. Local variant: la-9.12.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: change-exp-4539. Deployment/exposure: 2026-07-23, receipt rollout-exp-4539; 25% of eligible production accounts. The original observation is history/evidence/record-9f7793fb1f.md. Later review: history/evidence/record-76088cc5d5.md.
Disposition recorded after the first window: Disabled 2026-08-03, receipt disable-exp-4539, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
