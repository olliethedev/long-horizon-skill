# record-1fa71b7184: NDJSON
Alias used in the design review: export progress. Local variant: la-3.8.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: change-exp-4875. Deployment/exposure: 2026-02-19, receipt rollout-exp-4875; 5% of eligible production accounts. The original observation is history/evidence/record-5f570a5103.md. Later review: history/evidence/record-954d70f6fa.md.
Disposition recorded after the first window: Disabled 2026-03-02, receipt disable-exp-4875, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
