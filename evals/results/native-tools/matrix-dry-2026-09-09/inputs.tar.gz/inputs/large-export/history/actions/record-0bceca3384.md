# record-0bceca3384: workspace dump
Alias used in the design review: Ledger Ferry. Local variant: la-3.15.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-10: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: change-exp-6378. Deployment/exposure: 2026-05-13, receipt rollout-exp-6378; 20% of eligible production accounts. The original observation is history/evidence/record-38e7d21277.md. Later review: history/evidence/record-a8d081648b.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
