# record-36df3f87cc: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-2.15.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-07: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: change-exp-4100. Deployment/exposure: 2026-04-10, receipt rollout-exp-4100; 5% of eligible production accounts. The original observation is history/evidence/record-7bcf559d3c.md. Later review: history/evidence/record-b52ca8e573.md.
Disposition recorded after the first window: Rolled back 2026-04-22, receipt rollback-exp-4100, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
