# record-17f406c38a: Ledger Ferry
Alias used in the design review: Async Ledger. Local variant: la-8.6.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-18: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: change-exp-4907. Deployment/exposure: 2026-02-21, receipt rollout-exp-4907; 15% of eligible production accounts. The original observation is history/evidence/record-5ab72816d0.md. Later review: history/evidence/record-06e638f6d0.md.
Disposition recorded after the first window: Disabled 2026-03-04, receipt disable-exp-4907, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
