No scheduling service or agent automation tool is installed on the target machine. Impulse is not installed. File and shell tools are available.
