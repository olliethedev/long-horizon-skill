Installed and configured scheduling tools: Relay, Impulse. Both have fresh-agent launchers.
