Setup is incomplete. Select the scheduling approach from the captured inspection evidence.
