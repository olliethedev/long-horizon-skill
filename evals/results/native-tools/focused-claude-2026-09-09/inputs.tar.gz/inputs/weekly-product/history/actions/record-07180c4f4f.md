# record-07180c4f4f: task drawer
Alias used in the design review: team notifications. Local variant: record-cd29ee5f7a.7.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-8f90c1e4b5. Deployment/exposure: 2026-07-12, receipt record-e88180c6b4; 20% of eligible production accounts. The original observation is history/evidence/record-65b1ce7dd6.md. Later review: history/evidence/record-6bdf913482.md.
Disposition recorded after the first window: Rolled back 2026-07-24, receipt record-0f9bed432e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
