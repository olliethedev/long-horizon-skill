# record-2c35e8f1d2: weekly note
Alias used in the design review: task drawer. Local variant: record-ec0e0ab09e.6.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-22: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-69f53c7db1. Deployment/exposure: 2026-03-25, receipt record-876b042055; 25% of eligible production accounts. The original observation is history/evidence/record-412ceeb6f4.md. Later review: history/evidence/record-19f2fe58d4.md.
Disposition recorded after the first window: Rolled back 2026-04-02, receipt record-adbe3690c6, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
