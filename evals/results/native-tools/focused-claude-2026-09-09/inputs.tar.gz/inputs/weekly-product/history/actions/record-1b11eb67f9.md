# record-1b11eb67f9: status filters
Alias used in the design review: Focus Shelf. Local variant: record-562146c9ea.9.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-e06ce9ebc4. Deployment/exposure: 2026-06-27, receipt record-edbeded057; 20% of eligible production accounts. The original observation is history/evidence/record-e6dd16bd24.md. Later review: history/evidence/record-92af56de6c.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
