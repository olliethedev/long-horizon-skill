# record-0a2a4dfff4: Sunday Room
Alias used in the design review: triage facets. Local variant: record-dce8c08a5e.16.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-10: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-046fecb333. Deployment/exposure: 2026-04-13, receipt record-24dccd0d9f; 20% of eligible production accounts. The original observation is history/evidence/record-4513b7074a.md. Later review: history/evidence/record-103a8c779d.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-22; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
