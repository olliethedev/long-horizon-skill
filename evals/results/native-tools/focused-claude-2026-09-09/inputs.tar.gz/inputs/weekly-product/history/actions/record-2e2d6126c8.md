# record-2e2d6126c8: weekly note
Alias used in the design review: task drawer. Local variant: record-431a358680.3.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-22: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-0dd01255d6. Deployment/exposure: 2026-03-25, receipt record-f78a7ab414; 25% of eligible production accounts. The original observation is history/evidence/record-46eb40e30a.md. Later review: history/evidence/record-a6e519a8ea.md.
Disposition recorded after the first window: Rolled back 2026-04-06, receipt record-8defc2a5ea, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
