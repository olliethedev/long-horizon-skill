# record-0338dfd1ad: triage facets
Alias used in the design review: weekly note. Local variant: record-b88d0e3215.12.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-e05cb0468b. Deployment/exposure: 2026-07-12, receipt record-a8743d16bb; 20% of eligible production accounts. The original observation is history/evidence/record-a3f4c58e2b.md. Later review: history/evidence/record-57b990ac04.md.
Disposition recorded after the first window: Disabled 2026-07-23, receipt record-fdb2377620, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
