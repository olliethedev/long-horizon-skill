# record-31d26f1ce4: weekly note
Alias used in the design review: task drawer. Local variant: record-647d99546c.16.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-10: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-31384b00fc. Deployment/exposure: 2026-05-13, receipt record-5a283b5b91; 20% of eligible production accounts. The original observation is history/evidence/record-a43a40c240.md. Later review: history/evidence/record-fc2cdf1d0d.md.
Disposition recorded after the first window: Rolled back 2026-05-25, receipt record-90f8fbfdf2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
