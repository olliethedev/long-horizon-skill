# record-25a70131ea: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.11.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-15: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-b170a10a70. Deployment/exposure: 2026-07-18, receipt record-b9d2c5b5d8; 25% of eligible production accounts. The original observation is history/evidence/record-76a54dcfe7.md. Later review: history/evidence/record-16fb8ee010.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
