# record-01bbb611e7: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.10.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-5d1878fef4. Deployment/exposure: 2026-04-25, receipt record-70ff363085; 5% of eligible production accounts. The original observation is history/evidence/record-89505f1ed2.md. Later review: history/evidence/record-137a603ec7.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
