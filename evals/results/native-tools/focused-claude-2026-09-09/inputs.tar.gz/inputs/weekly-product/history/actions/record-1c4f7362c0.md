# record-1c4f7362c0: Sunday Room
Alias used in the design review: triage facets. Local variant: record-8ff9b086a1.6.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-09: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-9a8d09ff6b. Deployment/exposure: 2026-05-12, receipt record-523bf13ac6; 15% of eligible production accounts. The original observation is history/evidence/record-56dad8e481.md. Later review: history/evidence/record-63ecdb61db.md.
Disposition recorded after the first window: Rolled back 2026-05-24, receipt record-dc9885c1ba, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
