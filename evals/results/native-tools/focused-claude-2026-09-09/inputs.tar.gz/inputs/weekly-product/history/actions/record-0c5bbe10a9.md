# record-0c5bbe10a9: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-431a358680.7.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-02: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-17cd118080. Deployment/exposure: 2026-08-05, receipt record-1ccd863a61; 15% of eligible production accounts. The original observation is history/evidence/record-f5571acaa3.md. Later review: history/evidence/record-67290d1940.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
