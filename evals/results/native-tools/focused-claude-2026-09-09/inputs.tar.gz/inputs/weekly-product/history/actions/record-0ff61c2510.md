# record-0ff61c2510: status filters
Alias used in the design review: Focus Shelf. Local variant: record-b88d0e3215.3.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-3bcc481acd. Deployment/exposure: 2026-06-21, receipt record-77c8ea46c3; 15% of eligible production accounts. The original observation is history/evidence/record-4ee76d605c.md. Later review: history/evidence/record-3c1a5f0c96.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-30; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
