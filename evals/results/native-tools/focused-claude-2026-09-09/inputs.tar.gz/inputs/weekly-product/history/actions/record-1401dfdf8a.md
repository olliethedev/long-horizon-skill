# record-1401dfdf8a: status filters
Alias used in the design review: Focus Shelf. Local variant: record-dce8c08a5e.12.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-16: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-2b1cf56ad3. Deployment/exposure: 2026-03-19, receipt record-6b3e6eaa8d; 20% of eligible production accounts. The original observation is history/evidence/record-6dae1cfcfc.md. Later review: history/evidence/record-1c37d970cc.md.
Disposition recorded after the first window: Rolled back 2026-03-27, receipt record-daf952f381, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
