# record-35b4e1d381: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-647d99546c.12.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-04: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-573ca982cc. Deployment/exposure: 2026-04-07, receipt record-0fe9636641; 15% of eligible production accounts. The original observation is history/evidence/record-da8663027b.md. Later review: history/evidence/record-63d979ddfd.md.
Disposition recorded after the first window: Disabled 2026-04-18, receipt record-b3e936193c, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
