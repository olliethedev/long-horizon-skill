# record-34e3c3da2b: team notifications
Alias used in the design review: status filters. Local variant: record-8ff9b086a1.2.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-15: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-9268d182ac. Deployment/exposure: 2026-03-18, receipt record-b6c61a7833; 15% of eligible production accounts. The original observation is history/evidence/record-7d2a855195.md. Later review: history/evidence/record-18e7f361cb.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
