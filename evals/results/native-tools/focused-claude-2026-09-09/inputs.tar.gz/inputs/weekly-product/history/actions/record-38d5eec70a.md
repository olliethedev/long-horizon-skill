# record-38d5eec70a: team notifications
Alias used in the design review: status filters. Local variant: record-dce8c08a5e.8.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-12: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-20923d595e. Deployment/exposure: 2026-04-15, receipt record-2c55c6e123; 5% of eligible production accounts. The original observation is history/evidence/record-b4e3010c67.md. Later review: history/evidence/record-af15a13149.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
