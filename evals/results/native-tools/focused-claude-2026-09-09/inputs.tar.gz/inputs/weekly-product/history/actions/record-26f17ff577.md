# record-26f17ff577: team notifications
Alias used in the design review: status filters. Local variant: record-431a358680.16.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-28: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-35b1377643. Deployment/exposure: 2026-07-01, receipt record-99867464a0; 15% of eligible production accounts. The original observation is history/evidence/record-5064b57bd7.md. Later review: history/evidence/record-c40ad4a94a.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
