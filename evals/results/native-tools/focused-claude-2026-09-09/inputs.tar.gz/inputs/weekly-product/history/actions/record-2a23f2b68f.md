# record-2a23f2b68f: weekly note
Alias used in the design review: task drawer. Local variant: record-562146c9ea.15.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-11: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-48eba69711. Deployment/exposure: 2026-04-14, receipt record-ed7c48b2db; 25% of eligible production accounts. The original observation is history/evidence/record-734842ae42.md. Later review: history/evidence/record-c3eede7293.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-23; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
