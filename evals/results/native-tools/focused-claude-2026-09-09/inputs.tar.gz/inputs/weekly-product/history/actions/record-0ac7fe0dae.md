# record-0ac7fe0dae: team notifications
Alias used in the design review: status filters. Local variant: record-ec0e0ab09e.5.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-26: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-68ed3133b7. Deployment/exposure: 2026-06-29, receipt record-6a01ec22a0; 5% of eligible production accounts. The original observation is history/evidence/record-a76bd25f5c.md. Later review: history/evidence/record-b34ddd0c4d.md.
Disposition recorded after the first window: Disabled 2026-07-14, receipt record-ceee8d1aa9, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
