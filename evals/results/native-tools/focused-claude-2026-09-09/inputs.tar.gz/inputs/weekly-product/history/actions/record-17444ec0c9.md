# record-17444ec0c9: task drawer
Alias used in the design review: team notifications. Local variant: record-8ff9b086a1.10.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-26: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-2a76a73970. Deployment/exposure: 2026-03-01, receipt record-06fb70db67; 5% of eligible production accounts. The original observation is history/evidence/record-3bce17a14e.md. Later review: history/evidence/record-c25dc792a1.md.
Disposition recorded after the first window: Rolled back 2026-03-13, receipt record-22111265dd, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
