# record-293116ca9c: triage facets
Alias used in the design review: weekly note. Local variant: record-8ff9b086a1.13.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-21: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-fb1d44f9db. Deployment/exposure: 2026-05-24, receipt record-a1d1816a5d; 25% of eligible production accounts. The original observation is history/evidence/record-28cb1bc6fb.md. Later review: history/evidence/record-f23641f23a.md.
Disposition recorded after the first window: Disabled 2026-06-08, receipt record-d36e6603e6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
