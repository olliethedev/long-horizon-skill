# record-251bb2db59: status filters
Alias used in the design review: Focus Shelf. Local variant: record-dce8c08a5e.15.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-13: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-5ba4b7182f. Deployment/exposure: 2026-04-16, receipt record-d39e9fd207; 10% of eligible production accounts. The original observation is history/evidence/record-e095f67600.md. Later review: history/evidence/record-1e4e6dd31c.md.
Disposition recorded after the first window: Rolled back 2026-04-28, receipt record-a30de7c546, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
