# record-394eea70f4: team notifications
Alias used in the design review: status filters. Local variant: record-562146c9ea.3.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-05: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-411afd926f. Deployment/exposure: 2026-07-08, receipt record-6c8a3d00bd; 25% of eligible production accounts. The original observation is history/evidence/record-1e5eefc86f.md. Later review: history/evidence/record-136137d72d.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-17; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
