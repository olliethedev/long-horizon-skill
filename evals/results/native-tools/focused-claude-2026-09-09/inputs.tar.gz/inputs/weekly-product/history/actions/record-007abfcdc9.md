# record-007abfcdc9: team notifications
Alias used in the design review: status filters. Local variant: record-647d99546c.9.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-19: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-4e732d3af6. Deployment/exposure: 2026-06-22, receipt record-d183c9ec1e; 20% of eligible production accounts. The original observation is history/evidence/record-6d3839f5d2.md. Later review: history/evidence/record-d037027c93.md.
Disposition recorded after the first window: Disabled 2026-07-03, receipt record-f5da32e6bc, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
