# record-2e545bfa73: team notifications
Alias used in the design review: status filters. Local variant: record-562146c9ea.11.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-12: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-ca9c5c7660. Deployment/exposure: 2026-04-15, receipt record-a4c20afec6; 5% of eligible production accounts. The original observation is history/evidence/record-615a2bce11.md. Later review: history/evidence/record-56c5358790.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-28; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
