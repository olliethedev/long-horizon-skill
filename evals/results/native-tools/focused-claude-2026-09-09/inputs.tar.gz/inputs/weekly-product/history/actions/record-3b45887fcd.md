# record-3b45887fcd: team notifications
Alias used in the design review: status filters. Local variant: record-cd29ee5f7a.14.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-04: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-92e0ea8d67. Deployment/exposure: 2026-04-07, receipt record-7435f93fa2; 15% of eligible production accounts. The original observation is history/evidence/record-1b126573ec.md. Later review: history/evidence/record-f98f0460a1.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
