# record-274dbae61a: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.14.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-13: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-277e4a42fc. Deployment/exposure: 2026-07-16, receipt record-c40372bfcf; 15% of eligible production accounts. The original observation is history/evidence/record-b661be1819.md. Later review: history/evidence/record-2c0fb20ef9.md.
Disposition recorded after the first window: Rolled back 2026-07-28, receipt record-8c2586cf9c, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
