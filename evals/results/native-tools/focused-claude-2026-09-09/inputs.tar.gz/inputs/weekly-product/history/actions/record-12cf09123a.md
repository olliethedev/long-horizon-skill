# record-12cf09123a: triage facets
Alias used in the design review: weekly note. Local variant: record-8ff9b086a1.16.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-c670903d07. Deployment/exposure: 2026-06-21, receipt record-ac72563cf8; 15% of eligible production accounts. The original observation is history/evidence/record-03b61d7c82.md. Later review: history/evidence/record-ca77b63792.md.
Disposition recorded after the first window: Disabled 2026-07-02, receipt record-0c9ea8c15d, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
