# record-0fa10ab28b: task drawer
Alias used in the design review: team notifications. Local variant: record-647d99546c.15.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-11: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-2b7992bb9d. Deployment/exposure: 2026-03-14, receipt record-157719451f; 20% of eligible production accounts. The original observation is history/evidence/record-12c9b22bc2.md. Later review: history/evidence/record-abf6d808ff.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-27; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
