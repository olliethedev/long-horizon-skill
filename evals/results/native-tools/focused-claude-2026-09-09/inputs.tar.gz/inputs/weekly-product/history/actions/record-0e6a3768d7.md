# record-0e6a3768d7: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-dce8c08a5e.13.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-25: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-b7795be4a4. Deployment/exposure: 2026-07-28, receipt record-87c5ed84fd; 25% of eligible production accounts. The original observation is history/evidence/record-8bdd0e2b03.md. Later review: history/evidence/record-c7bc02bd6a.md.
Disposition recorded after the first window: Disabled 2026-08-08, receipt record-fa28b4b521, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
