# record-30c371c5f9: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-ec0e0ab09e.2.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-03: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-6f4e9d0e95. Deployment/exposure: 2026-04-06, receipt record-b1d5eda6aa; 10% of eligible production accounts. The original observation is history/evidence/record-1cbe0e8bcd.md. Later review: history/evidence/record-fd63a6bee4.md.
Disposition recorded after the first window: Rolled back 2026-04-18, receipt record-326e8f841b, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
