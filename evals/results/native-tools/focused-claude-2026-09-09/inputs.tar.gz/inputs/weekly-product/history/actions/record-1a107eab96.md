# record-1a107eab96: Sunday Room
Alias used in the design review: triage facets. Local variant: record-cd29ee5f7a.12.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-15: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-97e9baa9da. Deployment/exposure: 2026-03-18, receipt record-1c6894a85d; 15% of eligible production accounts. The original observation is history/evidence/record-1067f8da03.md. Later review: history/evidence/record-9eae2d4b74.md.
Disposition recorded after the first window: Disabled 2026-04-02, receipt record-92f7a186b9, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
