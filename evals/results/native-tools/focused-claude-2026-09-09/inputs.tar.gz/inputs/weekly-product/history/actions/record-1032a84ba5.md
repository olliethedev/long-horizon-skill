# record-1032a84ba5: triage facets
Alias used in the design review: weekly note. Local variant: record-647d99546c.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-20: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-eab9d020f1. Deployment/exposure: 2026-05-23, receipt record-b462020ed4; 20% of eligible production accounts. The original observation is history/evidence/record-6c780ef520.md. Later review: history/evidence/record-1702f30647.md.
Disposition recorded after the first window: Rolled back 2026-05-31, receipt record-b73f8f2995, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
