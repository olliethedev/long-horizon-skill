# record-27e7a76ea7: weekly note
Alias used in the design review: task drawer. Local variant: record-cd29ee5f7a.12.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-d8eafb14ad. Deployment/exposure: 2026-04-28, receipt record-a329270863; 20% of eligible production accounts. The original observation is history/evidence/record-40b655499f.md. Later review: history/evidence/record-226628cb57.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
