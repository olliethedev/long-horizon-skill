# record-37ebd5ce12: team notifications
Alias used in the design review: status filters. Local variant: record-dce8c08a5e.12.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-22: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-0646d1f248. Deployment/exposure: 2026-05-25, receipt record-838e25931d; 5% of eligible production accounts. The original observation is history/evidence/record-88b5650a45.md. Later review: history/evidence/record-ee58c5bdc3.md.
Disposition recorded after the first window: Disabled 2026-06-09, receipt record-0d1b38fc18, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
