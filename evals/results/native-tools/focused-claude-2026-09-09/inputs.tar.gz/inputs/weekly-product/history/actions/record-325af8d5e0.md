# record-325af8d5e0: Sunday Room
Alias used in the design review: triage facets. Local variant: record-b88d0e3215.5.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-22: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-b330944578. Deployment/exposure: 2026-03-25, receipt record-1ba294e678; 25% of eligible production accounts. The original observation is history/evidence/record-66cc211171.md. Later review: history/evidence/record-53ccc7d137.md.
Disposition recorded after the first window: Disabled 2026-04-09, receipt record-d9f8349db6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
