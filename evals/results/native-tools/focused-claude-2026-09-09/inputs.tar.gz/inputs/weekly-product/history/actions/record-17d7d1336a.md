# record-17d7d1336a: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-192230d558.4.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-13: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-688f58527d. Deployment/exposure: 2026-06-16, receipt record-8d8e2480c5; 15% of eligible production accounts. The original observation is history/evidence/record-c48968846b.md. Later review: history/evidence/record-f6d2bcd2a2.md.
Disposition recorded after the first window: Disabled 2026-06-27, receipt record-6bec78cbba, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
