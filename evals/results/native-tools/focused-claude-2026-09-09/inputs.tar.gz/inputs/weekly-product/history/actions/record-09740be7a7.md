# record-09740be7a7: task drawer
Alias used in the design review: team notifications. Local variant: record-ec0e0ab09e.5.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-09: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-beae0266b0. Deployment/exposure: 2026-04-12, receipt record-616774a1b5; 15% of eligible production accounts. The original observation is history/evidence/record-1f1036d7de.md. Later review: history/evidence/record-6f1775f588.md.
Disposition recorded after the first window: Rolled back 2026-04-20, receipt record-340416031b, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
