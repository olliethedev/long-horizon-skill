# record-1cafa4663e: triage facets
Alias used in the design review: weekly note. Local variant: record-8ff9b086a1.0.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-25: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-aa8a143620. Deployment/exposure: 2026-03-28, receipt record-2da24b29bb; 15% of eligible production accounts. The original observation is history/evidence/record-7ea1dcee34.md. Later review: history/evidence/record-2c6ae294e7.md.
Disposition recorded after the first window: Rolled back 2026-04-09, receipt record-c3b7e8935d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
