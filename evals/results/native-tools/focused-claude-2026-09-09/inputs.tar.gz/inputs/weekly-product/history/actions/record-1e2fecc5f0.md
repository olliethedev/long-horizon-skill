# record-1e2fecc5f0: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.14.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-24: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-db6a9cf539. Deployment/exposure: 2026-02-27, receipt record-a4eb074987; 20% of eligible production accounts. The original observation is history/evidence/record-be05b3f5b8.md. Later review: history/evidence/record-7cfabc670b.md.
Disposition recorded after the first window: Disabled 2026-03-14, receipt record-6929217b47, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
