# record-388ecb79e7: triage facets
Alias used in the design review: weekly note. Local variant: record-431a358680.7.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-01: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-e3302f0c25. Deployment/exposure: 2026-04-04, receipt record-9bd15d8401; 25% of eligible production accounts. The original observation is history/evidence/record-4bf0278179.md. Later review: history/evidence/record-3689ffa1d7.md.
Disposition recorded after the first window: Rolled back 2026-04-12, receipt record-25f31fba1a, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
