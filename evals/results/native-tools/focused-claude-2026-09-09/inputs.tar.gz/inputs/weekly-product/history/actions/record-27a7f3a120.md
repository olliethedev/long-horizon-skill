# record-27a7f3a120: team notifications
Alias used in the design review: status filters. Local variant: record-ec0e0ab09e.11.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-29: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-2060f05ba8. Deployment/exposure: 2026-04-01, receipt record-13c0456280; 10% of eligible production accounts. The original observation is history/evidence/record-8417fe3d88.md. Later review: history/evidence/record-0ede4d40d3.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-10; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
