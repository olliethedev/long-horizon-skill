# record-17e35ded04: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-192230d558.16.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-17: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-b3c3467ac3. Deployment/exposure: 2026-07-20, receipt record-e4810e94bf; 10% of eligible production accounts. The original observation is history/evidence/record-91a21dede1.md. Later review: history/evidence/record-9d638e9487.md.
Disposition recorded after the first window: Rolled back 2026-08-01, receipt record-38cb85b7a2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
