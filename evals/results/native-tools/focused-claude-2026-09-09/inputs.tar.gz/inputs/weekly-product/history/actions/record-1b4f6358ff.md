# record-1b4f6358ff: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.13.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-03: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-b42a797e17. Deployment/exposure: 2026-03-06, receipt record-af2046ff97; 5% of eligible production accounts. The original observation is history/evidence/record-4d89f674d4.md. Later review: history/evidence/record-7adc5c7e48.md.
Disposition recorded after the first window: Disabled 2026-03-21, receipt record-50857ecbdf, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
