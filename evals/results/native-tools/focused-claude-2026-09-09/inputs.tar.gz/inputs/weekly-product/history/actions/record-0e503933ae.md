# record-0e503933ae: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.8.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-926769a2f2. Deployment/exposure: 2026-03-15, receipt record-9ce93950f2; 25% of eligible production accounts. The original observation is history/evidence/record-6307868bc8.md. Later review: history/evidence/record-cac1e5165b.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-28; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
