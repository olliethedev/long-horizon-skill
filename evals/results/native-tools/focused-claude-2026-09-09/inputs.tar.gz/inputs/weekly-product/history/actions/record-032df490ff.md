# record-032df490ff: quiet digest
Alias used in the design review: Sunday Room. Local variant: record-8ff9b086a1.10.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-2975cc08b3. Deployment/exposure: 2026-08-08, receipt record-8736742246; 5% of eligible production accounts. The original observation is history/evidence/record-53aa11713b.md. Later review: history/evidence/record-59179ffc05.md.
Disposition recorded after the first window: Disabled 2026-08-23, receipt record-7ef8952de6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
