# record-2f873f01fd: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-192230d558.10.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-08: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-c78cb341ca. Deployment/exposure: 2026-08-11, receipt record-537d619bb1; 20% of eligible production accounts. The original observation is history/evidence/record-0be6d4f739.md. Later review: history/evidence/record-0288807679.md.
Disposition recorded after the first window: Disabled 2026-08-22, receipt record-c410b8514f, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
