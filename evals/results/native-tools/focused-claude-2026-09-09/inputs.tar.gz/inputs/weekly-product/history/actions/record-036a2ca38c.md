# record-036a2ca38c: Sunday Room
Alias used in the design review: triage facets. Local variant: record-562146c9ea.10.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-21: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-52cf7e1141. Deployment/exposure: 2026-06-24, receipt record-1839779a16; 5% of eligible production accounts. The original observation is history/evidence/record-de42d65166.md. Later review: history/evidence/record-558b7d406e.md.
Disposition recorded after the first window: Disabled 2026-07-09, receipt record-49abdd9f0f, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
