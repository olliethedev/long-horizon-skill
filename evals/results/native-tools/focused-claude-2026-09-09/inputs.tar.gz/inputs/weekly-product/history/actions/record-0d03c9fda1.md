# record-0d03c9fda1: task drawer
Alias used in the design review: team notifications. Local variant: record-192230d558.15.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-14: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-5bc536dce8. Deployment/exposure: 2026-05-17, receipt record-62ee2836d3; 15% of eligible production accounts. The original observation is history/evidence/record-3306d7f2b8.md. Later review: history/evidence/record-ba4d890e3d.md.
Disposition recorded after the first window: Rolled back 2026-05-25, receipt record-12cef7fd2d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
