# record-1648e5af0f: status filters
Alias used in the design review: Focus Shelf. Local variant: record-647d99546c.9.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-13: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-06fc4df05b. Deployment/exposure: 2026-05-16, receipt record-298bb0fbaa; 10% of eligible production accounts. The original observation is history/evidence/record-930791edd8.md. Later review: history/evidence/record-781bc932c4.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
