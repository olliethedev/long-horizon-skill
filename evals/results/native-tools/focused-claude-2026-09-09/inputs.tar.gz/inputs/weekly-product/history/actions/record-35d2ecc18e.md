# record-35d2ecc18e: status filters
Alias used in the design review: Focus Shelf. Local variant: record-562146c9ea.5.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-03: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-d1581ad98f. Deployment/exposure: 2026-06-06, receipt record-6fdc583347; 15% of eligible production accounts. The original observation is history/evidence/record-4a0c6cfa58.md. Later review: history/evidence/record-3799c711db.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
