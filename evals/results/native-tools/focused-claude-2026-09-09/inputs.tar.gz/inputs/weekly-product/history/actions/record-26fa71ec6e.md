# record-26fa71ec6e: status filters
Alias used in the design review: Focus Shelf. Local variant: record-562146c9ea.4.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-28: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-f22555674e. Deployment/exposure: 2026-07-31, receipt record-117675a8ac; 15% of eligible production accounts. The original observation is history/evidence/record-9bda5c821a.md. Later review: history/evidence/record-3ab3d24ed6.md.
Disposition recorded after the first window: Disabled 2026-08-11, receipt record-48d91cef41, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
