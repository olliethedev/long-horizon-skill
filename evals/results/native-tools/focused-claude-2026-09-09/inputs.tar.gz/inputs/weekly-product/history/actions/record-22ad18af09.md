# record-22ad18af09: task drawer
Alias used in the design review: team notifications. Local variant: record-b88d0e3215.1.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-b1b1fbea6a. Deployment/exposure: 2026-04-25, receipt record-49c3d3b92e; 5% of eligible production accounts. The original observation is history/evidence/record-502f25b12b.md. Later review: history/evidence/record-4efa8d3312.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-08; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
