# record-1a99ba17b0: triage facets
Alias used in the design review: weekly note. Local variant: record-647d99546c.10.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-21: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-dcbfb68cdf. Deployment/exposure: 2026-05-24, receipt record-5966dd908a; 25% of eligible production accounts. The original observation is history/evidence/record-f23b42de0f.md. Later review: history/evidence/record-6d4310b774.md.
Disposition recorded after the first window: Disabled 2026-06-04, receipt record-6c47156f4d, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
