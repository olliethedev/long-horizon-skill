# record-2d2a0fd759: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.15.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-19: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-db82595c5e. Deployment/exposure: 2026-05-22, receipt record-c4ecf24a7f; 15% of eligible production accounts. The original observation is history/evidence/record-06a0b3cadd.md. Later review: history/evidence/record-e648591c61.md.
Disposition recorded after the first window: Disabled 2026-06-06, receipt record-3c5c447198, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
