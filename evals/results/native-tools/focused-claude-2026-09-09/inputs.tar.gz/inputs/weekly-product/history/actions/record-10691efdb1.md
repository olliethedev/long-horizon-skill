# record-10691efdb1: status filters
Alias used in the design review: Focus Shelf. Local variant: record-562146c9ea.8.2.
Originating responsibility: retained-growth. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-01: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-ea57efdedc. Deployment/exposure: 2026-07-04, receipt record-ea0ac03338; 5% of eligible production accounts. The original observation is history/evidence/record-f3231b0530.md. Later review: history/evidence/record-d10bbac8c0.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
