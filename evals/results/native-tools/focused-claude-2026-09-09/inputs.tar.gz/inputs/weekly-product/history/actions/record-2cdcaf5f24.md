# record-2cdcaf5f24: team notifications
Alias used in the design review: status filters. Local variant: record-647d99546c.15.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-22: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-6b80fd3107. Deployment/exposure: 2026-03-25, receipt record-5a3ad3b9da; 25% of eligible production accounts. The original observation is history/evidence/record-893033fd22.md. Later review: history/evidence/record-2e48d153ea.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
