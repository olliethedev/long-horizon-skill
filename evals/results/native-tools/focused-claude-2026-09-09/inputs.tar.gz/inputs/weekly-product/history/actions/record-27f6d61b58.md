# record-27f6d61b58: Sunday Room
Alias used in the design review: triage facets. Local variant: record-431a358680.13.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-34588dcdad. Deployment/exposure: 2026-05-19, receipt record-0d0f0dffdc; 25% of eligible production accounts. The original observation is history/evidence/record-5d2ac274f8.md. Later review: history/evidence/record-895e933731.md.
Disposition recorded after the first window: Rolled back 2026-05-27, receipt record-2d2cd2eb06, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
