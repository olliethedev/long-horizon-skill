# record-297c2fedb0: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-8ff9b086a1.7.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-27: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-2a4f1d5638. Deployment/exposure: 2026-06-30, receipt record-9685f6dbbb; 10% of eligible production accounts. The original observation is history/evidence/record-a595ec92a8.md. Later review: history/evidence/record-525f5a3c97.md.
Disposition recorded after the first window: Disabled 2026-07-11, receipt record-fdb4249e9a, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
