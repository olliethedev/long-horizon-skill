# record-3a7f1f317d: status filters
Alias used in the design review: Focus Shelf. Local variant: record-8ff9b086a1.1.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-08: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-65238718c2. Deployment/exposure: 2026-06-11, receipt record-1798e967e3; 15% of eligible production accounts. The original observation is history/evidence/record-9a244b5e12.md. Later review: history/evidence/record-d397f8743b.md.
Disposition recorded after the first window: Rolled back 2026-06-19, receipt record-d91ab3a942, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
