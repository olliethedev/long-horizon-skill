# record-2a6d8146e9: Sunday Room
Alias used in the design review: triage facets. Local variant: record-cd29ee5f7a.13.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-13: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-bc037212ae. Deployment/exposure: 2026-06-16, receipt record-59782ed6be; 15% of eligible production accounts. The original observation is history/evidence/record-778443b6be.md. Later review: history/evidence/record-44cc030d3f.md.
Disposition recorded after the first window: Rolled back 2026-06-24, receipt record-de81ee0b6d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
