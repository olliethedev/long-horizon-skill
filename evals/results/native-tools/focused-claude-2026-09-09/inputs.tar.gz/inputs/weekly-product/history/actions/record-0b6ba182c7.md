# record-0b6ba182c7: team notifications
Alias used in the design review: status filters. Local variant: record-431a358680.4.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-31: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-db078e017b. Deployment/exposure: 2026-08-03, receipt record-6aec6bbbba; 5% of eligible production accounts. The original observation is history/evidence/record-3c87819cd3.md. Later review: history/evidence/record-3782b17736.md.
Disposition recorded after the first window: Disabled 2026-08-18, receipt record-e1f3505d0b, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
