# record-36bc8a4d44: Sunday Room
Alias used in the design review: triage facets. Local variant: record-cd29ee5f7a.0.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-17: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-307e03cac2. Deployment/exposure: 2026-04-20, receipt record-3626906a7f; 5% of eligible production accounts. The original observation is history/evidence/record-8b2f2c79cf.md. Later review: history/evidence/record-11eee6f5ad.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-03; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
