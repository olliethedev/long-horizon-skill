# record-2201bfdebe: status filters
Alias used in the design review: Focus Shelf. Local variant: record-cd29ee5f7a.1.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-a95b2c50d8. Deployment/exposure: 2026-06-27, receipt record-766eb2837d; 20% of eligible production accounts. The original observation is history/evidence/record-5a2a38176a.md. Later review: history/evidence/record-a51061c78b.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
