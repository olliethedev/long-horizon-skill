# record-0587c3f4e1: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-192230d558.16.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-11: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-988dba9898. Deployment/exposure: 2026-04-14, receipt record-2cce4e7d5d; 25% of eligible production accounts. The original observation is history/evidence/record-b45517fd67.md. Later review: history/evidence/record-22f6c2a66c.md.
Disposition recorded after the first window: Disabled 2026-04-25, receipt record-020aedf08a, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
