# record-3213c9df23: task drawer
Alias used in the design review: team notifications. Local variant: record-647d99546c.15.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-41ec7ee65d. Deployment/exposure: 2026-08-06, receipt record-d3150b3590; 20% of eligible production accounts. The original observation is history/evidence/record-7cc2dc92bf.md. Later review: history/evidence/record-75eda074e9.md.
Disposition recorded after the first window: Disabled 2026-08-17, receipt record-97329cf083, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
