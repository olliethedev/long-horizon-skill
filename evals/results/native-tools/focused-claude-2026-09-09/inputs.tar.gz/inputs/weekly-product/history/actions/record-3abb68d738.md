# record-3abb68d738: team notifications
Alias used in the design review: status filters. Local variant: record-ec0e0ab09e.4.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-03: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-249e50baff. Deployment/exposure: 2026-07-06, receipt record-a87831e432; 15% of eligible production accounts. The original observation is history/evidence/record-34315f6046.md. Later review: history/evidence/record-5b0ed20b23.md.
Disposition recorded after the first window: Disabled 2026-07-21, receipt record-23331255c4, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
