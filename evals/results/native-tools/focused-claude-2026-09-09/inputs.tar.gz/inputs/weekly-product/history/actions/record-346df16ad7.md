# record-346df16ad7: Sunday Room
Alias used in the design review: triage facets. Local variant: record-562146c9ea.10.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-04: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-d4708c4c53. Deployment/exposure: 2026-04-07, receipt record-08c3bfbfae; 15% of eligible production accounts. The original observation is history/evidence/record-60bbac7993.md. Later review: history/evidence/record-6b46fe092f.md.
Disposition recorded after the first window: Rolled back 2026-04-15, receipt record-fecfc9e90b, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
