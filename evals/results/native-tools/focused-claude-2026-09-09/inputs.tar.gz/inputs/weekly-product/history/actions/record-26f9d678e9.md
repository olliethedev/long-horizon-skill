# record-26f9d678e9: team notifications
Alias used in the design review: status filters. Local variant: record-192230d558.11.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-10: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-2a45956e27. Deployment/exposure: 2026-07-13, receipt record-5a2453fafc; 25% of eligible production accounts. The original observation is history/evidence/record-8c9f2939ce.md. Later review: history/evidence/record-2aecf1c393.md.
Disposition recorded after the first window: Disabled 2026-07-24, receipt record-297e59fac6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
