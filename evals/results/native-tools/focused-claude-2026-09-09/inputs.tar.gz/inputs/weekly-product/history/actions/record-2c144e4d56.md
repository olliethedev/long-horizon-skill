# record-2c144e4d56: team notifications
Alias used in the design review: status filters. Local variant: record-b88d0e3215.5.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-12: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-cba29ebe99. Deployment/exposure: 2026-06-15, receipt record-b9451853e9; 10% of eligible production accounts. The original observation is history/evidence/record-a2da2df50f.md. Later review: history/evidence/record-1b749ff91b.md.
Disposition recorded after the first window: Disabled 2026-06-26, receipt record-5e0236dea2, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
