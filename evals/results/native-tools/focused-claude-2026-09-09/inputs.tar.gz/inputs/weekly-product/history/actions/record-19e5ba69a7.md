# record-19e5ba69a7: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-562146c9ea.5.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-14: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-b26800383b. Deployment/exposure: 2026-06-17, receipt record-2999090e9d; 20% of eligible production accounts. The original observation is history/evidence/record-dd4c7d04e0.md. Later review: history/evidence/record-7fcf316da4.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
