# record-286c1d76fb: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.13.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-20: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-c94346d0b2. Deployment/exposure: 2026-07-23, receipt record-ba93f21595; 25% of eligible production accounts. The original observation is history/evidence/record-6a575375d9.md. Later review: history/evidence/record-d8b616d111.md.
Disposition recorded after the first window: Rolled back 2026-08-04, receipt record-7b3e288909, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
