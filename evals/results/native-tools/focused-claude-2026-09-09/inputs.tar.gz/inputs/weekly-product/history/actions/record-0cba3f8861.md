# record-0cba3f8861: team notifications
Alias used in the design review: status filters. Local variant: record-8ff9b086a1.6.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-24: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-24ad216897. Deployment/exposure: 2026-04-27, receipt record-8ca5190f0b; 15% of eligible production accounts. The original observation is history/evidence/record-162fb579bf.md. Later review: history/evidence/record-78a8b49060.md.
Disposition recorded after the first window: Disabled 2026-05-12, receipt record-2ef5e3e9cf, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
