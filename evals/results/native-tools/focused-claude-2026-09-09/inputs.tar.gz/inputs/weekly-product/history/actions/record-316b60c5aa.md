# record-316b60c5aa: triage facets
Alias used in the design review: weekly note. Local variant: record-dce8c08a5e.6.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-22: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-d6da5133df. Deployment/exposure: 2026-04-25, receipt record-33592c7636; 5% of eligible production accounts. The original observation is history/evidence/record-35533623ae.md. Later review: history/evidence/record-62f2a9c28d.md.
Disposition recorded after the first window: Rolled back 2026-05-07, receipt record-36d2934fb0, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
