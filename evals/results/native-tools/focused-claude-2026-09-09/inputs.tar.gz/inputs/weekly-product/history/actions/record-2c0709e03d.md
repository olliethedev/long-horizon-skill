# record-2c0709e03d: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.10.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-16: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-1835f88761. Deployment/exposure: 2026-04-19, receipt record-79f18e4284; 25% of eligible production accounts. The original observation is history/evidence/record-e7058b076f.md. Later review: history/evidence/record-2475737769.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-28; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
