# record-3aa8ee92b8: weekly note
Alias used in the design review: task drawer. Local variant: record-dce8c08a5e.4.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-04: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-c234813deb. Deployment/exposure: 2026-07-07, receipt record-1d4a4f5868; 20% of eligible production accounts. The original observation is history/evidence/record-7c8b4b4b1e.md. Later review: history/evidence/record-c973e1a48c.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-16; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
