# record-2bce6ec964: team notifications
Alias used in the design review: status filters. Local variant: record-562146c9ea.15.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-22: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-435671feb4. Deployment/exposure: 2026-05-25, receipt record-87c0f7cb3f; 5% of eligible production accounts. The original observation is history/evidence/record-4af17026bb.md. Later review: history/evidence/record-c7920266c4.md.
Disposition recorded after the first window: Disabled 2026-06-05, receipt record-d466c11e7c, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
