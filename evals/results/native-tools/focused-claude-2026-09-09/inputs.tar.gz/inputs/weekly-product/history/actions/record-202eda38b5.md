# record-202eda38b5: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-431a358680.1.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-08: similar workspace names made successful activity look unrelated. The proposed change was to show the affected workspace in the activity row.
Implementation: record-0453b1183d. Deployment/exposure: 2026-05-11, receipt record-a302cf5dd1; 10% of eligible production accounts. The original observation is history/evidence/record-c6b5692272.md. Later review: history/evidence/record-765f88ca2d.md.
Disposition recorded after the first window: Rolled back 2026-05-23, receipt record-98d49a9dc3, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
