# record-15c35f1ee8: weekly note
Alias used in the design review: task drawer. Local variant: record-192230d558.9.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-25: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-f8d4caca16. Deployment/exposure: 2026-04-28, receipt record-a924e1fddf; 20% of eligible production accounts. The original observation is history/evidence/record-7db577e88f.md. Later review: history/evidence/record-455546ee42.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-11; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
