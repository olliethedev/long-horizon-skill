# record-28cae65d33: status filters
Alias used in the design review: Focus Shelf. Local variant: record-dce8c08a5e.11.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-04: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-d8a6a5d7dc. Deployment/exposure: 2026-03-07, receipt record-67bfa0503e; 10% of eligible production accounts. The original observation is history/evidence/record-4704b5707b.md. Later review: history/evidence/record-20b1200c49.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
