# record-103a4ba5b2: status filters
Alias used in the design review: Focus Shelf. Local variant: record-b88d0e3215.5.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-06: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-80e37f1891. Deployment/exposure: 2026-04-09, receipt record-8bdb0f2ba3; 25% of eligible production accounts. The original observation is history/evidence/record-aeccf8d90a.md. Later review: history/evidence/record-899837e83d.md.
Disposition recorded after the first window: Rolled back 2026-04-21, receipt record-12ab09525e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
