# record-05b4f8c9f1: task drawer
Alias used in the design review: team notifications. Local variant: record-192230d558.4.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-09: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-dba990dfac. Deployment/exposure: 2026-07-12, receipt record-0a1bce7474; 20% of eligible production accounts. The original observation is history/evidence/record-64500e998e.md. Later review: history/evidence/record-b290828b1a.md.
Disposition recorded after the first window: Rolled back 2026-07-20, receipt record-d6d004a9dd, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
