# record-1edc6be0f4: status filters
Alias used in the design review: Focus Shelf. Local variant: record-dce8c08a5e.4.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-663c0022ba. Deployment/exposure: 2026-04-05, receipt record-9265c76a60; 5% of eligible production accounts. The original observation is history/evidence/record-1ae9e0b762.md. Later review: history/evidence/record-2edbe66fb8.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-18; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
