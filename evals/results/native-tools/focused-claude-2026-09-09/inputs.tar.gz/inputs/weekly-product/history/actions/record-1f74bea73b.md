# record-1f74bea73b: task drawer
Alias used in the design review: team notifications. Local variant: record-192230d558.12.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-22: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-c349d3e53d. Deployment/exposure: 2026-06-25, receipt record-464bfb52b9; 10% of eligible production accounts. The original observation is history/evidence/record-301ab4d5ea.md. Later review: history/evidence/record-465abfb436.md.
Disposition recorded after the first window: Disabled 2026-07-06, receipt record-0b5c279468, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
