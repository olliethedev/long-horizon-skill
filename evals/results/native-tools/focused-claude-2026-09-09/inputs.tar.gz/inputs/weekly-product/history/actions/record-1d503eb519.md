# record-1d503eb519: team notifications
Alias used in the design review: status filters. Local variant: record-8ff9b086a1.4.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-19: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-8d14dad59a. Deployment/exposure: 2026-04-22, receipt record-c2ac4401ec; 15% of eligible production accounts. The original observation is history/evidence/record-7d0226763b.md. Later review: history/evidence/record-f785e98f91.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-05; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
