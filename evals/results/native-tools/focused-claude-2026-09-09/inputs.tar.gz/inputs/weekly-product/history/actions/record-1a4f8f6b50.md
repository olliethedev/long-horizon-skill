# record-1a4f8f6b50: Sunday Room
Alias used in the design review: triage facets. Local variant: record-647d99546c.1.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-04: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-3d8b2f6339. Deployment/exposure: 2026-04-07, receipt record-180f2c2950; 15% of eligible production accounts. The original observation is history/evidence/record-c63f92ed25.md. Later review: history/evidence/record-7752036bdf.md.
Disposition recorded after the first window: Rolled back 2026-04-19, receipt record-7b356ec3d4, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
