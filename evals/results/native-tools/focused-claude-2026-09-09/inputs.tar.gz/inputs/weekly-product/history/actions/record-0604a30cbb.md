# record-0604a30cbb: status filters
Alias used in the design review: Focus Shelf. Local variant: record-8ff9b086a1.1.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-08: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-18140358d9. Deployment/exposure: 2026-07-11, receipt record-410a00e75d; 15% of eligible production accounts. The original observation is history/evidence/record-84500de20c.md. Later review: history/evidence/record-f2e47f3651.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
