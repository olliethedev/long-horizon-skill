# record-0bd1ee62b0: task drawer
Alias used in the design review: team notifications. Local variant: record-b88d0e3215.6.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-25: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-e1b3288758. Deployment/exposure: 2026-05-28, receipt record-6206ebfdf6; 20% of eligible production accounts. The original observation is history/evidence/record-942e660f56.md. Later review: history/evidence/record-4c6fb3bc6e.md.
Disposition recorded after the first window: Disabled 2026-06-08, receipt record-3b4cb07fca, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
