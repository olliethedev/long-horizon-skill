# record-1038dfd993: quiet digest
Alias used in the design review: Sunday Room. Local variant: record-dce8c08a5e.11.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-14: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-3c56241973. Deployment/exposure: 2026-04-17, receipt record-75a7211edc; 15% of eligible production accounts. The original observation is history/evidence/record-e9ff160182.md. Later review: history/evidence/record-3949220e2c.md.
Disposition recorded after the first window: Rolled back 2026-04-25, receipt record-6ee33c097d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
