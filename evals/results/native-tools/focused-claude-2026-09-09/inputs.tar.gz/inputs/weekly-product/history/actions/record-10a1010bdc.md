# record-10a1010bdc: Sunday Room
Alias used in the design review: triage facets. Local variant: record-562146c9ea.3.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-03: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-3d04bf0a4c. Deployment/exposure: 2026-04-06, receipt record-2e33ef5262; 10% of eligible production accounts. The original observation is history/evidence/record-fd8de13c77.md. Later review: history/evidence/record-efec231e38.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-04-19; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
