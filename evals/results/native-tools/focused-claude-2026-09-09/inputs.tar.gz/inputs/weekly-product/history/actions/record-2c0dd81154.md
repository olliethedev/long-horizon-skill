# record-2c0dd81154: task drawer
Alias used in the design review: team notifications. Local variant: record-562146c9ea.11.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-18: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-c9cf2ff01e. Deployment/exposure: 2026-06-21, receipt record-cc117581e8; 15% of eligible production accounts. The original observation is history/evidence/record-59fe8df329.md. Later review: history/evidence/record-81d2601fb6.md.
Disposition recorded after the first window: Rolled back 2026-07-03, receipt record-1f0fe28bb9, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
