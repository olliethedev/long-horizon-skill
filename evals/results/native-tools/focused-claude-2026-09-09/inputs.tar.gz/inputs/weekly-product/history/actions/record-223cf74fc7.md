# record-223cf74fc7: task drawer
Alias used in the design review: team notifications. Local variant: record-8ff9b086a1.0.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-22: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-cdc7c2c160. Deployment/exposure: 2026-07-25, receipt record-0988689595; 10% of eligible production accounts. The original observation is history/evidence/record-1edbd716b7.md. Later review: history/evidence/record-ee7a528185.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
