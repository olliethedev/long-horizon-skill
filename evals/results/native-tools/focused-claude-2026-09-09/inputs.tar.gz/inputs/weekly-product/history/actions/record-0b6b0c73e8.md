# record-0b6b0c73e8: task drawer
Alias used in the design review: team notifications. Local variant: record-cd29ee5f7a.4.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-11: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-e622f59a83. Deployment/exposure: 2026-06-14, receipt record-474cf55f60; 5% of eligible production accounts. The original observation is history/evidence/record-7225cbe992.md. Later review: history/evidence/record-96ada56b47.md.
Disposition recorded after the first window: Rolled back 2026-06-22, receipt record-ec03765e3e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
