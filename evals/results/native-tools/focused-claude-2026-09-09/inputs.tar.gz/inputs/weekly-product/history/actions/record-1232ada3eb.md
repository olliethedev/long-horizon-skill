# record-1232ada3eb: task drawer
Alias used in the design review: team notifications. Local variant: record-562146c9ea.5.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-e96cda786c. Deployment/exposure: 2026-04-26, receipt record-0e00220f34; 10% of eligible production accounts. The original observation is history/evidence/record-757c797bf5.md. Later review: history/evidence/record-180876d98e.md.
Disposition recorded after the first window: Rolled back 2026-05-08, receipt record-1417e0bc9d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
