# record-03b4ce7ab4: status filters
Alias used in the design review: Focus Shelf. Local variant: record-647d99546c.12.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-10: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-121070c627. Deployment/exposure: 2026-06-13, receipt record-5fc0f6cfbb; 25% of eligible production accounts. The original observation is history/evidence/record-64083ca685.md. Later review: history/evidence/record-67300558d5.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
