# record-054ffcc99d: task drawer
Alias used in the design review: team notifications. Local variant: record-b88d0e3215.2.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-15: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-dfcc169379. Deployment/exposure: 2026-04-18, receipt record-db8190112e; 20% of eligible production accounts. The original observation is history/evidence/record-792396bd61.md. Later review: history/evidence/record-a83bd7dcef.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-05-01; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
