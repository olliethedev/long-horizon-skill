# record-2e9d061bdb: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.12.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-19: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-28e112a6f3. Deployment/exposure: 2026-02-22, receipt record-390393e9ea; 20% of eligible production accounts. The original observation is history/evidence/record-b391ae7d38.md. Later review: history/evidence/record-573006ae0f.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
