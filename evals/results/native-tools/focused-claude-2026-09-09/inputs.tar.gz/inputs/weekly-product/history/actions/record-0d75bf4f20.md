# record-0d75bf4f20: task drawer
Alias used in the design review: team notifications. Local variant: record-8ff9b086a1.1.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-03: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-946e35578b. Deployment/exposure: 2026-08-06, receipt record-c1ee919761; 20% of eligible production accounts. The original observation is history/evidence/record-2837825a54.md. Later review: history/evidence/record-1468e488ab.md.
Disposition recorded after the first window: Disabled 2026-08-21, receipt record-1f90af00b3, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
