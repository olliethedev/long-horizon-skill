# record-29c3f9ca4c: weekly note
Alias used in the design review: task drawer. Local variant: record-8ff9b086a1.7.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-12: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-0079e73b5c. Deployment/exposure: 2026-07-15, receipt record-c573dc5466; 10% of eligible production accounts. The original observation is history/evidence/record-9f116816ac.md. Later review: history/evidence/record-2f69dd7b6d.md.
Disposition recorded after the first window: Rolled back 2026-07-23, receipt record-6a37377655, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
