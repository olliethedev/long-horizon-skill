# record-2b6bc80d28: status filters
Alias used in the design review: Focus Shelf. Local variant: record-562146c9ea.0.2.
Originating responsibility: retained-growth. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-01: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-04dda63580. Deployment/exposure: 2026-04-04, receipt record-2392bd8168; 25% of eligible production accounts. The original observation is history/evidence/record-de732ced0a.md. Later review: history/evidence/record-9a4f53bf66.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
