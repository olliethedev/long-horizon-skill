# record-172e8da65c: task drawer
Alias used in the design review: team notifications. Local variant: record-cd29ee5f7a.5.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-16: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-dc6c7490e0. Deployment/exposure: 2026-02-19, receipt record-d0ef858028; 5% of eligible production accounts. The original observation is history/evidence/record-b15351bb72.md. Later review: history/evidence/record-cd2acdb719.md.
Disposition recorded after the first window: Disabled 2026-03-06, receipt record-9a8c92923a, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
