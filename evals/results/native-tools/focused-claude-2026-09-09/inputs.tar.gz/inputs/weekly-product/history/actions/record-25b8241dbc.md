# record-25b8241dbc: task drawer
Alias used in the design review: team notifications. Local variant: record-b88d0e3215.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-19: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-76abdaf441. Deployment/exposure: 2026-02-22, receipt record-449e130920; 20% of eligible production accounts. The original observation is history/evidence/record-0b36d5ef59.md. Later review: history/evidence/record-061360ed73.md.
Disposition recorded after the first window: Rolled back 2026-03-02, receipt record-f2ea237b31, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
