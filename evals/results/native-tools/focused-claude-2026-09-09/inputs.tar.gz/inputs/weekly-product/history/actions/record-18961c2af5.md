# record-18961c2af5: triage facets
Alias used in the design review: weekly note. Local variant: record-b88d0e3215.7.0.
Originating responsibility: onboarding-cycle. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-02-18: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-cd73050c81. Deployment/exposure: 2026-02-21, receipt record-a7be9cd608; 15% of eligible production accounts. The original observation is history/evidence/record-f921453b60.md. Later review: history/evidence/record-c04f88905b.md.
Disposition recorded after the first window: Rolled back 2026-03-05, receipt record-a902c2a95a, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
