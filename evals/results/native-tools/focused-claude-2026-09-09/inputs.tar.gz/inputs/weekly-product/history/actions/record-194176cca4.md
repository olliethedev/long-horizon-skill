# record-194176cca4: triage facets
Alias used in the design review: weekly note. Local variant: record-192230d558.0.0.
Originating responsibility: onboarding-cycle. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-08: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-b8b54ca949. Deployment/exposure: 2026-04-11, receipt record-79faf2ae56; 10% of eligible production accounts. The original observation is history/evidence/record-fcfac55565.md. Later review: history/evidence/record-0eb6d949d8.md.
Disposition recorded after the first window: Rolled back 2026-04-19, receipt record-fb0aa13f6c, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
