# record-3807b2eafe: status filters
Alias used in the design review: Focus Shelf. Local variant: record-8ff9b086a1.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-16: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-d0d1172506. Deployment/exposure: 2026-03-19, receipt record-5d528b0cc9; 20% of eligible production accounts. The original observation is history/evidence/record-11878dfa46.md. Later review: history/evidence/record-99c52dda3f.md.
Disposition recorded after the first window: Rolled back 2026-03-31, receipt record-3a6c7721d8, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
