# record-291324de5a: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-dce8c08a5e.12.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-27: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-a2a5e25546. Deployment/exposure: 2026-03-30, receipt record-cdb53254b9; 25% of eligible production accounts. The original observation is history/evidence/record-6c5695ee58.md. Later review: history/evidence/record-17edf9f89a.md.
Disposition recorded after the first window: Rolled back 2026-04-07, receipt record-a108a4de4d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
