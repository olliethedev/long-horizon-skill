# record-1f46a6de74: triage facets
Alias used in the design review: weekly note. Local variant: record-192230d558.6.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-17: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-ded4332776. Deployment/exposure: 2026-03-20, receipt record-316cc8fdee; 25% of eligible production accounts. The original observation is history/evidence/record-0bc8d71ce6.md. Later review: history/evidence/record-7a2609ce2e.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
