# record-174ac3de70: task drawer
Alias used in the design review: team notifications. Local variant: record-dce8c08a5e.13.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-04: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-8be6aa560b. Deployment/exposure: 2026-05-07, receipt record-099e90d204; 15% of eligible production accounts. The original observation is history/evidence/record-8de4cee95b.md. Later review: history/evidence/record-87a5037e58.md.
Disposition recorded after the first window: Disabled 2026-05-22, receipt record-d0a49b41d8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
