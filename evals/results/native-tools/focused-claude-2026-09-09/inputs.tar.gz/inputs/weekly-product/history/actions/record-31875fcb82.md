# record-31875fcb82: weekly note
Alias used in the design review: task drawer. Local variant: record-647d99546c.5.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-05: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-da573e5184. Deployment/exposure: 2026-07-08, receipt record-11bb0ec994; 25% of eligible production accounts. The original observation is history/evidence/record-2f4ebd558b.md. Later review: history/evidence/record-d4820bd1ab.md.
Disposition recorded after the first window: Rolled back 2026-07-20, receipt record-91f2a293d3, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
