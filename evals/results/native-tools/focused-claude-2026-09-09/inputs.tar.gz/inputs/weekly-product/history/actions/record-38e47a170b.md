# record-38e47a170b: Sunday Room
Alias used in the design review: triage facets. Local variant: record-dce8c08a5e.14.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-05: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-f34bce027b. Deployment/exposure: 2026-04-08, receipt record-5d2bd4ba27; 20% of eligible production accounts. The original observation is history/evidence/record-ed9b666b83.md. Later review: history/evidence/record-a5fcf08ac6.md.
Disposition recorded after the first window: Disabled 2026-04-23, receipt record-2a41e17ce8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
