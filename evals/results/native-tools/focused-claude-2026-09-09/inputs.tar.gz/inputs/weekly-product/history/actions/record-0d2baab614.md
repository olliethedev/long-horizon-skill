# record-0d2baab614: status filters
Alias used in the design review: Focus Shelf. Local variant: record-dce8c08a5e.10.1.
Originating responsibility: regional-quality. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-28: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-e8bd3ea113. Deployment/exposure: 2026-05-31, receipt record-0188158867; 10% of eligible production accounts. The original observation is history/evidence/record-7eab603a22.md. Later review: history/evidence/record-500d11f212.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-13; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
