# record-228ce4b9df: triage facets
Alias used in the design review: weekly note. Local variant: record-192230d558.4.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-33c3c1ce44. Deployment/exposure: 2026-03-15, receipt record-3d822a265d; 25% of eligible production accounts. The original observation is history/evidence/record-88b5d43767.md. Later review: history/evidence/record-0378691af0.md.
Disposition recorded after the first window: Disabled 2026-03-30, receipt record-726b9a916e, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
