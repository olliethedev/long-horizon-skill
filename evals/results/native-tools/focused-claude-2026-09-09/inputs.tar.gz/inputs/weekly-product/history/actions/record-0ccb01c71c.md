# record-0ccb01c71c: team notifications
Alias used in the design review: status filters. Local variant: record-8ff9b086a1.3.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-27: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-764bc2a57e. Deployment/exposure: 2026-03-30, receipt record-e774dabffb; 25% of eligible production accounts. The original observation is history/evidence/record-f61fd6b539.md. Later review: history/evidence/record-538509e79e.md.
Disposition recorded after the first window: Disabled 2026-04-10, receipt record-e7f89f0fc0, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
