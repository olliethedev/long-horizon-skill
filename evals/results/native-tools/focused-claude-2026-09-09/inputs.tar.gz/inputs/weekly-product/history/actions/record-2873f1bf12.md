# record-2873f1bf12: status filters
Alias used in the design review: Focus Shelf. Local variant: record-cd29ee5f7a.3.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-29: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-8f1f7c5c1a. Deployment/exposure: 2026-07-02, receipt record-7f4912c6a1; 20% of eligible production accounts. The original observation is history/evidence/record-84846c0ac7.md. Later review: history/evidence/record-d9b1a1dbcc.md.
Disposition recorded after the first window: Rolled back 2026-07-10, receipt record-f8b2c61357, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
