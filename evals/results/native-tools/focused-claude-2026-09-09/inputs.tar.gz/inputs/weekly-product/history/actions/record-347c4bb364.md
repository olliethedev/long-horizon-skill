# record-347c4bb364: Sunday Room
Alias used in the design review: triage facets. Local variant: record-562146c9ea.15.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-01: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-84598864ee. Deployment/exposure: 2026-03-04, receipt record-4a7f4607c2; 20% of eligible production accounts. The original observation is history/evidence/record-60e8faa46a.md. Later review: history/evidence/record-31cbc0147d.md.
Disposition recorded after the first window: Disabled 2026-03-19, receipt record-2d718855dd, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
