# record-1fa0da0ec7: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-562146c9ea.9.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-24: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-6af786cc7e. Deployment/exposure: 2026-07-27, receipt record-d80a612b6e; 20% of eligible production accounts. The original observation is history/evidence/record-69f0ab7c8b.md. Later review: history/evidence/record-801ec6f767.md.
Disposition recorded after the first window: Rolled back 2026-08-08, receipt record-6c538c243f, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
