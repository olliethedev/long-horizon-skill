# record-393c1ac5d8: status filters
Alias used in the design review: Focus Shelf. Local variant: record-b88d0e3215.2.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-26: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-79ac467cc1. Deployment/exposure: 2026-05-29, receipt record-24c80b7108; 25% of eligible production accounts. The original observation is history/evidence/record-04889ec611.md. Later review: history/evidence/record-db6a379f85.md.
Disposition recorded after the first window: Disabled 2026-06-13, receipt record-22f3796350, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
