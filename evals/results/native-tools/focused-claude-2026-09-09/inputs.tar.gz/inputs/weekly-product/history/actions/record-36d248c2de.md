# record-36d248c2de: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.12.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-27: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-4a9b6c9a09. Deployment/exposure: 2026-04-30, receipt record-1dc418e181; 5% of eligible production accounts. The original observation is history/evidence/record-c955a125a5.md. Later review: history/evidence/record-c97fd18344.md.
Disposition recorded after the first window: Rolled back 2026-05-12, receipt record-80da6f78b2, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
