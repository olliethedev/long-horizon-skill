# record-30d12b1df3: task drawer
Alias used in the design review: team notifications. Local variant: record-ec0e0ab09e.6.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-69d086e005. Deployment/exposure: 2026-04-05, receipt record-3db260c0d2; 5% of eligible production accounts. The original observation is history/evidence/record-12d7dda4eb.md. Later review: history/evidence/record-0cd9477e4e.md.
Disposition recorded after the first window: Rolled back 2026-04-13, receipt record-795608bb7e, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
