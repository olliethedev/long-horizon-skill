# record-37a02bb70e: weekly note
Alias used in the design review: task drawer. Local variant: record-b88d0e3215.10.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-04: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-004b2f8307. Deployment/exposure: 2026-07-07, receipt record-0789bb66b7; 20% of eligible production accounts. The original observation is history/evidence/record-bcbc3c13e8.md. Later review: history/evidence/record-18d13d302d.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-16; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
