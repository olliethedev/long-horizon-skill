# record-3a9e4f26a9: team notifications
Alias used in the design review: status filters. Local variant: record-647d99546c.3.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-24: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-8f094b2a9c. Deployment/exposure: 2026-05-27, receipt record-9ffde78ffb; 15% of eligible production accounts. The original observation is history/evidence/record-8d97f2c28e.md. Later review: history/evidence/record-86fde050d2.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-09; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
