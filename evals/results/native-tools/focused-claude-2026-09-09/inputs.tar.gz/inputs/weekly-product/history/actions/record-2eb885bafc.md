# record-2eb885bafc: task drawer
Alias used in the design review: team notifications. Local variant: record-8ff9b086a1.12.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-55ebe8dc78. Deployment/exposure: 2026-04-05, receipt record-24815a1164; 5% of eligible production accounts. The original observation is history/evidence/record-ec807e57dc.md. Later review: history/evidence/record-49e841e162.md.
Disposition recorded after the first window: Rolled back 2026-04-13, receipt record-100f92f59d, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
