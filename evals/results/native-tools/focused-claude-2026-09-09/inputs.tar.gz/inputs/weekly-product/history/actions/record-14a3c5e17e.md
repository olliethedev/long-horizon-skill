# record-14a3c5e17e: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-dce8c08a5e.11.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-20: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-66d0fbb3df. Deployment/exposure: 2026-06-23, receipt record-5d0d2b1a2e; 25% of eligible production accounts. The original observation is history/evidence/record-bd401b14ed.md. Later review: history/evidence/record-ae5a0efd93.md.
Disposition recorded after the first window: Disabled 2026-07-08, receipt record-a348a127d9, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
