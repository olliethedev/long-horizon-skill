# record-06a1f46fd2: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-b88d0e3215.15.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-01c2ed4e87. Deployment/exposure: 2026-05-19, receipt record-73c182ee88; 25% of eligible production accounts. The original observation is history/evidence/record-6998897499.md. Later review: history/evidence/record-5d1b80eb44.md.
Disposition recorded after the first window: Disabled 2026-05-30, receipt record-2f7054c847, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
