# record-2aea4a4986: task drawer
Alias used in the design review: team notifications. Local variant: record-ec0e0ab09e.8.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-13: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-2b212432b5. Deployment/exposure: 2026-07-16, receipt record-374872ceef; 15% of eligible production accounts. The original observation is history/evidence/record-bf83ab4f59.md. Later review: history/evidence/record-361e00ae85.md.
Disposition recorded after the first window: Disabled 2026-07-27, receipt record-8231acb24f, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
