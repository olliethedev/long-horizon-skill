# record-0bd3c2ad38: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.15.2.
Originating responsibility: retained-growth. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-cd40f190de. Deployment/exposure: 2026-06-27, receipt record-2e94be3b34; 20% of eligible production accounts. The original observation is history/evidence/record-3aed423158.md. Later review: history/evidence/record-270ee7c283.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
