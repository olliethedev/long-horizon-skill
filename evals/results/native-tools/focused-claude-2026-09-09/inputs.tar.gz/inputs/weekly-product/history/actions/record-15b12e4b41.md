# record-15b12e4b41: quiet digest
Alias used in the design review: Sunday Room. Local variant: record-cd29ee5f7a.7.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-24: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-b07941e218. Deployment/exposure: 2026-06-27, receipt record-cb4de8b590; 20% of eligible production accounts. The original observation is history/evidence/record-684055ef4d.md. Later review: history/evidence/record-4e3a28ee7f.md.
Disposition recorded after the first window: Disabled 2026-07-12, receipt record-2606e7b86e, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
