# record-0121c8b91a: status filters
Alias used in the design review: Focus Shelf. Local variant: record-647d99546c.11.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-12: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-93cbdabce6. Deployment/exposure: 2026-03-15, receipt record-36ef7d1d0a; 25% of eligible production accounts. The original observation is history/evidence/record-efffc339df.md. Later review: history/evidence/record-c876ea16ff.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-24; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
