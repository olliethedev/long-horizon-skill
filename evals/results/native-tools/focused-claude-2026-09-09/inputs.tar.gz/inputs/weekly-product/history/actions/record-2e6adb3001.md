# record-2e6adb3001: Sunday Room
Alias used in the design review: triage facets. Local variant: record-8ff9b086a1.0.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-31: a retry was recorded as a new event during a short disconnect. The proposed change was to retain the original event identity through retries.
Implementation: record-451d2fd9e4. Deployment/exposure: 2026-06-03, receipt record-5193771a10; 25% of eligible production accounts. The original observation is history/evidence/record-6eb340674d.md. Later review: history/evidence/record-94bcf4a9a1.md.
Disposition recorded after the first window: Disabled 2026-06-14, receipt record-16f16389f3, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
