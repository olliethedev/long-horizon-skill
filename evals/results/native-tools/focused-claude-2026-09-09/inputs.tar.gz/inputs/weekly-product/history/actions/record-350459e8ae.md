# record-350459e8ae: team notifications
Alias used in the design review: status filters. Local variant: record-ec0e0ab09e.5.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-26: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-310f45fe32. Deployment/exposure: 2026-07-29, receipt record-1ceb765cee; 5% of eligible production accounts. The original observation is history/evidence/record-44d2c06fa6.md. Later review: history/evidence/record-701b3780df.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-08-07; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
