# record-39b6805fde: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-cd29ee5f7a.4.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-16: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-9d3badebf5. Deployment/exposure: 2026-05-19, receipt record-dc7d75c120; 25% of eligible production accounts. The original observation is history/evidence/record-24934b33d9.md. Later review: history/evidence/record-9cfad2f019.md.
Disposition recorded after the first window: Disabled 2026-05-30, receipt record-d811f43bb5, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
