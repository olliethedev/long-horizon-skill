# record-00a9cf217b: status filters
Alias used in the design review: Focus Shelf. Local variant: record-562146c9ea.14.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-04: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-074533f132. Deployment/exposure: 2026-03-07, receipt record-e99025a720; 10% of eligible production accounts. The original observation is history/evidence/record-09fcf64867.md. Later review: history/evidence/record-b28ee29241.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
