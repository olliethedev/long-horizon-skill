# record-0a81ad57a3: status filters
Alias used in the design review: Focus Shelf. Local variant: record-647d99546c.3.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-04: resuming after an interrupted connection repeated the previous page. The proposed change was to preserve the last completed checkpoint.
Implementation: record-82f7c435ea. Deployment/exposure: 2026-06-07, receipt record-2faa6ba089; 20% of eligible production accounts. The original observation is history/evidence/record-573aceb46a.md. Later review: history/evidence/record-c3100c1c35.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-20; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
