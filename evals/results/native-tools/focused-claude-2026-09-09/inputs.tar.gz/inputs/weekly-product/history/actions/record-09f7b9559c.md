# record-09f7b9559c: task drawer
Alias used in the design review: team notifications. Local variant: record-431a358680.3.0.
Originating responsibility: onboarding-cycle. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-a5c0507b19. Deployment/exposure: 2026-04-05, receipt record-0c8a153e32; 5% of eligible production accounts. The original observation is history/evidence/record-0c1c392eb9.md. Later review: history/evidence/record-fadea5888c.md.
Disposition recorded after the first window: Rolled back 2026-04-17, receipt record-c21c7bccff, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
