# record-1bb9da1fe2: Sunday Room
Alias used in the design review: triage facets. Local variant: record-647d99546c.10.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-10: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-69de71abd7. Deployment/exposure: 2026-05-13, receipt record-d25ba90a85; 20% of eligible production accounts. The original observation is history/evidence/record-1e8c78c256.md. Later review: history/evidence/record-0791081b45.md.
Disposition recorded after the first window: Disabled 2026-05-24, receipt record-034a4e7605, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
