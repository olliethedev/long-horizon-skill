# record-36f8dbf76a: team notifications
Alias used in the design review: status filters. Local variant: record-ec0e0ab09e.6.1.
Originating responsibility: regional-quality. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-19: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-44b93687cf. Deployment/exposure: 2026-07-22, receipt record-1c72c76fbc; 20% of eligible production accounts. The original observation is history/evidence/record-eb4412653e.md. Later review: history/evidence/record-c8b04ef857.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-31; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
