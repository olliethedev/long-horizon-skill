# record-0e7fabc9ad: triage facets
Alias used in the design review: weekly note. Local variant: record-8ff9b086a1.10.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-23: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-568bcbdba9. Deployment/exposure: 2026-04-26, receipt record-0c4e02cc47; 10% of eligible production accounts. The original observation is history/evidence/record-330c07f657.md. Later review: history/evidence/record-c093b7ac8c.md.
Disposition recorded after the first window: Disabled 2026-05-07, receipt record-de97686ece, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
