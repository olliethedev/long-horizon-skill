# record-2efd9d8cad: triage facets
Alias used in the design review: weekly note. Local variant: record-192230d558.1.3.
Originating responsibility: client-reliability. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-06: pending work appeared in the same counter as confirmed completed work. The proposed change was to show separate states for pending and complete.
Implementation: record-a357b920d7. Deployment/exposure: 2026-08-09, receipt record-e51c7aa43a; 10% of eligible production accounts. The original observation is history/evidence/record-200bdd35c9.md. Later review: history/evidence/record-e7cf157048.md.
Disposition recorded after the first window: Disabled 2026-08-20, receipt record-a6f2c280b6, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
