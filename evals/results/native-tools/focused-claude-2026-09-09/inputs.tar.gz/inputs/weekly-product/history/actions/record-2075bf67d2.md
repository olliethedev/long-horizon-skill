# record-2075bf67d2: triage facets
Alias used in the design review: weekly note. Local variant: record-562146c9ea.0.1.
Originating responsibility: regional-quality. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-17: switching panels detached the visible progress from the running operation. The proposed change was to keep the progress indicator attached to the operation.
Implementation: record-d678177f40. Deployment/exposure: 2026-03-20, receipt record-d260f2aa31; 25% of eligible production accounts. The original observation is history/evidence/record-e4b80fc2da.md. Later review: history/evidence/record-38f91ddc58.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-03-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
