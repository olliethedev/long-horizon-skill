# record-2a5dd02da1: triage facets
Alias used in the design review: weekly note. Local variant: record-431a358680.14.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-02: a refresh replaced a pending selection while its confirmation was open. The proposed change was to delay background refresh until the dialog closes.
Implementation: record-5f5cea64ed. Deployment/exposure: 2026-04-05, receipt record-c1a3576932; 5% of eligible production accounts. The original observation is history/evidence/record-3786726933.md. Later review: history/evidence/record-cd7536d55f.md.
Disposition recorded after the first window: Disabled 2026-04-16, receipt record-4053841ca8, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
