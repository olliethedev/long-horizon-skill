# record-12e80d5bde: status filters
Alias used in the design review: Focus Shelf. Local variant: record-192230d558.7.2.
Originating responsibility: retained-growth. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-25: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-5015e567f1. Deployment/exposure: 2026-03-28, receipt record-39e04f29f8; 15% of eligible production accounts. The original observation is history/evidence/record-ed4ab3bdcc.md. Later review: history/evidence/record-4feb1770f7.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
