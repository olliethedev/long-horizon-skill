# record-0487d4cfda: status filters
Alias used in the design review: Focus Shelf. Local variant: record-8ff9b086a1.2.3.
Originating responsibility: client-reliability. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-14: the profile region and workspace region disagreed after migration. The proposed change was to use the account's current regional setting.
Implementation: record-8270d1204c. Deployment/exposure: 2026-04-17, receipt record-2d0156619b; 15% of eligible production accounts. The original observation is history/evidence/record-ca4445dede.md. Later review: history/evidence/record-c05abf26b8.md.
Disposition recorded after the first window: Disabled 2026-04-28, receipt record-ed29beae1f, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
