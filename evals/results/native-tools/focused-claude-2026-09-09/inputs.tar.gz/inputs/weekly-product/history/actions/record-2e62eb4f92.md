# record-2e62eb4f92: weekly note
Alias used in the design review: task drawer. Local variant: record-192230d558.10.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-01: a translated title was served from a previous locale's cached response. The proposed change was to include the locale in the cache key.
Implementation: record-3d66ad6785. Deployment/exposure: 2026-03-04, receipt record-a12b41fa61; 20% of eligible production accounts. The original observation is history/evidence/record-ffcbad0da1.md. Later review: history/evidence/record-cbe955843b.md.
Disposition recorded after the first window: Rolled back 2026-03-12, receipt record-c5f8e85baf, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
