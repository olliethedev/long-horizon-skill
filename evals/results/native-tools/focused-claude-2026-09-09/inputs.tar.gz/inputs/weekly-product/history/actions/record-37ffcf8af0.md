# record-37ffcf8af0: team notifications
Alias used in the design review: status filters. Local variant: record-562146c9ea.3.2.
Originating responsibility: retained-growth. Cohort: returning desktop teams in Germany. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-04-18: the initial query waited for the archived-workspace count. The proposed change was to defer the status count until interaction.
Implementation: record-ad87b2b50f. Deployment/exposure: 2026-04-21, receipt record-98242f5b4a; 10% of eligible production accounts. The original observation is history/evidence/record-e51a3f39d6.md. Later review: history/evidence/record-6cb540cb0a.md.
Disposition recorded after the first window: The comparison remains inconclusive. The implementation stays exposed only in its existing pilot while additional recordings are reviewed.
Coordination: the payment retry cleanup was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
