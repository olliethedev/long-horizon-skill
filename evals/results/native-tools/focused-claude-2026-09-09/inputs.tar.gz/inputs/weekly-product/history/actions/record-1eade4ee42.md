# record-1eade4ee42: Sunday Room
Alias used in the design review: triage facets. Local variant: record-8ff9b086a1.10.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-30: cached eligibility outlived the permission that originally supplied it. The proposed change was to recalculate eligibility on session resume.
Implementation: record-1f33c7a2c2. Deployment/exposure: 2026-06-02, receipt record-087a01344f; 20% of eligible production accounts. The original observation is history/evidence/record-bafd34629c.md. Later review: history/evidence/record-e890f18876.md.
Disposition recorded after the first window: Rolled back 2026-06-10, receipt record-6ec8aac9b1, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
