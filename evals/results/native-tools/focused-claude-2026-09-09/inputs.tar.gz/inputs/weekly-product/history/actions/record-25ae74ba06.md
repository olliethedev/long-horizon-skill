# record-25ae74ba06: quiet digest
Alias used in the design review: Sunday Room. Local variant: record-8ff9b086a1.9.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-13: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-c5ead62e68. Deployment/exposure: 2026-07-16, receipt record-4311e7d99f; 15% of eligible production accounts. The original observation is history/evidence/record-52fa5ad31b.md. Later review: history/evidence/record-6e3b92b907.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-29; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
