# record-28edda2bcf: status filters
Alias used in the design review: Focus Shelf. Local variant: record-8ff9b086a1.0.0.
Originating responsibility: onboarding-cycle. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-15: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-f89208eb32. Deployment/exposure: 2026-06-18, receipt record-65ca9ac8a5; 25% of eligible production accounts. The original observation is history/evidence/record-7ea0f586ed.md. Later review: history/evidence/record-adae494505.md.
Disposition recorded after the first window: Rolled back 2026-06-26, receipt record-1effaf1658, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
