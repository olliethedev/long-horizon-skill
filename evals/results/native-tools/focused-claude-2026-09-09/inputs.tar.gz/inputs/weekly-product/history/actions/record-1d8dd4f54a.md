# record-1d8dd4f54a: task drawer
Alias used in the design review: team notifications. Local variant: record-8ff9b086a1.13.0.
Originating responsibility: onboarding-cycle. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-03-26: the default query scanned inactive records outside the selected date range. The proposed change was to load the narrow date range before optional history.
Implementation: record-105ab10ca1. Deployment/exposure: 2026-03-29, receipt record-d05e8e5e3e; 20% of eligible production accounts. The original observation is history/evidence/record-7f828b9dde.md. Later review: history/evidence/record-26f5e5fff7.md.
Disposition recorded after the first window: Rolled back 2026-04-06, receipt record-c81a8c9eae, because the resumed-session check still failed.
Coordination: the locale refresh was active for part of the same week; the analyst retained that limitation. A similarly named change for a different revision requires its own source chain.
