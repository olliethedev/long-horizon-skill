# record-283e1bd306: Sunday Room
Alias used in the design review: triage facets. Local variant: record-192230d558.15.1.
Originating responsibility: regional-quality. Cohort: US enterprise administrators. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-05-29: selection was retained for one workspace but reset when the account changed. The proposed change was to restore selection after account switch.
Implementation: record-8018f31afd. Deployment/exposure: 2026-06-01, receipt record-28b73ca1ac; 15% of eligible production accounts. The original observation is history/evidence/record-4327c25303.md. Later review: history/evidence/record-58b278b2d8.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-06-14; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
