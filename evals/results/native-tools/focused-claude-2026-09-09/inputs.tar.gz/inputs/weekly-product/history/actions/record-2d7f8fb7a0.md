# record-2d7f8fb7a0: status filters
Alias used in the design review: Focus Shelf. Local variant: record-431a358680.15.1.
Originating responsibility: regional-quality. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-16: people mistook the confirmation for an additional required action. The proposed change was to move the confirmation below the result.
Implementation: record-355d128407. Deployment/exposure: 2026-07-19, receipt record-65d5669e56; 5% of eligible production accounts. The original observation is history/evidence/record-25139486ee.md. Later review: history/evidence/record-a7dc950a62.md.
Disposition recorded after the first window: Retained for this cohort after the review on 2026-07-28; no claim is made about the other clients.
Coordination: the workspace migration was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
