# record-3ad8f76c87: Focus Shelf
Alias used in the design review: quiet digest. Local variant: record-562146c9ea.14.3.
Originating responsibility: client-reliability. Cohort: Brazilian free workspaces. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-06-20: recordings showed repeated selection of an already active option. The proposed change was to increase contrast on the selected option.
Implementation: record-83b306c7c9. Deployment/exposure: 2026-06-23, receipt record-ff232f734f; 25% of eligible production accounts. The original observation is history/evidence/record-2ba86f9fa1.md. Later review: history/evidence/record-ec02b1305d.md.
Disposition recorded after the first window: Disabled 2026-07-04, receipt record-2178078756, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
