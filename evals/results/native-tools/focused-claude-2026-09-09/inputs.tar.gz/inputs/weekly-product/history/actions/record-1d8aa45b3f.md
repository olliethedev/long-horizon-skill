# record-1d8aa45b3f: quiet digest
Alias used in the design review: Sunday Room. Local variant: record-dce8c08a5e.13.3.
Originating responsibility: client-reliability. Cohort: new Android accounts in Canada. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-08-05: the migration counted an inherited preference as an explicit user choice. The proposed change was to split legacy and newly created preference records.
Implementation: record-7544d4aa69. Deployment/exposure: 2026-08-08, receipt record-5633f899c1; 5% of eligible production accounts. The original observation is history/evidence/record-89feccccbe.md. Later review: history/evidence/record-0cd741a9f2.md.
Disposition recorded after the first window: Disabled 2026-08-19, receipt record-956541060b, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
