# record-296d706b7f: status filters
Alias used in the design review: Focus Shelf. Local variant: record-ec0e0ab09e.4.3.
Originating responsibility: client-reliability. Cohort: UK solo contributors on iOS. This action's eligibility is restricted to that population and revision.
Problem recorded 2026-07-14: the second confirmation increased exits without additional validation. The proposed change was to remove a redundant intermediate confirmation.
Implementation: record-46895bd39e. Deployment/exposure: 2026-07-17, receipt record-11fcdd70fa; 20% of eligible production accounts. The original observation is history/evidence/record-6f472d92f3.md. Later review: history/evidence/record-de8f2cf9da.md.
Disposition recorded after the first window: Disabled 2026-08-01, receipt record-fc9afd4394, when the partner migration changed the cohort definition.
Coordination: the navigation update was excluded from the enrollment list. A similarly named change for a different revision requires its own source chain.
