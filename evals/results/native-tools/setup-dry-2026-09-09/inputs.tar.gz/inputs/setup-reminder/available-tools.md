Installed tools: Bell, Impulse. Impulse has a configured agent launcher.
