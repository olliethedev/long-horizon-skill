The project uses Bell for calendar notices; evaluate continuation before activating this responsibility.
