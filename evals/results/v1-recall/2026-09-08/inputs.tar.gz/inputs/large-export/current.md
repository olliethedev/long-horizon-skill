# Current handoff
Written August 29. Async export is shipped. The support dashboard says the feature is 14 days old, so some remaining requests could predate the rollout. The standard smoke check passed. Consider whether these tickets can close.
