# Customer conversation 8117
Subject: CSV download
Cohort: internal QA accounts in staging
Submitted: 2026-05-26
Imported: 2026-05-28
Customer: We use csv download when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
