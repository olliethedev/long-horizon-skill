# exp-422 progress wording
Deployed September 5, receipt deploy-x422. Adds 'Preparing your export' to the spinner. No worker, row-selection, checkpoint, or signed-URL changes. It overlaps exp-407's observation period but cannot establish that the underlying jobs complete correctly.
