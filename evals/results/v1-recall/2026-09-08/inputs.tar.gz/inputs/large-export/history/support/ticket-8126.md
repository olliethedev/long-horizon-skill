# Customer conversation 8126
Subject: Ledger Ferry
Cohort: US enterprise administrators
Submitted: 2026-07-10
Imported: 2026-07-12
Customer: We use ledger ferry when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
