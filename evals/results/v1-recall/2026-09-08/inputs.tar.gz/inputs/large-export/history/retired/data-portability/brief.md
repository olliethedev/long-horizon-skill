# data-portability
Status: terminated July 15 after the bounded export API launch. Keep its delivery receipts and benchmarks for product support.
