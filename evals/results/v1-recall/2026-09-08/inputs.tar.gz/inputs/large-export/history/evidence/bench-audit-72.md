# bench-audit-72
Dated September 7. Corrects the broad description of bench-181: it tested 10,000 CSV rows, no NDJSON, no 1M+ workspace. It does not demonstrate large-export reliability. The June streaming deployment remains real.
