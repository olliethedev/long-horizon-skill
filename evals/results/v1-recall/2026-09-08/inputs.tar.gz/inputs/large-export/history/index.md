# Product history navigation
Generated: 2026-08-19. This navigation is an old convenience copy.
Original action records live under history/actions; support, evidence, releases, and retired responsibility folders hold their own source records. Later observations can refer to an action without changing its original file.
