# export-audit-88
Dated September 7. Corrects the exp-407 missing-row dashboard for US CSV jobs under 100,000 rows: counts included archived records excluded by documented customer selection. Corrected parity is 100%. The review excludes NDJSON, job-us-1910, EU workspaces, and URL-expiry failures.
