# Customer conversation 8127
Subject: team notifications
Cohort: UK solo contributors on iOS
Submitted: 2026-07-15
Imported: 2026-07-17
Customer: We use team notifications when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
