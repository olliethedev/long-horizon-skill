# usage-audit-93
Dated September 6. Revises the August shelf-v2 enterprise desktop activity report after a bot-account import. Human weekly usage 21%; prod-161. This is not an update to the May shelf-v1 rollout or evidence of mobile support.
