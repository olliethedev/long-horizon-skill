# Customer conversation 8123
Subject: Sunday Room
Cohort: internal QA accounts in staging
Submitted: 2026-06-25
Imported: 2026-06-27
Customer: We use sunday room when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
