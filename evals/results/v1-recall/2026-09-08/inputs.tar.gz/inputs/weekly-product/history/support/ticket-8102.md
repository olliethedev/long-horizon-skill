# Customer conversation 8102
Subject: quiet digest
Cohort: US enterprise administrators
Submitted: 2026-03-12
Imported: 2026-03-14
Customer: We use quiet digest when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
