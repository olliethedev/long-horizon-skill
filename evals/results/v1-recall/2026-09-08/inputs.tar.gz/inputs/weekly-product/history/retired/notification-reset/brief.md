# notification-reset
Bounded responsibility terminated July 31 after preference migration. Its action and preference audit records are retained for continuing product work.
