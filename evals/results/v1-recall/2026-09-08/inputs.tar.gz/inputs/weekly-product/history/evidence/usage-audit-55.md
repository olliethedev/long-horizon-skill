# usage-audit-55
Dated June 18. Corrects obs-114 for prod-114: weekly usage among active humans was 28%. This repairs the low-use interpretation. Count-query latency at more than 50,000 tasks remained a problem; the June 2 rollback happened. The audit contains no mobile exposure.
