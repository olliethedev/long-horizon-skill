# prod-137: Sunday Room
Aliases: quiet digest; weekly note. Deployed July 12, receipt deploy-725. Workspace administrators could select weekly instead of daily email. The UI copy said 'team digest'; contributor-level legacy daily subscriptions were not migrated by this change.
