# Customer conversation 8129
Subject: Focus Shelf
Cohort: internal QA accounts in staging
Submitted: 2026-07-25
Imported: 2026-07-27
Customer: We use focus shelf when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
