# pref-audit-18
Dated August 19. prod-137 follow-up. Admin preference storage is correct. For contributors who subscribed before July 12, legacy per-user daily preferences take precedence over workspace weekly preferences. This affects 63 sampled contributors across nine teams; the capability is delivered but does not cover that migration path.
