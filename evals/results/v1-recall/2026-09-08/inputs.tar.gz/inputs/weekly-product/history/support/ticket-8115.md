# Customer conversation 8115
Subject: Sunday Room
Cohort: UK solo contributors on iOS
Submitted: unknown
Imported: 2026-05-18
Customer: We use sunday room when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
