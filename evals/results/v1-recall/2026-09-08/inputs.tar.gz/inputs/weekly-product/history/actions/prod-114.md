# prod-114: Focus Shelf
Aliases: triage facets; status filters. Internal name shelf-v1. Deployed May 14 to enterprise desktop accounts only, receipt deploy-611. Android and iOS were not included. Initial obs-114 reported 2% weekly use. Rolled back June 2, receipt rollback-210, after slow count queries in workspaces over 50,000 tasks.
