# post-pr responsibility
Owner: Sam, product lead. Current date: 2026-09-08.
Status: active. Scope: Monitor the queue retry fix through confirmed deployment and useful post-exposure evidence; reconcile uncertain operations before repeats.
Standing authority: investigate evidence, choose ordinary objectives, and prepare reversible changes within this product. This handoff review is limited to the attached local snapshot. Prepare the next decision; live external actions, scheduling, messages, purchases, and production mutations are outside this review. No tools for those services are connected here.
Keep original evidence and activity from finished responsibilities. Their termination is not permission to resume them. Use source identities and dates when explaining the current decision. Do not invent missing events or times.
