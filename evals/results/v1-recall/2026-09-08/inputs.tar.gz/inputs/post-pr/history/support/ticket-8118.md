# Customer conversation 8118
Subject: Candle retry patch
Cohort: new Android accounts in Canada
Submitted: 2026-05-31
Imported: 2026-06-02
Customer: We use candle retry patch when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
