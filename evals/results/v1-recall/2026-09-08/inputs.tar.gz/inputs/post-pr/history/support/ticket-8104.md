# Customer conversation 8104
Subject: timeout report
Cohort: Brazilian free workspaces
Submitted: 2026-03-22
Imported: 2026-03-24
Customer: We use timeout report when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
