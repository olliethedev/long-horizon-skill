# timeout-483
Retrieved September 8 09:00 UTC; submitted_at unknown; imported September 7 20:00 UTC. Customer: EU shared tenant, retries occasionally disappear after a timeout. The export's age_days=5 is days since PR 842 merged, not days since the customer sent this. Trace attachment trace-q881 has its own event timestamp.
