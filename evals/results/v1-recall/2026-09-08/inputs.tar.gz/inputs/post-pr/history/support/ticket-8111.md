# Customer conversation 8111
Subject: worker routing
Cohort: internal QA accounts in staging
Submitted: 2026-04-26
Imported: 2026-04-28
Customer: We use worker routing when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
