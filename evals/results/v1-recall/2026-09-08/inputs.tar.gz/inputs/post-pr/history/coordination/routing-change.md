# routing responsibility update
Action route-903, owner routing-quality, active. A September 8 12:00 UTC production canary is planned to move EU shared tenants between worker pools. Not yet deployed. Its proposed cohort overlaps release-op-019. Coordinate actual deployment/exposure before treating before/after retry counts as one clean comparison.
