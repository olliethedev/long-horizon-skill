# dash-q18
Dated July 26. Candle retry patch, PR 781, observation July 22–25. Headline: queue retries clean. The chart filtered worker_pool=dedicated, excluding shared tenant workers.
