# Customer conversation 8100
Subject: queue retry fix
Cohort: new Android accounts in Canada
Submitted: unknown
Imported: 2026-03-04
Customer: We use queue retry fix when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
