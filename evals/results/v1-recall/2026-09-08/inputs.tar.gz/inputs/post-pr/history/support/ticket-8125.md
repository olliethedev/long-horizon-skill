# Customer conversation 8125
Subject: shared worker
Cohort: returning desktop teams in Germany
Submitted: unknown
Imported: 2026-07-07
Customer: We use shared worker when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
