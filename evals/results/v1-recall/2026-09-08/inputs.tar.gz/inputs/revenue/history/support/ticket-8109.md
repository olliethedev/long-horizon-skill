# Customer conversation 8109
Subject: renewal reminder
Cohort: UK solo contributors on iOS
Submitted: 2026-04-16
Imported: 2026-04-18
Customer: We use renewal reminder when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
