# obs-219-a
Recorded August 18. rev-219 H1. New US mobile accounts exposed August 11–17. Revenue per new account -9%; no confidence claim. Some resumed sessions were counted as new accounts twice. Seven of twelve reviewed permission-dialog sessions reset the chosen annual plan.
