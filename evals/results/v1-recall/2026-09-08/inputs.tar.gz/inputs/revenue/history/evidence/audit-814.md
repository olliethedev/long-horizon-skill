# audit-814
Dated 2026-09-07. Harbor reporting on returning desktop accounts, rev-308, August 25–31. A billing retry inflated annual-plan counts; corrected revenue -3%. The product name overlaps rev-219, but this is a different action and population.
