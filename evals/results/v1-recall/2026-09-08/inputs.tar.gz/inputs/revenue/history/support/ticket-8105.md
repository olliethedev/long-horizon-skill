# Customer conversation 8105
Subject: Harbor
Cohort: internal QA accounts in staging
Submitted: unknown
Imported: 2026-03-29
Customer: We use harbor when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
