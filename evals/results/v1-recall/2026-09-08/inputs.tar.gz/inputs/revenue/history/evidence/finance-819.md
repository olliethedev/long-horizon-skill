# finance-819 correction
Recorded 2026-09-06. Reference: Quiet Return name reused by rev-312. US returning desktop monthly subscribers, variant W3, August 20–27. The prior -1% net-revenue estimate becomes +4% after late invoices. This report does not cover rev-208, R7, returning iOS annual subscribers, or July exposures.
