# Customer conversation 8128
Subject: Anchor plan picker
Cohort: Brazilian free workspaces
Submitted: 2026-07-20
Imported: 2026-07-22
Customer: We use anchor plan picker when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
