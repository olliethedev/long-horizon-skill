# Summer offers
Status: terminated 2026-07-30 after the bounded summer campaign. Retain its experiments for the revenue responsibility. No further work or schedule remains for summer-offers.
