# Customer conversation 8131
Subject: returning mobile offer
Cohort: returning desktop teams in Germany
Submitted: 2026-08-04
Imported: 2026-08-06
Customer: We use returning mobile offer when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
