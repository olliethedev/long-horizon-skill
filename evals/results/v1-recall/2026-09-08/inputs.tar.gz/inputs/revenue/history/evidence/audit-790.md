# audit-790
Recorded 2026-08-24. Corrects obs-219-a for rev-219 H1, same cohort and exposure window. Deduplicated revenue per new account is +1.8%, with a wide interval spanning harm and benefit; the test is inconclusive. The reset behavior in recordings remains real, and rollback rb-141 occurred. Do not label Harbor a demonstrated loss or win.
