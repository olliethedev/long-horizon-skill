# Customer conversation 8116
Subject: Quiet Return
Cohort: Brazilian free workspaces
Submitted: 2026-05-21
Imported: 2026-05-23
Customer: We use quiet return when reviewing our team's Monday work. The wording and order are less predictable after switching workspaces. We can finish the task, but we would like the state to remain visible when returning to the page.
Support: Could you share the workspace size and the client version?
Resolution: awaiting the customer's reproduction details; no deployment claim.
