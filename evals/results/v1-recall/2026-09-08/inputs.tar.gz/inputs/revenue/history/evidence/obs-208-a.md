# obs-208-a
Recorded 2026-07-20. rev-208 R7, US returning iOS annual subscribers, July 13–19. Trial starts +11%; retained-net-revenue not yet mature. Analyst headline: promising. This is an early funnel metric.
